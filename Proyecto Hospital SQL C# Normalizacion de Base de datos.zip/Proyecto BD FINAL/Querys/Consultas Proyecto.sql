use PROYECTO

-- 1. Crear y mantener registros que registren los detalles de los miembros del personal (oficial de personal).INSERT INTO personal (No_personal, nombre, apellido, Direccion, Sexo, fecha_nacimiento, telefono, id_puesto, NSS, horasXsemana, salario_actual, pago_semanal_mensual, id_escala_salarial, permanente_temporal, id_turnos)
VALUES (19, 'Jhon', 'Gonzales', '56 calle', 'Masculino', '1990-01-15', 12347890, 'PST14', '123-45-6789', 40, 5000.00, 2500.00, 'ES01', 'Permanente', 'T01');
-- 2. B�squeda de personal que tenga t�tulo especial o experiencia laboral previa (oficial de personal).SELECT p.No_personal, p.nombre, p.apellido
FROM personal p
LEFT JOIN detalle_titulo dt ON p.No_personal = dt.No_personal
LEFT JOIN experiencia_laboral el ON p.No_personal = el.No_personal
WHERE dt.id_titulo IS NOT NULL OR el.No_personal IS NOT NULL;


-- 3. Un informe que enumere los detalles del personal asignado a cada sala (oficial de personal y enfermera a cargo).
SELECT 
    s.no_sala AS "N�mero de Sala",
    s.Nombre_sala AS "Nombre de Sala",
    p1.No_personal AS "No. de Personal (Oficial de Personal)",
    p1.nombre AS "Nombre (Oficial de Personal)",
    p1.apellido AS "Apellido (Oficial de Personal)",
    p2.No_personal AS "No. de Personal (Enfermera a Cargo)",
    p2.nombre AS "Nombre (Enfermera a Cargo)",
    p2.apellido AS "Apellido (Enfermera a Cargo)"
FROM 
    salas s
LEFT JOIN detalle_personal_sala dps1 ON s.no_sala = dps1.no_sala AND dps1.No_personal IN (SELECT No_personal FROM personal WHERE id_puesto = 'PST03') -- Reemplazar '(lo que este adentro de comillas)' con el ID del puesto de Oficial de Personal
LEFT JOIN personal p1 ON dps1.No_personal = p1.No_personal
LEFT JOIN detalle_personal_sala dps2 ON s.no_sala = dps2.no_sala AND dps2.No_personal IN (SELECT No_personal FROM personal WHERE id_puesto = 'PST05') -- Reemplazar '(lo que este adentro de comillas)' con el ID del puesto de Enfermera
LEFT JOIN personal p2 ON dps2.No_personal = p2.No_personal;



-- 4. Crear y mantener registros registrando los detalles de los pacientes referidos al hospital (todo el personal).INSERT INTO pacientes (no_paciente, nombre, apellido, direccion, fecha_nacimiento, fecha_registro, sexo, telefono, estado_civil)
VALUES (2001, 'Leslie', 'Sierra', '15 avenida', '1990-02-20', '2023-10-27', 'femenino', 12347890, 'Soltero');


-- 5. Crear y mantener registros que registren los detalles de los pacientes referidos a la cl�nica ambulatoria (enfermera a cargo).

/* Insertar un nuevo paciente referido a la cl�nica ambulatoria*/
INSERT INTO pacientes (no_paciente, nombre, apellido, direccion, fecha_nacimiento, fecha_registro, sexo, telefono, estado_civil)
VALUES (2002, 'Juan', 'Rosales', '15 avenida MP', '1992-03-10', '2023-10-27', 'masculino', 98763210, 'Casado');

/*Nueva enfermera*/
INSERT INTO personal (No_personal, nombre, apellido, Direccion, Sexo, fecha_nacimiento, telefono, id_puesto, NSS, horasXsemana, salario_actual, pago_semanal_mensual, id_escala_salarial, permanente_temporal, id_turnos)
VALUES (18, 'Andrea', 'Pacheco', '34 avenida', 'Femenino', '1990-01-15', 12347890, 'PST05', '123-45-6789', 40, 5000.00, 2500.00, 'ES01', 'Permanente', 'T01');

/* Asignar el paciente a la enfermera a cargo de la cl�nica ambulatoria */
INSERT INTO detalle_personal_sala (No_personal, no_sala)
VALUES (18, 14);  

-- 6. Un informe que enumere los detalles de los pacientes referidos a la cl�nica ambulatoria (enfermero a cargo y director m�dico).


SELECT DISTINCT p.*
FROM pacientes p
JOIN detalle_medico dm ON p.no_paciente = dm.no_paciente
JOIN medico_local ml ON dm.id_medico_local = ml.id_medico_local
JOIN clinicas c ON ml.no_clinica = c.no_clinica
WHERE c.clinica = 'Centro M�dico QRS';



-- 7. Cree y mantenga registros que registren los detalles de los pacientes referidos a una sala en particular (enfermera a cargo)./* Para crear un nuevo registro de paciente en una sala*/
INSERT INTO detalle_paciente_sala (no_paciente, no_sala, lista_espera, espere_quedarse, fecha_salida, fecha_real_salida, no_cama)
VALUES (1, 1, '2023-10-27', 2, '2023-10-29', '2023-10-29', 101);

/* Para asignar un personal de enfermer�a a cargo de la sala*/
INSERT INTO detalle_personal_sala (No_personal, no_sala)
VALUES (1001, 1);


-- 8. Un informe que enumere los detalles de los pacientes que se encuentran actualmente en una sala en particular (enfermero a cargo y director m�dico).


SELECT p.*
FROM pacientes p
JOIN detalle_paciente_sala dps ON p.no_paciente = dps.no_paciente
JOIN salas s ON dps.no_sala = s.no_sala
WHERE s.no_sala = '1';			/*reemplazar id sala dependiendo la sala que se quiera*/



-- 9. Un informe con los detalles de los pacientes actualmente en la lista de espera para una sala en particular (enfermero a cargo y director m�dico).


SELECT p.*
FROM pacientes p
JOIN detalle_paciente_sala dps ON p.no_paciente = dps.no_paciente
JOIN salas s ON dps.no_sala = s.no_sala
WHERE s.no_sala = '2' AND dps.lista_espera IS NOT NULL;



-- 10. Crear y mantener registros que registren los detalles de la medicaci�n administrada a un paciente en particular (enfermera a cargo).


-- Insertar un registro de medicaci�n administrada a un paciente por una enfermera a cargo
INSERT INTO detalle_medicamento (no_paciente, no_medicamento, fecha_comienzo, unidades_por_dia, fehca_finalizar, dosis, id_metodo)
VALUES (1, 1001, '2023-10-27', 2, '2023-10-31', 5, 'ORAL');


-- 11. Un informe que enumere los detalles de la medicaci�n para un paciente en particular (enfermera a cargo).


SELECT m.*, dm.*
FROM pacientes p
JOIN detalle_medicamento dm ON p.no_paciente = dm.no_paciente
JOIN medicamentos m ON dm.no_medicamento = m.no_medicamento
WHERE p.no_paciente = '1005';


-- 12. Crear y mantener registros registrando los detalles de los proveedores para el hospital (director m�dico)


insert into proveedor (no_proveedor, nombre, direccion, telefono, numero_fax) values
('P10', 'Proveedor 10', 'Calle 123, Ciudad de Guatemala', 55555555, 55555556),
('P11', 'Proveedor 11', 'Calle 456, Argentina', 33333333, 33333334),
('P12', 'Proveedor 12', 'Calle 789, vegas', 81818181, 81818182),
('P13', 'Proveedor 13', 'Calle 1011, croacia ', 66666666, 66666667);



Select * from proveedor

-- 13. Cree y mantenga registros que detallen las solicitudes de suministros para salas particulares (enfermera a cargo).



INSERT INTO solicitud (no_solicitud, no_sala, no_personal, fecha_solicitud, recibido_por, fecha_recepcion)
VALUES ('S18', '17', '3', '2023-11-07', 'Dr. L�pez', '2023-11-07'); 


-- 14. Un informe que enumere los detalles de los suministros proporcionados a salas espec�ficas (enfermero a cargo y director m�dico).



SELECT s.no_solicitud, s.no_sala, sa.Nombre_sala, s.no_personal, s.fecha_solicitud, s.recibido_por, s.fecha_recepcion, f.no_medicamento, m.nombre AS nombre_medicamento, f.dosis, f.costo_unidad, f.cantidad, f.id_metodo
FROM solicitud s
JOIN detalle_formulario f ON s.no_solicitud = f.no_solicitud
JOIN salas sa ON s.no_sala = sa.no_sala
JOIN medicamentos m ON f.no_medicamento = m.no_medicamento
WHERE s.no_sala = '7';
