create database PROYECTO
use PROYECTO;


/*Creacion de tablas*/
/*Fuertes*/

Create table parentesco (
	id_parentesco varchar(10) not null,
	nombre varchar(50) not null,
	apellido varchar(50) not null, 
	direccion varchar(80), 
	telefono numeric(8,0) not null,
	primary key(id_parentesco)
);

Create table clinicas(
	no_clinica varchar(10) not null,
	clinica varchar(70) not null,
	primary key (no_clinica)
);

Create table descripcion(
	codigo_descripcion numeric(10,0) not null,
	descripcion varchar(200) not null,
	primary key (codigo_descripcion)
);

select * from pacientes;

Create table pacientes (
	no_paciente numeric(10, 0) not null,
	nombre varchar(50) not null,
	apellido varchar(50) not null, 
	direccion varchar(80),
	fecha_nacimiento date not null, 
	fecha_registro date not null, 
	sexo varchar(20) not null,
	telefono numeric(8,0) not null,
	estado_civil varchar(20) not null,
	primary key(no_paciente)
);

Create table metodos_adminstracion(
	id_metodo varchar(10) not null,
	metodos varchar(30) not null,
	primary key (id_metodo)
);


Create table ubicaciones (
	id_ubicaciones varchar(10) not null,
	ubicaciones varchar(30),
	primary key (id_ubicaciones)
);




Create table Turnos (
id_turnos varchar(10) not null,
turnos varchar(30),
primary key(id_turnos)
);

create table instituciones(
id_institucion varchar(10) not null,
institucion varchar(30) not null,
primary key(id_institucion)
);


Create table Escala_Salariales(
	id_escala_salarial varchar(10) not null, 
	escala_salarial varchar(25), 
	primary key (id_escala_salarial)
);

Create table puestos(
	id_puesto varchar(10) not null,
	puesto varchar(100),
	primary key (id_puesto)
);


Create table Organizaciones(
	id_organizacion varchar(10) not null, 
	organizacion varchar(50) not  null, 
	primary key(id_organizacion)
); 



/*Debiles*/

Create table medico_local(
	id_medico_local numeric(4,0) not null,
	nombre varchar(50) not null,
	apellido varchar(50) not null,
	direccion varchar(100),
	telefono numeric(9,0),
	no_clinica varchar(10) not null,
	primary key (id_medico_local),
	foreign key (no_clinica) references clinicas
);

Create table medicamentos(
no_medicamento numeric (10,0) not null, 
nombre varchar(60) not null, 
codigo_descripcion numeric(10,0) not null,
primary key(no_medicamento),
foreign key(codigo_descripcion) references descripcion,
); 

Create table salas (
	no_sala numeric (10,0) not null,
	Nombre_sala varchar(30) not null,
	id_ubicaciones varchar(10) not null,
	telefono_extension numeric (10,0),
	no_cama numeric(10,0) not null,
primary key(no_sala),
foreign	key (id_ubicaciones) references ubicaciones
);


create table personal(
	No_personal numeric(10,0) not null,
	nombre varchar (30) not null,
	apellido varchar (30) not null,
	Direccion varchar (20),
	Sexo varchar (20),
	fecha_nacimiento date,
	telefono numeric(10,0),
	id_puesto varchar(10) not null,
	NSS varchar(15),
	horasXsemana varchar(20),
	salario_actual numeric(10,3),
	pago_semanal_mensual numeric (10,3),
	id_escala_salarial varchar(10),
	permanente_temporal varchar(10),
	id_turnos varchar(10),
	primary key (No_personal),	
	foreign key (id_puesto) references puestos,
	foreign key (id_escala_salarial) references Escala_Salariales,
	foreign key (id_turnos) references Turnos
);

Create table solicitud(
	no_solicitud varchar(20)  not null,
	no_sala numeric(10,0) not null,
	no_personal numeric(10,0) not null,
	fecha_solicitud date not null,
	recibido_por varchar(100) not null,
	fecha_recepcion date not null,
	primary key (no_solicitud),
	foreign key (no_sala) references salas, 
foreign key (no_personal) references personal
);


Create table Titulos(
	id_titulo varchar(20) not null,
	titulo varchar(100) not null,
	id_institucion varchar(10) not null,
	primary key (id_titulo),
foreign key (id_institucion) references instituciones 
);


/*Detalles*/

Create table experiencia_laboral (
	No_personal numeric(10,0) not null,
	id_organizacion varchar(10) not null, 
	id_puesto varchar(10) not null,
	inicio_laboral date not null, 
	fin_laboral date not null, 
	primary key(No_personal, id_organizacion, id_puesto),
	foreign key(No_personal) references personal, 
	foreign key(id_organizacion) references Organizaciones, 
	foreign key(id_puesto) references puestos
); 

Create table detalle_parentesco(
	no_paciente numeric(10, 0) not null,
	id_parentesco varchar(10) not null,
	parentesco varchar(100),
	primary key (no_paciente, id_parentesco),
	foreign key (no_paciente) references pacientes,
	foreign key (id_parentesco) references parentesco,
);

Create table detalle_titulo(
	No_personal numeric(10,0) not null,
	id_titulo varchar(20) not null,
	fecha date not null
	primary key(No_personal, id_titulo), 
	foreign key(No_personal) references personal, 
	foreign key(id_titulo) references Titulos
); 

Create table detalle_medico(
	no_paciente numeric(10, 0) not null,
	id_medico_local numeric(4,0) not null
	primary key (no_paciente, id_medico_local),
	foreign key (no_paciente) references pacientes,
	foreign key (id_medico_local) references medico_local

);


Create table detalle_formulario(
	no_solicitud varchar(20) not null,
	no_medicamento numeric(10,0) not null,
	dosis varchar(15) not null,
	costo_unidad numeric (10,0) not null,
	cantidad numeric (10,0) not null,
	id_metodo varchar(10) not null,
	primary key (no_solicitud, no_medicamento),
	foreign key (no_solicitud) references solicitud,
	foreign key (no_medicamento) references medicamentos,
	foreign key (id_metodo) references metodos_adminstracion
);

Create table detalle_paciente_sala(
	no_paciente numeric(10, 0) not null,
	no_sala numeric (10,0) not null,
	lista_espera date not null,
	espere_quedarse numeric(2) not null,
	fecha_salida date not null,
	fecha_real_salida date not null,
	no_cama numeric(10,0) not null,
	primary key (no_paciente, no_sala),
	foreign key (no_paciente) references pacientes,
	foreign key (no_sala) references salas
);


Create table detalle_personal_sala(
	No_personal numeric(10,0) not null,
	no_sala numeric(10,0) not null,
	primary key(No_personal, no_sala),
	foreign key(No_personal) references personal, 
	foreign key(no_sala) references salas

); 

create table detalle_medicamento(
	no_paciente numeric(10, 0) not null,
	no_medicamento numeric (10,0) not null, 
	fecha_comienzo date not null,
	unidades_por_dia numeric (3,0) not null,
	fehca_finalizar date not null,
	dosis numeric (3,0),
	id_metodo varchar(10) not null,
	primary key(no_paciente, no_medicamento, fecha_comienzo),
	foreign key (no_paciente) references pacientes,
	foreign key (no_medicamento) references medicamentos,
	foreign key(id_metodo) references  metodos_adminstracion
);

create table proveedor (
	no_proveedor varchar(10) not null, 
	nombre varchar(60) not null, 
	direccion varchar(80), 
	telefono numeric(8,0) not null, 
	numero_fax numeric(8,0), 
	primary key(no_proveedor)
);


/*Segunda Parte del query*/

create table usuarios(
username varchar(20),
contrase�a varchar(20),
primary key (username)
);

create table proveedor (
	no_proveedor varchar(10) not null, 
	nombre varchar(60) not null, 
	direccion varchar(80), 
	telefono numeric(8,0) not null, 
	numero_fax numeric(8,0), 
	primary key(no_proveedor)
);

alter table medicamentos add no_proveedor varchar(10) foreign key(no_proveedor) references proveedor;

INSERT INTO usuarios VALUES('Director Medico', 'director2023');

INSERT INTO usuarios VALUES('Oficial Personal','oficial2023');

INSERT INTO usuarios VALUES('Enfermera', 'enfermera2023');



