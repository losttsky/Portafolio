﻿namespace Clinica
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            tabControl1 = new TabControl();
            tabPage1 = new TabPage();
            label2 = new Label();
            btnBuscarPersonal = new Button();
            panel2 = new Panel();
            dgPersonal = new DataGridView();
            tabPage2 = new TabPage();
            panel3 = new Panel();
            tabControl2 = new TabControl();
            tabPage9 = new TabPage();
            label3 = new Label();
            btnMostrarCama = new Button();
            panel7 = new Panel();
            dgCamas = new DataGridView();
            tabPage12 = new TabPage();
            label9 = new Label();
            btnMostrarMedicna = new Button();
            panel10 = new Panel();
            dgMedicina = new DataGridView();
            tabPage3 = new TabPage();
            label4 = new Label();
            btnMostrarPacientes = new Button();
            panel4 = new Panel();
            dgPacientes = new DataGridView();
            tabPage4 = new TabPage();
            label5 = new Label();
            btnProveedores = new Button();
            panel5 = new Panel();
            dgProveedores = new DataGridView();
            tabPage10 = new TabPage();
            dgClinicas = new DataGridView();
            button2 = new Button();
            label7 = new Label();
            tabPage5 = new TabPage();
            label6 = new Label();
            btnMostarSalas = new Button();
            panel6 = new Panel();
            dgSalas = new DataGridView();
            tabPage6 = new TabPage();
            id_turnos = new TextBox();
            label11 = new Label();
            horasxsemana = new TextBox();
            label10 = new Label();
            tt_contrato = new ComboBox();
            btnIngresarPersonal = new Button();
            id_escala = new TextBox();
            label26 = new Label();
            label27 = new Label();
            label28 = new Label();
            telefono_personal = new TextBox();
            pago_semanal = new TextBox();
            label25 = new Label();
            salario_personal = new TextBox();
            label24 = new Label();
            id_puesto = new TextBox();
            label23 = new Label();
            nss = new TextBox();
            fecha_personal = new TextBox();
            direccion_personal = new TextBox();
            apellido_personal = new TextBox();
            nombre_personal = new TextBox();
            label14 = new Label();
            label15 = new Label();
            label16 = new Label();
            sexo_personal = new ComboBox();
            label17 = new Label();
            label18 = new Label();
            label19 = new Label();
            label20 = new Label();
            label21 = new Label();
            label22 = new Label();
            no_personal = new TextBox();
            tabPage7 = new TabPage();
            tabControl3 = new TabControl();
            tabPage13 = new TabPage();
            dg1 = new DataGridView();
            label29 = new Label();
            noSala = new TextBox();
            btn_agregarCama = new Button();
            tabPage16 = new TabPage();
            label12 = new Label();
            no_medicina = new TextBox();
            label30 = new Label();
            descripcion_medicina = new TextBox();
            label13 = new Label();
            nombre_medicina = new TextBox();
            btnAgregarMedicina = new Button();
            tabPage8 = new TabPage();
            button5 = new Button();
            label36 = new Label();
            label35 = new Label();
            txt_no_p = new TextBox();
            label34 = new Label();
            txt_fax = new TextBox();
            label33 = new Label();
            txt_telP = new TextBox();
            label32 = new Label();
            txt_direP = new TextBox();
            label8 = new Label();
            label31 = new Label();
            txt_nombreP = new TextBox();
            label1 = new Label();
            button1 = new Button();
            label37 = new Label();
            codigo_descripcion = new TextBox();
            panel1.SuspendLayout();
            tabControl1.SuspendLayout();
            tabPage1.SuspendLayout();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgPersonal).BeginInit();
            tabPage2.SuspendLayout();
            panel3.SuspendLayout();
            tabControl2.SuspendLayout();
            tabPage9.SuspendLayout();
            panel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgCamas).BeginInit();
            tabPage12.SuspendLayout();
            panel10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgMedicina).BeginInit();
            tabPage3.SuspendLayout();
            panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgPacientes).BeginInit();
            tabPage4.SuspendLayout();
            panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgProveedores).BeginInit();
            tabPage10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgClinicas).BeginInit();
            tabPage5.SuspendLayout();
            panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgSalas).BeginInit();
            tabPage6.SuspendLayout();
            tabPage7.SuspendLayout();
            tabControl3.SuspendLayout();
            tabPage13.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dg1).BeginInit();
            tabPage16.SuspendLayout();
            tabPage8.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(18, 64, 119);
            panel1.Controls.Add(tabControl1);
            panel1.Location = new Point(73, 89);
            panel1.Name = "panel1";
            panel1.Size = new Size(873, 430);
            panel1.TabIndex = 0;
            // 
            // tabControl1
            // 
            tabControl1.Controls.Add(tabPage1);
            tabControl1.Controls.Add(tabPage2);
            tabControl1.Controls.Add(tabPage3);
            tabControl1.Controls.Add(tabPage4);
            tabControl1.Controls.Add(tabPage10);
            tabControl1.Controls.Add(tabPage5);
            tabControl1.Controls.Add(tabPage6);
            tabControl1.Controls.Add(tabPage7);
            tabControl1.Controls.Add(tabPage8);
            tabControl1.Dock = DockStyle.Fill;
            tabControl1.Location = new Point(0, 0);
            tabControl1.Name = "tabControl1";
            tabControl1.SelectedIndex = 0;
            tabControl1.Size = new Size(873, 430);
            tabControl1.TabIndex = 8;
            // 
            // tabPage1
            // 
            tabPage1.BackColor = Color.FromArgb(18, 64, 119);
            tabPage1.Controls.Add(label2);
            tabPage1.Controls.Add(btnBuscarPersonal);
            tabPage1.Controls.Add(panel2);
            tabPage1.Location = new Point(4, 24);
            tabPage1.Name = "tabPage1";
            tabPage1.Padding = new Padding(3);
            tabPage1.Size = new Size(865, 402);
            tabPage1.TabIndex = 0;
            tabPage1.Text = "Personal";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Rockwell", 27.75F, FontStyle.Regular, GraphicsUnit.Point);
            label2.ForeColor = Color.FromArgb(249, 247, 247);
            label2.Location = new Point(466, 78);
            label2.Name = "label2";
            label2.Size = new Size(357, 84);
            label2.TabIndex = 35;
            label2.Text = "Mostrar el personal \r\nexistente\r\n";
            // 
            // btnBuscarPersonal
            // 
            btnBuscarPersonal.BackColor = Color.FromArgb(17, 45, 78);
            btnBuscarPersonal.FlatAppearance.BorderColor = Color.FromArgb(249, 247, 247);
            btnBuscarPersonal.FlatAppearance.BorderSize = 2;
            btnBuscarPersonal.FlatAppearance.MouseDownBackColor = Color.FromArgb(18, 81, 157);
            btnBuscarPersonal.FlatStyle = FlatStyle.Flat;
            btnBuscarPersonal.Font = new Font("Rockwell", 15F, FontStyle.Regular, GraphicsUnit.Point);
            btnBuscarPersonal.ForeColor = Color.FromArgb(249, 247, 247);
            btnBuscarPersonal.Location = new Point(582, 217);
            btnBuscarPersonal.Margin = new Padding(3, 2, 3, 2);
            btnBuscarPersonal.Name = "btnBuscarPersonal";
            btnBuscarPersonal.Size = new Size(156, 75);
            btnBuscarPersonal.TabIndex = 34;
            btnBuscarPersonal.Text = "Mostrar Personal ";
            btnBuscarPersonal.UseVisualStyleBackColor = false;
            btnBuscarPersonal.Click += MostrarPersonal;
            // 
            // panel2
            // 
            panel2.Controls.Add(dgPersonal);
            panel2.Dock = DockStyle.Left;
            panel2.Location = new Point(3, 3);
            panel2.Name = "panel2";
            panel2.Size = new Size(458, 396);
            panel2.TabIndex = 0;
            // 
            // dgPersonal
            // 
            dgPersonal.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgPersonal.Dock = DockStyle.Fill;
            dgPersonal.Location = new Point(0, 0);
            dgPersonal.Name = "dgPersonal";
            dgPersonal.RowHeadersWidth = 51;
            dgPersonal.RowTemplate.Height = 25;
            dgPersonal.Size = new Size(458, 396);
            dgPersonal.TabIndex = 0;
            // 
            // tabPage2
            // 
            tabPage2.BackColor = Color.FromArgb(18, 64, 119);
            tabPage2.Controls.Add(panel3);
            tabPage2.Location = new Point(4, 24);
            tabPage2.Name = "tabPage2";
            tabPage2.Padding = new Padding(3);
            tabPage2.Size = new Size(865, 402);
            tabPage2.TabIndex = 1;
            tabPage2.Text = "Suministros";
            // 
            // panel3
            // 
            panel3.Controls.Add(tabControl2);
            panel3.Dock = DockStyle.Fill;
            panel3.Location = new Point(3, 3);
            panel3.Name = "panel3";
            panel3.Size = new Size(859, 396);
            panel3.TabIndex = 0;
            // 
            // tabControl2
            // 
            tabControl2.Controls.Add(tabPage9);
            tabControl2.Controls.Add(tabPage12);
            tabControl2.Dock = DockStyle.Fill;
            tabControl2.Location = new Point(0, 0);
            tabControl2.Name = "tabControl2";
            tabControl2.SelectedIndex = 0;
            tabControl2.Size = new Size(859, 396);
            tabControl2.TabIndex = 0;
            // 
            // tabPage9
            // 
            tabPage9.BackColor = Color.FromArgb(18, 64, 119);
            tabPage9.Controls.Add(label3);
            tabPage9.Controls.Add(btnMostrarCama);
            tabPage9.Controls.Add(panel7);
            tabPage9.Location = new Point(4, 24);
            tabPage9.Name = "tabPage9";
            tabPage9.Padding = new Padding(3);
            tabPage9.Size = new Size(851, 368);
            tabPage9.TabIndex = 0;
            tabPage9.Text = "Camas";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Rockwell", 27.75F, FontStyle.Regular, GraphicsUnit.Point);
            label3.ForeColor = Color.FromArgb(249, 247, 247);
            label3.Location = new Point(487, 105);
            label3.Name = "label3";
            label3.Size = new Size(290, 84);
            label3.TabIndex = 38;
            label3.Text = "Mostrar lista de \r\ncamas";
            // 
            // btnMostrarCama
            // 
            btnMostrarCama.BackColor = Color.FromArgb(17, 45, 78);
            btnMostrarCama.FlatAppearance.BorderColor = Color.FromArgb(249, 247, 247);
            btnMostrarCama.FlatAppearance.BorderSize = 2;
            btnMostrarCama.FlatAppearance.MouseDownBackColor = Color.FromArgb(18, 81, 157);
            btnMostrarCama.FlatStyle = FlatStyle.Flat;
            btnMostrarCama.Font = new Font("Rockwell", 15F, FontStyle.Regular, GraphicsUnit.Point);
            btnMostrarCama.ForeColor = Color.FromArgb(249, 247, 247);
            btnMostrarCama.Location = new Point(596, 240);
            btnMostrarCama.Margin = new Padding(3, 2, 3, 2);
            btnMostrarCama.Name = "btnMostrarCama";
            btnMostrarCama.Size = new Size(156, 75);
            btnMostrarCama.TabIndex = 37;
            btnMostrarCama.Text = "Mostrar Suministro";
            btnMostrarCama.UseVisualStyleBackColor = false;
            btnMostrarCama.Click += MostrarCama;
            // 
            // panel7
            // 
            panel7.Controls.Add(dgCamas);
            panel7.Dock = DockStyle.Left;
            panel7.Location = new Point(3, 3);
            panel7.Name = "panel7";
            panel7.Size = new Size(458, 362);
            panel7.TabIndex = 36;
            // 
            // dgCamas
            // 
            dgCamas.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgCamas.Dock = DockStyle.Fill;
            dgCamas.Location = new Point(0, 0);
            dgCamas.Name = "dgCamas";
            dgCamas.RowHeadersWidth = 51;
            dgCamas.RowTemplate.Height = 25;
            dgCamas.Size = new Size(458, 362);
            dgCamas.TabIndex = 0;
            // 
            // tabPage12
            // 
            tabPage12.BackColor = Color.FromArgb(18, 64, 119);
            tabPage12.Controls.Add(label9);
            tabPage12.Controls.Add(btnMostrarMedicna);
            tabPage12.Controls.Add(panel10);
            tabPage12.Location = new Point(4, 24);
            tabPage12.Name = "tabPage12";
            tabPage12.Size = new Size(851, 368);
            tabPage12.TabIndex = 3;
            tabPage12.Text = "Medicinas";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Rockwell", 27.75F, FontStyle.Regular, GraphicsUnit.Point);
            label9.ForeColor = Color.FromArgb(249, 247, 247);
            label9.Location = new Point(504, 66);
            label9.Name = "label9";
            label9.Size = new Size(290, 84);
            label9.TabIndex = 47;
            label9.Text = "Mostrar lista de \r\nmedicamentos";
            // 
            // btnMostrarMedicna
            // 
            btnMostrarMedicna.BackColor = Color.FromArgb(17, 45, 78);
            btnMostrarMedicna.FlatAppearance.BorderColor = Color.FromArgb(249, 247, 247);
            btnMostrarMedicna.FlatAppearance.BorderSize = 2;
            btnMostrarMedicna.FlatAppearance.MouseDownBackColor = Color.FromArgb(18, 81, 157);
            btnMostrarMedicna.FlatStyle = FlatStyle.Flat;
            btnMostrarMedicna.Font = new Font("Rockwell", 15F, FontStyle.Regular, GraphicsUnit.Point);
            btnMostrarMedicna.ForeColor = Color.FromArgb(249, 247, 247);
            btnMostrarMedicna.Location = new Point(579, 178);
            btnMostrarMedicna.Margin = new Padding(3, 2, 3, 2);
            btnMostrarMedicna.Name = "btnMostrarMedicna";
            btnMostrarMedicna.Size = new Size(156, 75);
            btnMostrarMedicna.TabIndex = 46;
            btnMostrarMedicna.Text = "Mostrar Suministro";
            btnMostrarMedicna.UseVisualStyleBackColor = false;
            btnMostrarMedicna.Click += MostrarMedicina;
            // 
            // panel10
            // 
            panel10.Controls.Add(dgMedicina);
            panel10.Dock = DockStyle.Left;
            panel10.Location = new Point(0, 0);
            panel10.Name = "panel10";
            panel10.Size = new Size(458, 368);
            panel10.TabIndex = 45;
            // 
            // dgMedicina
            // 
            dgMedicina.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgMedicina.Dock = DockStyle.Fill;
            dgMedicina.Location = new Point(0, 0);
            dgMedicina.Name = "dgMedicina";
            dgMedicina.RowHeadersWidth = 51;
            dgMedicina.RowTemplate.Height = 25;
            dgMedicina.Size = new Size(458, 368);
            dgMedicina.TabIndex = 0;
            // 
            // tabPage3
            // 
            tabPage3.BackColor = Color.FromArgb(18, 64, 119);
            tabPage3.Controls.Add(label4);
            tabPage3.Controls.Add(btnMostrarPacientes);
            tabPage3.Controls.Add(panel4);
            tabPage3.Location = new Point(4, 24);
            tabPage3.Name = "tabPage3";
            tabPage3.Size = new Size(865, 402);
            tabPage3.TabIndex = 2;
            tabPage3.Text = "Pacientes";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Rockwell", 27.75F, FontStyle.Regular, GraphicsUnit.Point);
            label4.ForeColor = Color.FromArgb(249, 247, 247);
            label4.Location = new Point(495, 66);
            label4.Name = "label4";
            label4.Size = new Size(290, 84);
            label4.TabIndex = 41;
            label4.Text = "Mostrar lista de \r\npacientes";
            // 
            // btnMostrarPacientes
            // 
            btnMostrarPacientes.BackColor = Color.FromArgb(17, 45, 78);
            btnMostrarPacientes.FlatAppearance.BorderColor = Color.FromArgb(249, 247, 247);
            btnMostrarPacientes.FlatAppearance.BorderSize = 2;
            btnMostrarPacientes.FlatAppearance.MouseDownBackColor = Color.FromArgb(18, 81, 157);
            btnMostrarPacientes.FlatStyle = FlatStyle.Flat;
            btnMostrarPacientes.Font = new Font("Rockwell", 15F, FontStyle.Regular, GraphicsUnit.Point);
            btnMostrarPacientes.ForeColor = Color.FromArgb(249, 247, 247);
            btnMostrarPacientes.Location = new Point(590, 204);
            btnMostrarPacientes.Margin = new Padding(3, 2, 3, 2);
            btnMostrarPacientes.Name = "btnMostrarPacientes";
            btnMostrarPacientes.Size = new Size(156, 75);
            btnMostrarPacientes.TabIndex = 40;
            btnMostrarPacientes.Text = "Mostrar Pacientes";
            btnMostrarPacientes.UseVisualStyleBackColor = false;
            btnMostrarPacientes.Click += MostarPacientes;
            // 
            // panel4
            // 
            panel4.Controls.Add(dgPacientes);
            panel4.Dock = DockStyle.Left;
            panel4.Location = new Point(0, 0);
            panel4.Name = "panel4";
            panel4.Size = new Size(458, 402);
            panel4.TabIndex = 39;
            // 
            // dgPacientes
            // 
            dgPacientes.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgPacientes.Dock = DockStyle.Fill;
            dgPacientes.Location = new Point(0, 0);
            dgPacientes.Name = "dgPacientes";
            dgPacientes.RowHeadersWidth = 51;
            dgPacientes.RowTemplate.Height = 25;
            dgPacientes.Size = new Size(458, 402);
            dgPacientes.TabIndex = 0;
            // 
            // tabPage4
            // 
            tabPage4.BackColor = Color.FromArgb(18, 64, 119);
            tabPage4.Controls.Add(label5);
            tabPage4.Controls.Add(btnProveedores);
            tabPage4.Controls.Add(panel5);
            tabPage4.Location = new Point(4, 24);
            tabPage4.Name = "tabPage4";
            tabPage4.Size = new Size(865, 402);
            tabPage4.TabIndex = 3;
            tabPage4.Text = "Proveedores";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Rockwell", 27.75F, FontStyle.Regular, GraphicsUnit.Point);
            label5.ForeColor = Color.FromArgb(249, 247, 247);
            label5.Location = new Point(494, 64);
            label5.Name = "label5";
            label5.Size = new Size(290, 84);
            label5.TabIndex = 44;
            label5.Text = "Mostrar lista de \r\nproveedores\r\n";
            // 
            // btnProveedores
            // 
            btnProveedores.BackColor = Color.FromArgb(17, 45, 78);
            btnProveedores.FlatAppearance.BorderColor = Color.FromArgb(249, 247, 247);
            btnProveedores.FlatAppearance.BorderSize = 2;
            btnProveedores.FlatAppearance.MouseDownBackColor = Color.FromArgb(18, 81, 157);
            btnProveedores.FlatStyle = FlatStyle.Flat;
            btnProveedores.Font = new Font("Rockwell", 15F, FontStyle.Regular, GraphicsUnit.Point);
            btnProveedores.ForeColor = Color.FromArgb(249, 247, 247);
            btnProveedores.Location = new Point(577, 189);
            btnProveedores.Margin = new Padding(3, 2, 3, 2);
            btnProveedores.Name = "btnProveedores";
            btnProveedores.Size = new Size(156, 75);
            btnProveedores.TabIndex = 43;
            btnProveedores.Text = "Mostrar Proveedores";
            btnProveedores.UseVisualStyleBackColor = false;
            btnProveedores.Click += MostrarProveedores;
            // 
            // panel5
            // 
            panel5.Controls.Add(dgProveedores);
            panel5.Dock = DockStyle.Left;
            panel5.Location = new Point(0, 0);
            panel5.Name = "panel5";
            panel5.Size = new Size(458, 402);
            panel5.TabIndex = 42;
            // 
            // dgProveedores
            // 
            dgProveedores.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgProveedores.Dock = DockStyle.Fill;
            dgProveedores.Location = new Point(0, 0);
            dgProveedores.Name = "dgProveedores";
            dgProveedores.RowHeadersWidth = 51;
            dgProveedores.RowTemplate.Height = 25;
            dgProveedores.Size = new Size(458, 402);
            dgProveedores.TabIndex = 0;
            // 
            // tabPage10
            // 
            tabPage10.BackColor = Color.FromArgb(18, 64, 119);
            tabPage10.Controls.Add(dgClinicas);
            tabPage10.Controls.Add(button2);
            tabPage10.Controls.Add(label7);
            tabPage10.ForeColor = SystemColors.ControlText;
            tabPage10.Location = new Point(4, 24);
            tabPage10.Name = "tabPage10";
            tabPage10.Size = new Size(865, 402);
            tabPage10.TabIndex = 8;
            tabPage10.Text = "Clinicas";
            // 
            // dgClinicas
            // 
            dgClinicas.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgClinicas.Dock = DockStyle.Left;
            dgClinicas.Location = new Point(0, 0);
            dgClinicas.Name = "dgClinicas";
            dgClinicas.RowHeadersWidth = 51;
            dgClinicas.RowTemplate.Height = 25;
            dgClinicas.Size = new Size(492, 402);
            dgClinicas.TabIndex = 50;
            // 
            // button2
            // 
            button2.BackColor = Color.FromArgb(17, 45, 78);
            button2.FlatAppearance.BorderColor = Color.FromArgb(249, 247, 247);
            button2.FlatAppearance.BorderSize = 2;
            button2.FlatAppearance.MouseDownBackColor = Color.FromArgb(18, 81, 157);
            button2.FlatStyle = FlatStyle.Flat;
            button2.Font = new Font("Rockwell", 15F, FontStyle.Regular, GraphicsUnit.Point);
            button2.ForeColor = Color.FromArgb(249, 247, 247);
            button2.Location = new Point(605, 190);
            button2.Margin = new Padding(3, 2, 3, 2);
            button2.Name = "button2";
            button2.Size = new Size(156, 75);
            button2.TabIndex = 49;
            button2.Text = "Mostrar Clinicas";
            button2.UseVisualStyleBackColor = false;
            button2.Click += mostrar_clinicas;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Rockwell", 27.75F, FontStyle.Regular, GraphicsUnit.Point);
            label7.ForeColor = Color.FromArgb(249, 247, 247);
            label7.Location = new Point(528, 51);
            label7.Name = "label7";
            label7.Size = new Size(290, 84);
            label7.TabIndex = 48;
            label7.Text = "Mostrar lista de \r\nclinicas";
            // 
            // tabPage5
            // 
            tabPage5.BackColor = Color.FromArgb(18, 64, 119);
            tabPage5.Controls.Add(label6);
            tabPage5.Controls.Add(btnMostarSalas);
            tabPage5.Controls.Add(panel6);
            tabPage5.Location = new Point(4, 24);
            tabPage5.Name = "tabPage5";
            tabPage5.Size = new Size(865, 402);
            tabPage5.TabIndex = 4;
            tabPage5.Text = "Salas";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Rockwell", 27.75F, FontStyle.Regular, GraphicsUnit.Point);
            label6.ForeColor = Color.FromArgb(249, 247, 247);
            label6.Location = new Point(497, 66);
            label6.Name = "label6";
            label6.Size = new Size(290, 84);
            label6.TabIndex = 47;
            label6.Text = "Mostrar lista de \r\nsalas";
            // 
            // btnMostarSalas
            // 
            btnMostarSalas.BackColor = Color.FromArgb(17, 45, 78);
            btnMostarSalas.FlatAppearance.BorderColor = Color.FromArgb(249, 247, 247);
            btnMostarSalas.FlatAppearance.BorderSize = 2;
            btnMostarSalas.FlatAppearance.MouseDownBackColor = Color.FromArgb(18, 81, 157);
            btnMostarSalas.FlatStyle = FlatStyle.Flat;
            btnMostarSalas.Font = new Font("Rockwell", 15F, FontStyle.Regular, GraphicsUnit.Point);
            btnMostarSalas.ForeColor = Color.FromArgb(249, 247, 247);
            btnMostarSalas.Location = new Point(579, 205);
            btnMostarSalas.Margin = new Padding(3, 2, 3, 2);
            btnMostarSalas.Name = "btnMostarSalas";
            btnMostarSalas.Size = new Size(156, 75);
            btnMostarSalas.TabIndex = 46;
            btnMostarSalas.Text = "Mostrar Salas";
            btnMostarSalas.UseVisualStyleBackColor = false;
            btnMostarSalas.Click += MostarSalas;
            // 
            // panel6
            // 
            panel6.Controls.Add(dgSalas);
            panel6.Dock = DockStyle.Left;
            panel6.Location = new Point(0, 0);
            panel6.Name = "panel6";
            panel6.Size = new Size(458, 402);
            panel6.TabIndex = 45;
            // 
            // dgSalas
            // 
            dgSalas.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgSalas.Dock = DockStyle.Fill;
            dgSalas.Location = new Point(0, 0);
            dgSalas.Name = "dgSalas";
            dgSalas.RowHeadersWidth = 51;
            dgSalas.RowTemplate.Height = 25;
            dgSalas.Size = new Size(458, 402);
            dgSalas.TabIndex = 0;
            // 
            // tabPage6
            // 
            tabPage6.BackColor = Color.FromArgb(18, 64, 119);
            tabPage6.Controls.Add(id_turnos);
            tabPage6.Controls.Add(label11);
            tabPage6.Controls.Add(horasxsemana);
            tabPage6.Controls.Add(label10);
            tabPage6.Controls.Add(tt_contrato);
            tabPage6.Controls.Add(btnIngresarPersonal);
            tabPage6.Controls.Add(id_escala);
            tabPage6.Controls.Add(label26);
            tabPage6.Controls.Add(label27);
            tabPage6.Controls.Add(label28);
            tabPage6.Controls.Add(telefono_personal);
            tabPage6.Controls.Add(pago_semanal);
            tabPage6.Controls.Add(label25);
            tabPage6.Controls.Add(salario_personal);
            tabPage6.Controls.Add(label24);
            tabPage6.Controls.Add(id_puesto);
            tabPage6.Controls.Add(label23);
            tabPage6.Controls.Add(nss);
            tabPage6.Controls.Add(fecha_personal);
            tabPage6.Controls.Add(direccion_personal);
            tabPage6.Controls.Add(apellido_personal);
            tabPage6.Controls.Add(nombre_personal);
            tabPage6.Controls.Add(label14);
            tabPage6.Controls.Add(label15);
            tabPage6.Controls.Add(label16);
            tabPage6.Controls.Add(sexo_personal);
            tabPage6.Controls.Add(label17);
            tabPage6.Controls.Add(label18);
            tabPage6.Controls.Add(label19);
            tabPage6.Controls.Add(label20);
            tabPage6.Controls.Add(label21);
            tabPage6.Controls.Add(label22);
            tabPage6.Controls.Add(no_personal);
            tabPage6.Location = new Point(4, 24);
            tabPage6.Name = "tabPage6";
            tabPage6.Size = new Size(865, 402);
            tabPage6.TabIndex = 5;
            tabPage6.Text = "AgregarPersonal";
            // 
            // id_turnos
            // 
            id_turnos.BackColor = Color.FromArgb(249, 247, 247);
            id_turnos.Font = new Font("Rockwell", 20F, FontStyle.Regular, GraphicsUnit.Point);
            id_turnos.Location = new Point(687, 227);
            id_turnos.Margin = new Padding(3, 2, 3, 2);
            id_turnos.Name = "id_turnos";
            id_turnos.Size = new Size(152, 39);
            id_turnos.TabIndex = 68;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Rockwell", 15F, FontStyle.Regular, GraphicsUnit.Point);
            label11.ForeColor = Color.FromArgb(249, 247, 247);
            label11.Location = new Point(687, 193);
            label11.Name = "label11";
            label11.Size = new Size(95, 22);
            label11.TabIndex = 69;
            label11.Text = "Id Turnos";
            // 
            // horasxsemana
            // 
            horasxsemana.BackColor = Color.FromArgb(249, 247, 247);
            horasxsemana.Font = new Font("Rockwell", 20F, FontStyle.Regular, GraphicsUnit.Point);
            horasxsemana.Location = new Point(481, 136);
            horasxsemana.Margin = new Padding(3, 2, 3, 2);
            horasxsemana.Name = "horasxsemana";
            horasxsemana.Size = new Size(152, 39);
            horasxsemana.TabIndex = 66;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Rockwell", 15F, FontStyle.Regular, GraphicsUnit.Point);
            label10.ForeColor = Color.FromArgb(249, 247, 247);
            label10.Location = new Point(481, 105);
            label10.Name = "label10";
            label10.Size = new Size(156, 22);
            label10.TabIndex = 67;
            label10.Text = "Horas x Semana";
            // 
            // tt_contrato
            // 
            tt_contrato.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            tt_contrato.FormattingEnabled = true;
            tt_contrato.Items.AddRange(new object[] { "Temporal", "Permanente" });
            tt_contrato.Location = new Point(687, 141);
            tt_contrato.Name = "tt_contrato";
            tt_contrato.Size = new Size(161, 33);
            tt_contrato.TabIndex = 65;
            tt_contrato.Text = "Ingrese una opcion";
            // 
            // btnIngresarPersonal
            // 
            btnIngresarPersonal.BackColor = Color.FromArgb(17, 45, 78);
            btnIngresarPersonal.FlatAppearance.BorderColor = Color.FromArgb(249, 247, 247);
            btnIngresarPersonal.FlatAppearance.BorderSize = 2;
            btnIngresarPersonal.FlatAppearance.MouseDownBackColor = Color.FromArgb(18, 81, 157);
            btnIngresarPersonal.FlatStyle = FlatStyle.Flat;
            btnIngresarPersonal.Font = new Font("Rockwell", 15F, FontStyle.Regular, GraphicsUnit.Point);
            btnIngresarPersonal.ForeColor = Color.FromArgb(249, 247, 247);
            btnIngresarPersonal.Location = new Point(687, 312);
            btnIngresarPersonal.Margin = new Padding(3, 2, 3, 2);
            btnIngresarPersonal.Name = "btnIngresarPersonal";
            btnIngresarPersonal.Size = new Size(152, 60);
            btnIngresarPersonal.TabIndex = 64;
            btnIngresarPersonal.Text = "Ingresar Personal";
            btnIngresarPersonal.UseVisualStyleBackColor = false;
            btnIngresarPersonal.Click += btnIngresarPersonal_Click;
            // 
            // id_escala
            // 
            id_escala.BackColor = Color.FromArgb(249, 247, 247);
            id_escala.Font = new Font("Rockwell", 20F, FontStyle.Regular, GraphicsUnit.Point);
            id_escala.Location = new Point(687, 48);
            id_escala.Margin = new Padding(3, 2, 3, 2);
            id_escala.Name = "id_escala";
            id_escala.Size = new Size(152, 39);
            id_escala.TabIndex = 59;
            // 
            // label26
            // 
            label26.AutoSize = true;
            label26.Font = new Font("Rockwell", 15F, FontStyle.Regular, GraphicsUnit.Point);
            label26.ForeColor = Color.FromArgb(249, 247, 247);
            label26.Location = new Point(821, 170);
            label26.Name = "label26";
            label26.Size = new Size(0, 22);
            label26.TabIndex = 63;
            // 
            // label27
            // 
            label27.AutoSize = true;
            label27.Font = new Font("Rockwell", 15F, FontStyle.Regular, GraphicsUnit.Point);
            label27.ForeColor = Color.FromArgb(249, 247, 247);
            label27.Location = new Point(687, 105);
            label27.Name = "label27";
            label27.Size = new Size(135, 22);
            label27.TabIndex = 62;
            label27.Text = "Tipo Contrato";
            // 
            // label28
            // 
            label28.AutoSize = true;
            label28.Font = new Font("Rockwell", 15F, FontStyle.Regular, GraphicsUnit.Point);
            label28.ForeColor = Color.FromArgb(249, 247, 247);
            label28.Location = new Point(687, 14);
            label28.Name = "label28";
            label28.Size = new Size(169, 22);
            label28.TabIndex = 61;
            label28.Text = "Id Escala Salarial";
            // 
            // telefono_personal
            // 
            telefono_personal.BackColor = Color.FromArgb(249, 247, 247);
            telefono_personal.Font = new Font("Rockwell", 20F, FontStyle.Regular, GraphicsUnit.Point);
            telefono_personal.Location = new Point(247, 224);
            telefono_personal.Margin = new Padding(3, 2, 3, 2);
            telefono_personal.Name = "telefono_personal";
            telefono_personal.Size = new Size(152, 39);
            telefono_personal.TabIndex = 58;
            // 
            // pago_semanal
            // 
            pago_semanal.BackColor = Color.FromArgb(249, 247, 247);
            pago_semanal.Font = new Font("Rockwell", 20F, FontStyle.Regular, GraphicsUnit.Point);
            pago_semanal.Location = new Point(481, 321);
            pago_semanal.Margin = new Padding(3, 2, 3, 2);
            pago_semanal.Name = "pago_semanal";
            pago_semanal.Size = new Size(152, 39);
            pago_semanal.TabIndex = 56;
            // 
            // label25
            // 
            label25.AutoSize = true;
            label25.Font = new Font("Rockwell", 15F, FontStyle.Regular, GraphicsUnit.Point);
            label25.ForeColor = Color.FromArgb(249, 247, 247);
            label25.Location = new Point(481, 290);
            label25.Name = "label25";
            label25.Size = new Size(139, 22);
            label25.TabIndex = 57;
            label25.Text = "Pago Semanal";
            // 
            // salario_personal
            // 
            salario_personal.BackColor = Color.FromArgb(249, 247, 247);
            salario_personal.Font = new Font("Rockwell", 20F, FontStyle.Regular, GraphicsUnit.Point);
            salario_personal.Location = new Point(481, 224);
            salario_personal.Margin = new Padding(3, 2, 3, 2);
            salario_personal.Name = "salario_personal";
            salario_personal.Size = new Size(152, 39);
            salario_personal.TabIndex = 54;
            // 
            // label24
            // 
            label24.AutoSize = true;
            label24.Font = new Font("Rockwell", 15F, FontStyle.Regular, GraphicsUnit.Point);
            label24.ForeColor = Color.FromArgb(249, 247, 247);
            label24.Location = new Point(481, 193);
            label24.Name = "label24";
            label24.Size = new Size(74, 22);
            label24.TabIndex = 55;
            label24.Text = "Salario";
            // 
            // id_puesto
            // 
            id_puesto.BackColor = Color.FromArgb(249, 247, 247);
            id_puesto.Font = new Font("Rockwell", 20F, FontStyle.Regular, GraphicsUnit.Point);
            id_puesto.Location = new Point(247, 321);
            id_puesto.Margin = new Padding(3, 2, 3, 2);
            id_puesto.Name = "id_puesto";
            id_puesto.Size = new Size(152, 39);
            id_puesto.TabIndex = 52;
            // 
            // label23
            // 
            label23.AutoSize = true;
            label23.Font = new Font("Rockwell", 15F, FontStyle.Regular, GraphicsUnit.Point);
            label23.ForeColor = Color.FromArgb(249, 247, 247);
            label23.Location = new Point(247, 290);
            label23.Name = "label23";
            label23.Size = new Size(93, 22);
            label23.TabIndex = 53;
            label23.Text = "Id Puesto";
            // 
            // nss
            // 
            nss.BackColor = Color.FromArgb(249, 247, 247);
            nss.Font = new Font("Rockwell", 20F, FontStyle.Regular, GraphicsUnit.Point);
            nss.Location = new Point(481, 48);
            nss.Margin = new Padding(3, 2, 3, 2);
            nss.Name = "nss";
            nss.Size = new Size(152, 39);
            nss.TabIndex = 40;
            // 
            // fecha_personal
            // 
            fecha_personal.BackColor = Color.FromArgb(249, 247, 247);
            fecha_personal.Font = new Font("Rockwell", 20F, FontStyle.Regular, GraphicsUnit.Point);
            fecha_personal.Location = new Point(247, 136);
            fecha_personal.Margin = new Padding(3, 2, 3, 2);
            fecha_personal.Name = "fecha_personal";
            fecha_personal.Size = new Size(152, 39);
            fecha_personal.TabIndex = 37;
            fecha_personal.Text = "aaaa-mm-dd";
            // 
            // direccion_personal
            // 
            direccion_personal.BackColor = Color.FromArgb(249, 247, 247);
            direccion_personal.Font = new Font("Rockwell", 20F, FontStyle.Regular, GraphicsUnit.Point);
            direccion_personal.Location = new Point(12, 324);
            direccion_personal.Margin = new Padding(3, 2, 3, 2);
            direccion_personal.Name = "direccion_personal";
            direccion_personal.Size = new Size(152, 39);
            direccion_personal.TabIndex = 35;
            // 
            // apellido_personal
            // 
            apellido_personal.BackColor = Color.FromArgb(249, 247, 247);
            apellido_personal.Font = new Font("Rockwell", 20F, FontStyle.Regular, GraphicsUnit.Point);
            apellido_personal.Location = new Point(12, 224);
            apellido_personal.Margin = new Padding(3, 2, 3, 2);
            apellido_personal.Name = "apellido_personal";
            apellido_personal.Size = new Size(152, 39);
            apellido_personal.TabIndex = 33;
            // 
            // nombre_personal
            // 
            nombre_personal.BackColor = Color.FromArgb(249, 247, 247);
            nombre_personal.Font = new Font("Rockwell", 20F, FontStyle.Regular, GraphicsUnit.Point);
            nombre_personal.Location = new Point(12, 136);
            nombre_personal.Margin = new Padding(3, 2, 3, 2);
            nombre_personal.Name = "nombre_personal";
            nombre_personal.Size = new Size(152, 39);
            nombre_personal.TabIndex = 32;
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Font = new Font("Rockwell", 15F, FontStyle.Regular, GraphicsUnit.Point);
            label14.ForeColor = Color.FromArgb(249, 247, 247);
            label14.Location = new Point(399, 170);
            label14.Name = "label14";
            label14.Size = new Size(0, 22);
            label14.TabIndex = 49;
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Font = new Font("Rockwell", 15F, FontStyle.Regular, GraphicsUnit.Point);
            label15.ForeColor = Color.FromArgb(249, 247, 247);
            label15.Location = new Point(247, 193);
            label15.Name = "label15";
            label15.Size = new Size(88, 22);
            label15.TabIndex = 48;
            label15.Text = "Telefono";
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Font = new Font("Rockwell", 15F, FontStyle.Regular, GraphicsUnit.Point);
            label16.ForeColor = Color.FromArgb(249, 247, 247);
            label16.Location = new Point(12, 193);
            label16.Name = "label16";
            label16.Size = new Size(90, 22);
            label16.TabIndex = 47;
            label16.Text = "Apellido";
            // 
            // sexo_personal
            // 
            sexo_personal.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            sexo_personal.FormattingEnabled = true;
            sexo_personal.Items.AddRange(new object[] { "Masculino", "Femenino" });
            sexo_personal.Location = new Point(247, 45);
            sexo_personal.Name = "sexo_personal";
            sexo_personal.Size = new Size(143, 33);
            sexo_personal.TabIndex = 41;
            sexo_personal.Text = "Ingrese una opcion";
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.Font = new Font("Rockwell", 15F, FontStyle.Regular, GraphicsUnit.Point);
            label17.ForeColor = Color.FromArgb(249, 247, 247);
            label17.Location = new Point(247, 14);
            label17.Name = "label17";
            label17.Size = new Size(54, 22);
            label17.TabIndex = 46;
            label17.Text = "Sexo";
            // 
            // label18
            // 
            label18.AutoSize = true;
            label18.Font = new Font("Rockwell", 15F, FontStyle.Regular, GraphicsUnit.Point);
            label18.ForeColor = Color.FromArgb(249, 247, 247);
            label18.Location = new Point(481, 14);
            label18.Name = "label18";
            label18.Size = new Size(46, 22);
            label18.TabIndex = 44;
            label18.Text = "NSS";
            // 
            // label19
            // 
            label19.AutoSize = true;
            label19.Font = new Font("Rockwell", 15F, FontStyle.Regular, GraphicsUnit.Point);
            label19.ForeColor = Color.FromArgb(249, 247, 247);
            label19.Location = new Point(247, 105);
            label19.Name = "label19";
            label19.Size = new Size(172, 22);
            label19.TabIndex = 42;
            label19.Text = "Fecha Nacimiento";
            // 
            // label20
            // 
            label20.AutoSize = true;
            label20.Font = new Font("Rockwell", 15F, FontStyle.Regular, GraphicsUnit.Point);
            label20.ForeColor = Color.FromArgb(249, 247, 247);
            label20.Location = new Point(12, 290);
            label20.Name = "label20";
            label20.Size = new Size(98, 22);
            label20.TabIndex = 39;
            label20.Text = "Direccion";
            // 
            // label21
            // 
            label21.AutoSize = true;
            label21.Font = new Font("Rockwell", 15F, FontStyle.Regular, GraphicsUnit.Point);
            label21.ForeColor = Color.FromArgb(249, 247, 247);
            label21.Location = new Point(12, 105);
            label21.Name = "label21";
            label21.Size = new Size(84, 22);
            label21.TabIndex = 36;
            label21.Text = "Nombre";
            // 
            // label22
            // 
            label22.AutoSize = true;
            label22.Font = new Font("Rockwell", 15F, FontStyle.Regular, GraphicsUnit.Point);
            label22.ForeColor = Color.FromArgb(249, 247, 247);
            label22.Location = new Point(12, 14);
            label22.Name = "label22";
            label22.Size = new Size(124, 22);
            label22.TabIndex = 34;
            label22.Text = "No. Personal";
            // 
            // no_personal
            // 
            no_personal.BackColor = Color.FromArgb(249, 247, 247);
            no_personal.Font = new Font("Rockwell", 20F, FontStyle.Regular, GraphicsUnit.Point);
            no_personal.Location = new Point(12, 48);
            no_personal.Margin = new Padding(3, 2, 3, 2);
            no_personal.Name = "no_personal";
            no_personal.Size = new Size(152, 39);
            no_personal.TabIndex = 31;
            // 
            // tabPage7
            // 
            tabPage7.BackColor = Color.FromArgb(18, 64, 119);
            tabPage7.Controls.Add(tabControl3);
            tabPage7.Location = new Point(4, 24);
            tabPage7.Name = "tabPage7";
            tabPage7.Size = new Size(865, 402);
            tabPage7.TabIndex = 6;
            tabPage7.Text = "AgregarSuministro";
            // 
            // tabControl3
            // 
            tabControl3.Controls.Add(tabPage13);
            tabControl3.Controls.Add(tabPage16);
            tabControl3.Dock = DockStyle.Fill;
            tabControl3.Location = new Point(0, 0);
            tabControl3.Name = "tabControl3";
            tabControl3.SelectedIndex = 0;
            tabControl3.Size = new Size(865, 402);
            tabControl3.TabIndex = 1;
            // 
            // tabPage13
            // 
            tabPage13.BackColor = Color.FromArgb(18, 64, 119);
            tabPage13.Controls.Add(dg1);
            tabPage13.Controls.Add(label29);
            tabPage13.Controls.Add(noSala);
            tabPage13.Controls.Add(btn_agregarCama);
            tabPage13.Location = new Point(4, 24);
            tabPage13.Name = "tabPage13";
            tabPage13.Padding = new Padding(3);
            tabPage13.Size = new Size(857, 374);
            tabPage13.TabIndex = 0;
            tabPage13.Text = "Camas";
            // 
            // dg1
            // 
            dg1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
            dg1.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
            dg1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dg1.Dock = DockStyle.Left;
            dg1.Location = new Point(3, 3);
            dg1.Name = "dg1";
            dg1.RowTemplate.Height = 25;
            dg1.Size = new Size(417, 368);
            dg1.TabIndex = 40;
            // 
            // label29
            // 
            label29.AutoSize = true;
            label29.Font = new Font("Rockwell", 27.75F, FontStyle.Regular, GraphicsUnit.Point);
            label29.ForeColor = Color.FromArgb(249, 247, 247);
            label29.Location = new Point(549, 88);
            label29.Name = "label29";
            label29.Size = new Size(166, 42);
            label29.TabIndex = 39;
            label29.Text = "No. Sala ";
            // 
            // noSala
            // 
            noSala.BackColor = Color.FromArgb(249, 247, 247);
            noSala.Font = new Font("Rockwell", 20F, FontStyle.Regular, GraphicsUnit.Point);
            noSala.Location = new Point(489, 145);
            noSala.Margin = new Padding(3, 2, 3, 2);
            noSala.Name = "noSala";
            noSala.Size = new Size(296, 39);
            noSala.TabIndex = 38;
            // 
            // btn_agregarCama
            // 
            btn_agregarCama.BackColor = Color.FromArgb(17, 45, 78);
            btn_agregarCama.FlatAppearance.BorderColor = Color.FromArgb(249, 247, 247);
            btn_agregarCama.FlatAppearance.BorderSize = 2;
            btn_agregarCama.FlatAppearance.MouseDownBackColor = Color.FromArgb(18, 81, 157);
            btn_agregarCama.FlatStyle = FlatStyle.Flat;
            btn_agregarCama.Font = new Font("Rockwell", 15F, FontStyle.Regular, GraphicsUnit.Point);
            btn_agregarCama.ForeColor = Color.FromArgb(249, 247, 247);
            btn_agregarCama.Location = new Point(559, 211);
            btn_agregarCama.Margin = new Padding(3, 2, 3, 2);
            btn_agregarCama.Name = "btn_agregarCama";
            btn_agregarCama.Size = new Size(156, 75);
            btn_agregarCama.TabIndex = 37;
            btn_agregarCama.Text = "Agregar Cama";
            btn_agregarCama.UseVisualStyleBackColor = false;
            btn_agregarCama.Click += btn_agregarCama_Click;
            // 
            // tabPage16
            // 
            tabPage16.BackColor = Color.FromArgb(18, 64, 119);
            tabPage16.Controls.Add(label37);
            tabPage16.Controls.Add(codigo_descripcion);
            tabPage16.Controls.Add(label12);
            tabPage16.Controls.Add(no_medicina);
            tabPage16.Controls.Add(label30);
            tabPage16.Controls.Add(descripcion_medicina);
            tabPage16.Controls.Add(label13);
            tabPage16.Controls.Add(nombre_medicina);
            tabPage16.Controls.Add(btnAgregarMedicina);
            tabPage16.Location = new Point(4, 24);
            tabPage16.Name = "tabPage16";
            tabPage16.Size = new Size(857, 374);
            tabPage16.TabIndex = 3;
            tabPage16.Text = "Medicinas";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Rockwell", 27.75F, FontStyle.Regular, GraphicsUnit.Point);
            label12.ForeColor = Color.FromArgb(249, 247, 247);
            label12.Location = new Point(31, 159);
            label12.Name = "label12";
            label12.Size = new Size(322, 42);
            label12.TabIndex = 46;
            label12.Text = "Numero Medicina";
            // 
            // no_medicina
            // 
            no_medicina.BackColor = Color.FromArgb(249, 247, 247);
            no_medicina.Font = new Font("Rockwell", 20F, FontStyle.Regular, GraphicsUnit.Point);
            no_medicina.Location = new Point(31, 226);
            no_medicina.Margin = new Padding(3, 2, 3, 2);
            no_medicina.Name = "no_medicina";
            no_medicina.Size = new Size(296, 39);
            no_medicina.TabIndex = 45;
            // 
            // label30
            // 
            label30.AutoSize = true;
            label30.Font = new Font("Rockwell", 27.75F, FontStyle.Regular, GraphicsUnit.Point);
            label30.ForeColor = Color.FromArgb(249, 247, 247);
            label30.Location = new Point(536, 159);
            label30.Name = "label30";
            label30.Size = new Size(223, 42);
            label30.TabIndex = 44;
            label30.Text = "Descripcion";
            // 
            // descripcion_medicina
            // 
            descripcion_medicina.BackColor = Color.FromArgb(249, 247, 247);
            descripcion_medicina.Font = new Font("Rockwell", 20F, FontStyle.Regular, GraphicsUnit.Point);
            descripcion_medicina.Location = new Point(536, 240);
            descripcion_medicina.Margin = new Padding(3, 2, 3, 2);
            descripcion_medicina.Multiline = true;
            descripcion_medicina.Name = "descripcion_medicina";
            descripcion_medicina.Size = new Size(296, 104);
            descripcion_medicina.TabIndex = 43;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Rockwell", 27.75F, FontStyle.Regular, GraphicsUnit.Point);
            label13.ForeColor = Color.FromArgb(249, 247, 247);
            label13.Location = new Point(31, 31);
            label13.Name = "label13";
            label13.Size = new Size(325, 42);
            label13.TabIndex = 42;
            label13.Text = "Nombre Medicina";
            // 
            // nombre_medicina
            // 
            nombre_medicina.BackColor = Color.FromArgb(249, 247, 247);
            nombre_medicina.Font = new Font("Rockwell", 20F, FontStyle.Regular, GraphicsUnit.Point);
            nombre_medicina.Location = new Point(31, 98);
            nombre_medicina.Margin = new Padding(3, 2, 3, 2);
            nombre_medicina.Name = "nombre_medicina";
            nombre_medicina.Size = new Size(296, 39);
            nombre_medicina.TabIndex = 41;
            // 
            // btnAgregarMedicina
            // 
            btnAgregarMedicina.BackColor = Color.FromArgb(17, 45, 78);
            btnAgregarMedicina.FlatAppearance.BorderColor = Color.FromArgb(249, 247, 247);
            btnAgregarMedicina.FlatAppearance.BorderSize = 2;
            btnAgregarMedicina.FlatAppearance.MouseDownBackColor = Color.FromArgb(18, 81, 157);
            btnAgregarMedicina.FlatStyle = FlatStyle.Flat;
            btnAgregarMedicina.Font = new Font("Rockwell", 15F, FontStyle.Regular, GraphicsUnit.Point);
            btnAgregarMedicina.ForeColor = Color.FromArgb(249, 247, 247);
            btnAgregarMedicina.Location = new Point(338, 280);
            btnAgregarMedicina.Margin = new Padding(3, 2, 3, 2);
            btnAgregarMedicina.Name = "btnAgregarMedicina";
            btnAgregarMedicina.Size = new Size(156, 75);
            btnAgregarMedicina.TabIndex = 40;
            btnAgregarMedicina.Text = "Agregar Medicina";
            btnAgregarMedicina.UseVisualStyleBackColor = false;
            btnAgregarMedicina.Click += btnAgregarMedicina_Click;
            // 
            // tabPage8
            // 
            tabPage8.BackColor = Color.FromArgb(18, 64, 119);
            tabPage8.Controls.Add(button5);
            tabPage8.Controls.Add(label36);
            tabPage8.Controls.Add(label35);
            tabPage8.Controls.Add(txt_no_p);
            tabPage8.Controls.Add(label34);
            tabPage8.Controls.Add(txt_fax);
            tabPage8.Controls.Add(label33);
            tabPage8.Controls.Add(txt_telP);
            tabPage8.Controls.Add(label32);
            tabPage8.Controls.Add(txt_direP);
            tabPage8.Controls.Add(label8);
            tabPage8.Controls.Add(label31);
            tabPage8.Controls.Add(txt_nombreP);
            tabPage8.Location = new Point(4, 24);
            tabPage8.Name = "tabPage8";
            tabPage8.Size = new Size(865, 402);
            tabPage8.TabIndex = 7;
            tabPage8.Text = "AgregarProveedor";
            // 
            // button5
            // 
            button5.BackColor = Color.FromArgb(17, 45, 78);
            button5.FlatAppearance.BorderColor = Color.FromArgb(249, 247, 247);
            button5.FlatAppearance.BorderSize = 2;
            button5.FlatAppearance.MouseDownBackColor = Color.FromArgb(18, 81, 157);
            button5.FlatStyle = FlatStyle.Flat;
            button5.Font = new Font("Rockwell", 15F, FontStyle.Regular, GraphicsUnit.Point);
            button5.ForeColor = Color.FromArgb(249, 247, 247);
            button5.Location = new Point(366, 273);
            button5.Margin = new Padding(3, 2, 3, 2);
            button5.Name = "button5";
            button5.Size = new Size(152, 60);
            button5.TabIndex = 65;
            button5.Text = "Ingresar Proveedor";
            button5.UseVisualStyleBackColor = false;
            button5.Click += agregar_proveedor;
            // 
            // label36
            // 
            label36.AutoSize = true;
            label36.Font = new Font("Rockwell", 10F, FontStyle.Regular, GraphicsUnit.Point);
            label36.ForeColor = Color.FromArgb(249, 247, 247);
            label36.Location = new Point(26, 218);
            label36.Name = "label36";
            label36.Size = new Size(86, 17);
            label36.TabIndex = 55;
            label36.Text = "Ejemplo: P1";
            // 
            // label35
            // 
            label35.AutoSize = true;
            label35.Font = new Font("Rockwell", 10F, FontStyle.Regular, GraphicsUnit.Point);
            label35.ForeColor = Color.FromArgb(249, 247, 247);
            label35.Location = new Point(14, 201);
            label35.Name = "label35";
            label35.Size = new Size(163, 17);
            label35.TabIndex = 54;
            label35.Text = "*Colocar una P al inicio ";
            // 
            // txt_no_p
            // 
            txt_no_p.BackColor = Color.FromArgb(249, 247, 247);
            txt_no_p.Font = new Font("Rockwell", 20F, FontStyle.Regular, GraphicsUnit.Point);
            txt_no_p.Location = new Point(14, 160);
            txt_no_p.Margin = new Padding(3, 2, 3, 2);
            txt_no_p.Name = "txt_no_p";
            txt_no_p.Size = new Size(152, 39);
            txt_no_p.TabIndex = 52;
            // 
            // label34
            // 
            label34.AutoSize = true;
            label34.Font = new Font("Rockwell", 15F, FontStyle.Regular, GraphicsUnit.Point);
            label34.ForeColor = Color.FromArgb(249, 247, 247);
            label34.Location = new Point(14, 129);
            label34.Name = "label34";
            label34.Size = new Size(142, 22);
            label34.TabIndex = 53;
            label34.Text = "No_proveedor";
            // 
            // txt_fax
            // 
            txt_fax.BackColor = Color.FromArgb(249, 247, 247);
            txt_fax.Font = new Font("Rockwell", 20F, FontStyle.Regular, GraphicsUnit.Point);
            txt_fax.Location = new Point(692, 49);
            txt_fax.Margin = new Padding(3, 2, 3, 2);
            txt_fax.Name = "txt_fax";
            txt_fax.Size = new Size(152, 39);
            txt_fax.TabIndex = 50;
            // 
            // label33
            // 
            label33.AutoSize = true;
            label33.Font = new Font("Rockwell", 15F, FontStyle.Regular, GraphicsUnit.Point);
            label33.ForeColor = Color.FromArgb(249, 247, 247);
            label33.Location = new Point(692, 18);
            label33.Name = "label33";
            label33.Size = new Size(120, 22);
            label33.TabIndex = 51;
            label33.Text = "Numero Fax";
            // 
            // txt_telP
            // 
            txt_telP.BackColor = Color.FromArgb(249, 247, 247);
            txt_telP.Font = new Font("Rockwell", 20F, FontStyle.Regular, GraphicsUnit.Point);
            txt_telP.Location = new Point(462, 49);
            txt_telP.Margin = new Padding(3, 2, 3, 2);
            txt_telP.Name = "txt_telP";
            txt_telP.Size = new Size(152, 39);
            txt_telP.TabIndex = 48;
            // 
            // label32
            // 
            label32.AutoSize = true;
            label32.Font = new Font("Rockwell", 15F, FontStyle.Regular, GraphicsUnit.Point);
            label32.ForeColor = Color.FromArgb(249, 247, 247);
            label32.Location = new Point(462, 18);
            label32.Name = "label32";
            label32.Size = new Size(88, 22);
            label32.TabIndex = 49;
            label32.Text = "Telefono";
            // 
            // txt_direP
            // 
            txt_direP.BackColor = Color.FromArgb(249, 247, 247);
            txt_direP.Font = new Font("Rockwell", 20F, FontStyle.Regular, GraphicsUnit.Point);
            txt_direP.Location = new Point(249, 49);
            txt_direP.Margin = new Padding(3, 2, 3, 2);
            txt_direP.Name = "txt_direP";
            txt_direP.Size = new Size(152, 39);
            txt_direP.TabIndex = 42;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Rockwell", 15F, FontStyle.Regular, GraphicsUnit.Point);
            label8.ForeColor = Color.FromArgb(249, 247, 247);
            label8.Location = new Point(249, 15);
            label8.Name = "label8";
            label8.Size = new Size(98, 22);
            label8.TabIndex = 43;
            label8.Text = "Direccion";
            // 
            // label31
            // 
            label31.AutoSize = true;
            label31.Font = new Font("Rockwell", 15F, FontStyle.Regular, GraphicsUnit.Point);
            label31.ForeColor = Color.FromArgb(249, 247, 247);
            label31.Location = new Point(14, 15);
            label31.Name = "label31";
            label31.Size = new Size(89, 22);
            label31.TabIndex = 41;
            label31.Text = "Nombre ";
            // 
            // txt_nombreP
            // 
            txt_nombreP.BackColor = Color.FromArgb(249, 247, 247);
            txt_nombreP.Font = new Font("Rockwell", 20F, FontStyle.Regular, GraphicsUnit.Point);
            txt_nombreP.Location = new Point(14, 49);
            txt_nombreP.Margin = new Padding(3, 2, 3, 2);
            txt_nombreP.Name = "txt_nombreP";
            txt_nombreP.Size = new Size(152, 39);
            txt_nombreP.TabIndex = 40;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Rockwell", 40F, FontStyle.Regular, GraphicsUnit.Point);
            label1.ForeColor = Color.FromArgb(249, 247, 247);
            label1.Location = new Point(331, 11);
            label1.Name = "label1";
            label1.Size = new Size(433, 60);
            label1.TabIndex = 1;
            label1.Text = "Director Medico";
            // 
            // button1
            // 
            button1.BackColor = Color.FromArgb(17, 45, 78);
            button1.FlatAppearance.BorderColor = Color.FromArgb(249, 247, 247);
            button1.FlatAppearance.BorderSize = 2;
            button1.FlatAppearance.MouseDownBackColor = Color.FromArgb(18, 81, 157);
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("Rockwell", 15F, FontStyle.Regular, GraphicsUnit.Point);
            button1.ForeColor = Color.FromArgb(249, 247, 247);
            button1.Location = new Point(12, 11);
            button1.Margin = new Padding(3, 2, 3, 2);
            button1.Name = "button1";
            button1.Size = new Size(104, 60);
            button1.TabIndex = 7;
            button1.Text = "Cerrar Sesion";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // label37
            // 
            label37.AutoSize = true;
            label37.Font = new Font("Rockwell", 27.75F, FontStyle.Regular, GraphicsUnit.Point);
            label37.ForeColor = Color.FromArgb(249, 247, 247);
            label37.Location = new Point(495, 31);
            label37.Name = "label37";
            label37.Size = new Size(359, 42);
            label37.TabIndex = 48;
            label37.Text = "Codigo Descripcion";
            // 
            // codigo_descripcion
            // 
            codigo_descripcion.BackColor = Color.FromArgb(249, 247, 247);
            codigo_descripcion.Font = new Font("Rockwell", 20F, FontStyle.Regular, GraphicsUnit.Point);
            codigo_descripcion.Location = new Point(532, 98);
            codigo_descripcion.Margin = new Padding(3, 2, 3, 2);
            codigo_descripcion.Name = "codigo_descripcion";
            codigo_descripcion.Size = new Size(296, 39);
            codigo_descripcion.TabIndex = 47;
            // 
            // Form2
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(17, 45, 78);
            ClientSize = new Size(996, 561);
            ControlBox = false;
            Controls.Add(button1);
            Controls.Add(label1);
            Controls.Add(panel1);
            Name = "Form2";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Director Medico";
            Load += Form2_Load;
            panel1.ResumeLayout(false);
            tabControl1.ResumeLayout(false);
            tabPage1.ResumeLayout(false);
            tabPage1.PerformLayout();
            panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dgPersonal).EndInit();
            tabPage2.ResumeLayout(false);
            panel3.ResumeLayout(false);
            tabControl2.ResumeLayout(false);
            tabPage9.ResumeLayout(false);
            tabPage9.PerformLayout();
            panel7.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dgCamas).EndInit();
            tabPage12.ResumeLayout(false);
            tabPage12.PerformLayout();
            panel10.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dgMedicina).EndInit();
            tabPage3.ResumeLayout(false);
            tabPage3.PerformLayout();
            panel4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dgPacientes).EndInit();
            tabPage4.ResumeLayout(false);
            tabPage4.PerformLayout();
            panel5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dgProveedores).EndInit();
            tabPage10.ResumeLayout(false);
            tabPage10.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dgClinicas).EndInit();
            tabPage5.ResumeLayout(false);
            tabPage5.PerformLayout();
            panel6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dgSalas).EndInit();
            tabPage6.ResumeLayout(false);
            tabPage6.PerformLayout();
            tabPage7.ResumeLayout(false);
            tabControl3.ResumeLayout(false);
            tabPage13.ResumeLayout(false);
            tabPage13.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dg1).EndInit();
            tabPage16.ResumeLayout(false);
            tabPage16.PerformLayout();
            tabPage8.ResumeLayout(false);
            tabPage8.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel panel1;
        private Label label1;
        private Button button1;
        private TabControl tabControl1;
        private TabPage tabPage1;
        private TabPage tabPage2;
        private TabPage tabPage3;
        private TabPage tabPage4;
        private TabPage tabPage5;
        private TabPage tabPage6;
        private TabPage tabPage7;
        private TabPage tabPage8;
        private Panel panel2;
        private DataGridView dgPersonal;
        private Label label2;
        private Button btnBuscarPersonal;
        private Label label4;
        private Button btnMostrarPacientes;
        private Panel panel4;
        private DataGridView dgPacientes;
        private Label label5;
        private Button btnProveedores;
        private Panel panel5;
        private DataGridView dgProveedores;
        private Label label6;
        private Button btnMostarSalas;
        private Panel panel6;
        private DataGridView dgSalas;
        private Panel panel3;
        private TabControl tabControl3;
        private TabPage tabPage13;
        private Button btn_agregarCama;
        private TabPage tabPage16;
        private TextBox telefono_personal;
        private TextBox pago_semanal;
        private Label label25;
        private TextBox salario_personal;
        private Label label24;
        private TextBox id_puesto;
        private Label label23;
        private TextBox nss;
        private TextBox fecha_personal;
        private TextBox direccion_personal;
        private TextBox apellido_personal;
        private TextBox nombre_personal;
        private Label label14;
        private Label label15;
        private Label label16;
        private ComboBox sexo_personal;
        private Label label17;
        private Label label18;
        private Label label19;
        private Label label20;
        private Label label21;
        private Label label22;
        private TextBox no_personal;
        private TextBox id_escala;
        private Label label26;
        private Label label27;
        private Label label28;
        private Button btnIngresarPersonal;
        private Label label29;
        private TextBox noSala;
        private Label label30;
        private TextBox descripcion_medicina;
        private Label label13;
        private TextBox nombre_medicina;
        private Button btnAgregarMedicina;
        private TabControl tabControl2;
        private TabPage tabPage9;
        private Label label3;
        private Button btnMostrarCama;
        private Panel panel7;
        private DataGridView dgCamas;
        private TabPage tabPage12;
        private Label label9;
        private Button btnMostrarMedicna;
        private Panel panel10;
        private DataGridView dgMedicina;
        private TabPage tabPage10;
        private Button button2;
        private Label label7;
        private DataGridView dgClinicas;
        private Label label35;
        private TextBox txt_no_p;
        private Label label34;
        private TextBox txt_fax;
        private Label label33;
        private TextBox txt_telP;
        private Label label32;
        private TextBox txt_direP;
        private Label label8;
        private Label label31;
        private TextBox txt_nombreP;
        private Button button5;
        private Label label36;
        private ComboBox tt_contrato;
        private TextBox horasxsemana;
        private Label label10;
        private TextBox id_turnos;
        private Label label11;
        private DataGridView dg1;
        private Label label12;
        private TextBox no_medicina;
        private Label label37;
        private TextBox codigo_descripcion;
    }
}