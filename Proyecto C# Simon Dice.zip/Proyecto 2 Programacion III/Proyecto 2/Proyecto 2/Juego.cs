﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyecto_2
{
    class Juego
    {
        public string nivel;
        public int punteo;
        List<string> Secuencia = new List<string>();
        Random Num = new Random();
        int Posicion = 0;
        int PosComprobar = 0;
        int puntajeMaximo = 0;
        public Juego(string nivel)
        {
            this.nivel = nivel;
            switch (nivel)
            {
                case "Facil":
                    puntajeMaximo = 7;
                    break;
                case "Medio":
                    puntajeMaximo = 13;
                    break;
                case "Dificil":
                    puntajeMaximo = 20;
                    break;
            }
        }

        public Juego(string nivel, int punteo)
        {
            this.nivel = nivel;
            this.punteo = punteo;
        }

        public Juego() { }

        public int PuntajeMaximo(string nivel)
        {

            this.nivel = nivel;
            switch (nivel)
            {
                case "Facil":
                    puntajeMaximo = 7;
                    break;
                case "Medio":
                    puntajeMaximo = 13;
                    break;
                case "Dificil":
                    puntajeMaximo = 20;
                    break;
            }
            return puntajeMaximo;
        }

        public string getNivel()
        {
            return nivel;
        }

        public int getPunteo()
        {
            return punteo;
        }

        public void NuevoNumero()
        {
            Secuencia.Add(Num.Next(1, 5).ToString());
            Posicion = 0;
        }

        public string ComprobarNumero(string Dato)
        {
            if (Dato == Secuencia[PosComprobar])
            {
                if (Secuencia.Count == (PosComprobar + 1))
                {
                    PosComprobar = 0;
                    return "2";
                }
                else
                {
                    PosComprobar++;
                    return "1";
                }
            }
            else
            {
                PosComprobar = 0;
                return "0";
            }
        }

        public void Error()
        {
            Secuencia.Clear();
            Posicion = 0;
        }

        public string Recorrer()
        {
            if (Secuencia.Count > Posicion)
            {
                string Resultado = Secuencia[Posicion];
                Posicion++;
                return Resultado;
            }
            else
            {
                return "0";
            }

        }

        public void Numeros()
        {
            Secuencia.Add("1");
            Secuencia.Add("2");
            Secuencia.Add("3");
            Secuencia.Add("4");
        }

        public int Aciertos()
        {
            return Secuencia.Count;
        }

        public void setNivel(string nivel)
        {
            this.nivel = nivel;
        }
    }
}
