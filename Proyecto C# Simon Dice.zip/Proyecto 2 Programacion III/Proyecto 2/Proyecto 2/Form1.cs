﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proyecto_2
{
    public partial class Form1 : Form
    {

        public String nombre, nivel;
        Juego juego = new Juego();
        Jugador jugador = new Jugador();
        string ruta = Directory.GetCurrentDirectory() + @"\records\";
        string rutaIMG = Directory.GetCurrentDirectory() + @"\img\";
        string nombreArchivo = "MejoresPuntuaciones.csv";
        int Contpunteo = 0;

        public Form1()
        {
            InitializeComponent();
            tab.ItemSize = new Size(0, 1);

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                // Eliminar líneas vacías del archivo CSV
                string[] lines = File.ReadAllLines(ruta + nombreArchivo)
                    .Where(line => !string.IsNullOrWhiteSpace(line))
                    .ToArray();
                File.WriteAllLines(ruta + nombreArchivo, lines);

                // Leer los datos del archivo CSV
                List<Jugador> jugadores = new List<Jugador>();
                StreamReader archivo = new StreamReader(ruta + nombreArchivo);
                char separador = ';';
                string linea;
                archivo.ReadLine();
                while ((linea = archivo.ReadLine()) != null)
                {
                    string[] fila = linea.Split(separador);
                    string nombre = fila[0];
                    string dificultad = fila[1];
                    int puntaje = int.Parse(fila[2]);
                    Jugador jugador = new Jugador(nombre, dificultad, puntaje);
                    jugadores.Add(jugador);
                }
                archivo.Close();

                // Mostrar los mejores jugadores en los TextBox
                jugadores = jugadores.OrderByDescending(j => j.punteo).ToList();
                int contador = 0;
                foreach (Jugador jugador in jugadores)
                {
                    if (contador < 4)
                    {
                        txt_mejoresJugadoresNombre.Text += jugador.name + "\r\n";
                        txt_mejoresJugadoresNivel.Text += jugador.nivel + "\r\n";
                        txt_mejoresJugadoresPunteo.Text += jugador.punteo + "\r\n";
                        contador++;
                    }
                    else
                    {
                        break;
                    }
                }

                if (jugadores.Count > 0)
                {
                    lbl_record.Text = jugadores[0].punteo.ToString();
                }
            }
            catch
            {
                MessageBox.Show("No existe el archivo, se creara uno", "No encontre el archivo", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            pb_mvp1.Image = Image.FromFile(rutaIMG + "mvp1.gif");
            pb_mvp2.Image = Image.FromFile(rutaIMG + "mvp2.gif");
            pictureBox1.Image = Image.FromFile(rutaIMG + "1.png");
            pictureBox2.Image = Image.FromFile(rutaIMG + "2.png");
            pictureBox3.Image = Image.FromFile(rutaIMG + "3.png");
            pictureBox4.Image = Image.FromFile(rutaIMG + "5.png");
            pictureBox5.Image = Image.FromFile(rutaIMG + "4.png");
            pictureBox6.Image = Image.FromFile(rutaIMG + "6.png");
        }

        private void IniciarJuego(object sender, EventArgs e)
        {
            nivel = cb_nivel.Text;
            btn_comenzarJuego.Enabled = false;
            juego = new Juego(nivel);
            juego.NuevoNumero();
            timer2.Enabled = true;
            switch (nivel)
            {
                case "Facil":
                    timer1.Interval = 1000;
                    timer3.Interval = 1000;
                    timer2.Interval = 1000;
                    break;
                case "Medio":
                    timer1.Interval = 500;
                    timer3.Interval = 500;
                    timer2.Interval = 500;
                    break;
                case "Dificil":
                    if(Convert.ToInt32(lbl_punteo.Text) <= 13)
                    {
                        timer1.Interval = 250;
                        timer3.Interval = 250;
                        timer2.Interval = 250;
                    }
                    switch (lbl_punteo.Text)
                    {
                        case "14":
                            timer1.Interval = 245;
                            timer3.Interval = 245;
                            timer2.Interval = 245;
                            break;
                        case "15":
                            timer1.Interval = 225;
                            timer3.Interval = 225;
                            timer2.Interval = 225;
                            break;
                        case "16":
                            timer1.Interval = 205;
                            timer3.Interval = 205;
                            timer2.Interval = 205;
                            break;
                        case "17":
                            timer1.Interval = 200;
                            timer3.Interval = 200;
                            timer2.Interval = 200;
                            break;
                        case "18":
                            timer1.Interval = 175;
                            timer3.Interval = 175;
                            timer2.Interval = 175;
                            break;
                        case "19":
                            timer1.Interval = 150;
                            timer3.Interval = 150;
                            timer2.Interval = 150;
                            break;
                        case "20":
                            timer1.Interval = 125;
                            timer3.Interval = 125;
                            timer2.Interval = 125;
                            break;
                    }
                    break;
                default:
                    nivel = "Facil";
                    timer1.Interval = 1000;
                    timer3.Interval = 1000;
                    timer2.Interval = 1000;
                    break;
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            btn_LuzRoja0.BackColor = Color.Red;
            btn_LuzVerde1.BackColor = Color.Lime;
            btn_LuzAzul2.BackColor = Color.Blue;
            btn_LuzAmarilla3.BackColor = Color.Yellow;
            timer1.Enabled = false;
        }
        private void timer2_Tick(object sender, EventArgs e)
        {
            btn_LuzRoja0.Enabled = false;
            btn_LuzVerde1.Enabled = false;
            btn_LuzAzul2.Enabled = false;
            btn_LuzAmarilla3.Enabled = false;
            switch (juego.Recorrer())
            {
                case "1":
                    btn_LuzRoja0.BackColor = Color.DarkRed;
                    timer1.Enabled = true;
                    break;
                case "2":
                    btn_LuzVerde1.BackColor = Color.LimeGreen;
                    timer1.Enabled = true;
                    break;
                case "3":
                    btn_LuzAzul2.BackColor = Color.DarkBlue;
                    timer1.Enabled = true;
                    break;
                case "4":
                    btn_LuzAmarilla3.BackColor = Color.YellowGreen;
                    timer1.Enabled = true;
                    break;
                default:
                    btn_LuzRoja0.Enabled = true;
                    btn_LuzVerde1.Enabled = true;
                    btn_LuzAzul2.Enabled = true;
                    btn_LuzAmarilla3.Enabled = true;
                    timer2.Enabled = false;
                    break;
            }
        }

        private void ComprobarBoton(string Dato)
        {
            switch (juego.ComprobarNumero(Dato))
            {
                case "1":
                    timer2.Enabled = false;
                    break;
                case "2":
                    lbl_punteo.Text = juego.Aciertos().ToString();
                    Contpunteo++;
                    string niveldePunteo = "";
                    switch (nivel)
                    {
                        case "Facil":
                            niveldePunteo = "7";
                            break;
                        case "Medio":
                            niveldePunteo = "13";
                            break;
                        case "Dificil":
                            niveldePunteo = "20";
                            break;
                    }
                    if (juego.Aciertos() == juego.PuntajeMaximo(niveldePunteo))
                    {
                        MessageBox.Show("¡Ganaste el juego! :D", "Victoria", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        btn_iniciarJuego.Enabled = true;
                        ingresarJugadoraCsv();
                        MessageBox.Show("Datos ingresados al registro de punteos", "Registro Guardado", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        tab.SelectTab(5);
                    }
                    else
                    {
                        juego.NuevoNumero();
                        timer3.Enabled = true;
                    }
                    break;
                case "0":
                    MessageBox.Show("Fallaste :(", "Perdiste", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    juego.Error();
                    btn_comenzarJuego.Enabled = true;
                    lbl_punteo.Text = "0";
                    timer3.Enabled = true;
                    ingresarJugadoraCsv();
                    MessageBox.Show("Datos ingresados al registro de punteos", "Registro Guardado", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    tab.SelectTab(5);
                    break;
            }
        }
        private void timer3_Tick(object sender, EventArgs e)
        {
            timer2.Enabled = true;
            timer3.Enabled = false;
            btn_LuzRoja0.Enabled = false;
            btn_LuzVerde1.Enabled = false;
            btn_LuzAzul2.Enabled = false;
            btn_LuzAmarilla3.Enabled = false;
        }

        private void btn_LuzRoja0_Click(object sender, EventArgs e)
        {
            btn_LuzRoja0.BackColor = Color.DarkRed;
            timer1.Enabled = true;
            ComprobarBoton("1");
        }

        private void btn_LuzVerde1_Click(object sender, EventArgs e)
        {
            btn_LuzVerde1.BackColor = Color.LimeGreen;
            timer1.Enabled = true;
            ComprobarBoton("2");
        }

        private void btn_LuzAzul2_Click(object sender, EventArgs e)
        {
            btn_LuzAzul2.BackColor = Color.DarkBlue;
            timer1.Enabled = true;
            ComprobarBoton("3");
        }

        private void btn_LuzAmarilla3_Click(object sender, EventArgs e)
        {
            btn_LuzAmarilla3.BackColor = Color.YellowGreen;
            timer1.Enabled = true;
            ComprobarBoton("4");
        }

        private void leerPunteos(object sender, EventArgs e)
        {
            try
            {
                // Leer todas las líneas del archivo y eliminar las líneas vacías
                string[] lineas = File.ReadAllLines(ruta + nombreArchivo, Encoding.UTF8).Where(l => !string.IsNullOrWhiteSpace(l)).ToArray();

                // Separar el encabezado y los datos
                string[] encabezado = lineas[0].Split(';');
                string[][] datos = lineas.Skip(1).Select(l => l.Split(';')).ToArray();

                // Crear una tabla a partir de los datos
                DataTable tabla = new DataTable();
                foreach (string columna in encabezado)
                {
                    tabla.Columns.Add(columna);
                }
                foreach (string[] fila in datos)
                {
                    tabla.Rows.Add(fila);
                }

                tabla = tabla.AsEnumerable().OrderByDescending(row => int.Parse(row["Punteo"].ToString())).CopyToDataTable();

                //Eliminar lineas en blanco en DataGridView
                for (int i = data.Rows.Count - 1; i >= 0; i--)
                {
                    bool esVacia = true;
                    foreach (DataGridViewCell cell in data.Rows[i].Cells)
                    {
                        if (!string.IsNullOrEmpty(cell.Value?.ToString()))
                        {
                            esVacia = false;
                            break;
                        }
                    }
                    if (esVacia)
                    {
                        data.Rows.RemoveAt(i);
                    }
                }
                data.DataSource = tabla;
            }
            catch
            {
                MessageBox.Show("Ya fueron leidos los datos", "Error");
            }
        }

        private void ingresarJugadoraCsv()
        {
            bool existe = File.Exists(ruta + nombreArchivo);

            if (existe)
            {
                using (StreamWriter sw = new StreamWriter(ruta + nombreArchivo, true))
                {
                    sw.WriteLine("{0};{1};{2}", nombre, nivel, Contpunteo.ToString());
                    sw.Close();
                }
            }
            else
            {
                MessageBox.Show("No existe el archivo, se creara uno", "No encontre el archivo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                using (StreamWriter sw = new StreamWriter(ruta + nombreArchivo, true))
                {
                    sw.WriteLine("Nombre;Nivel;Puntaje");
                    sw.WriteLine("{0};{1};{2}", nombre, nivel, Contpunteo.ToString());
                    sw.Close();
                }
            }
        }

        private void funcionalidadesBotones(object sender, EventArgs e)
        {
            Button aux = (Button)sender;

            switch (aux.Text)
            {
                case "Iniciar Juego":
                    tab.SelectTab(4);
                    break;
                case "Instrucciones":
                    tab.SelectTab(2);
                    break;
                case "Mejores Punteos":
                    tab.SelectTab(3);
                    break;
                case "Ver Todos":
                    tab.SelectTab(5);
                    break;
                case "Regresar":
                    tab.SelectTab(0);
                    break;
                case "Listo":
                    MessageBox.Show("Datos ingresados", "Listo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    nombre = txt_nombreJugador.Text;
                    nivel = cb_nivel.Text;
                    jugador = new Jugador(nombre, nivel);
                    juego = new Juego(nivel);
                    lbl_Jugador.Text = jugador.getName().ToString();
                    lbl_nivelJuego.Text = juego.getNivel().ToString();
                    tab.SelectTab(1);
                    break;
                case "Cerrar":
                    this.Close();
                    break;
                case "Info":
                    System.Diagnostics.Process.Start("https://es.wikipedia.org/wiki/Sim%C3%B3n_dice");
                    break;
            }
        }
    }
}
