﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyecto_2
{
    class Jugador
    {
        public String name, nivel;
        public int punteo;

        public Jugador(String name, String nivel, int punteo)
        {
            this.name = name;
            this.nivel = nivel;
            this.punteo = punteo;
        }

        public Jugador() { }

        public Jugador(String name, String nivel)
        {
            this.name = name;
            this.nivel = nivel;
        }

        public String getName()
        {
            return name;
        }

        public void setName(string name)
        {
            this.name = name;
        }




    }
}
