﻿
namespace Proyecto_2
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.tab = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.btn_cerrar = new FontAwesome.Sharp.IconButton();
            this.btn_Punteos = new FontAwesome.Sharp.IconButton();
            this.btn_Instrucciones = new FontAwesome.Sharp.IconButton();
            this.btn_iniciarJuego = new FontAwesome.Sharp.IconButton();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lbl_TitutloPrincipal = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btn_info = new FontAwesome.Sharp.IconButton();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.btn_LuzAzul2 = new System.Windows.Forms.Button();
            this.btn_LuzAmarilla3 = new System.Windows.Forms.Button();
            this.btn_LuzVerde1 = new System.Windows.Forms.Button();
            this.btn_LuzRoja0 = new System.Windows.Forms.Button();
            this.lbl_nivelJuego = new System.Windows.Forms.Label();
            this.lbl_Jugador = new System.Windows.Forms.Label();
            this.lbl_nivelTitulo = new System.Windows.Forms.Label();
            this.lbl_tituloJugador = new System.Windows.Forms.Label();
            this.lbl_Titulorecord = new System.Windows.Forms.Label();
            this.lbl_record = new System.Windows.Forms.Label();
            this.lbl_TituloPunteo = new System.Windows.Forms.Label();
            this.lbl_punteo = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.btn_comenzarJuego = new FontAwesome.Sharp.IconButton();
            this.btn_regresar1 = new FontAwesome.Sharp.IconButton();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.panel4 = new System.Windows.Forms.Panel();
            this.btn_regresar2 = new FontAwesome.Sharp.IconButton();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lbl_mejoresjugadores = new System.Windows.Forms.Label();
            this.txt_mejoresJugadoresPunteo = new System.Windows.Forms.TextBox();
            this.txt_mejoresJugadoresNivel = new System.Windows.Forms.TextBox();
            this.txt_mejoresJugadoresNombre = new System.Windows.Forms.TextBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.btn_regresar3 = new FontAwesome.Sharp.IconButton();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.cb_nivel = new System.Windows.Forms.ComboBox();
            this.txt_nombreJugador = new System.Windows.Forms.TextBox();
            this.lbl_TituloNivel = new System.Windows.Forms.Label();
            this.lbl_tituloName = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.btn_Listo = new FontAwesome.Sharp.IconButton();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.panel8 = new System.Windows.Forms.Panel();
            this.btn_Leer = new FontAwesome.Sharp.IconButton();
            this.iconButton1 = new FontAwesome.Sharp.IconButton();
            this.panel7 = new System.Windows.Forms.Panel();
            this.data = new System.Windows.Forms.DataGridView();
            this.label4 = new System.Windows.Forms.Label();
            this.panel9 = new System.Windows.Forms.Panel();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.timer3 = new System.Windows.Forms.Timer(this.components);
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.pb_mvp1 = new System.Windows.Forms.PictureBox();
            this.pb_mvp2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.panel10 = new System.Windows.Forms.Panel();
            this.panel11 = new System.Windows.Forms.Panel();
            this.panel12 = new System.Windows.Forms.Panel();
            this.panel13 = new System.Windows.Forms.Panel();
            this.panel14 = new System.Windows.Forms.Panel();
            this.panel15 = new System.Windows.Forms.Panel();
            this.panel16 = new System.Windows.Forms.Panel();
            this.btn_verTodos = new FontAwesome.Sharp.IconButton();
            this.tab.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.panel5.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.panel6.SuspendLayout();
            this.tabPage6.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.data)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_mvp1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_mvp2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            this.panel12.SuspendLayout();
            this.panel13.SuspendLayout();
            this.SuspendLayout();
            // 
            // tab
            // 
            this.tab.Controls.Add(this.tabPage1);
            this.tab.Controls.Add(this.tabPage2);
            this.tab.Controls.Add(this.tabPage3);
            this.tab.Controls.Add(this.tabPage4);
            this.tab.Controls.Add(this.tabPage5);
            this.tab.Controls.Add(this.tabPage6);
            this.tab.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tab.Location = new System.Drawing.Point(0, 0);
            this.tab.Name = "tab";
            this.tab.SelectedIndex = 0;
            this.tab.Size = new System.Drawing.Size(1097, 684);
            this.tab.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            this.tab.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(72)))), ((int)(((byte)(107)))));
            this.tabPage1.Controls.Add(this.btn_cerrar);
            this.tabPage1.Controls.Add(this.btn_Punteos);
            this.tabPage1.Controls.Add(this.btn_Instrucciones);
            this.tabPage1.Controls.Add(this.btn_iniciarJuego);
            this.tabPage1.Controls.Add(this.panel1);
            this.tabPage1.Controls.Add(this.panel11);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1089, 655);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Home";
            // 
            // btn_cerrar
            // 
            this.btn_cerrar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(217)))), ((int)(((byte)(73)))));
            this.btn_cerrar.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(72)))), ((int)(((byte)(107)))));
            this.btn_cerrar.IconChar = FontAwesome.Sharp.IconChar.X;
            this.btn_cerrar.IconColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(72)))), ((int)(((byte)(107)))));
            this.btn_cerrar.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btn_cerrar.IconSize = 40;
            this.btn_cerrar.Location = new System.Drawing.Point(8, 6);
            this.btn_cerrar.Name = "btn_cerrar";
            this.btn_cerrar.Size = new System.Drawing.Size(78, 63);
            this.btn_cerrar.TabIndex = 0;
            this.btn_cerrar.Text = "Cerrar";
            this.btn_cerrar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_cerrar.UseVisualStyleBackColor = false;
            this.btn_cerrar.Click += new System.EventHandler(this.funcionalidadesBotones);
            // 
            // btn_Punteos
            // 
            this.btn_Punteos.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(217)))), ((int)(((byte)(73)))));
            this.btn_Punteos.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(72)))), ((int)(((byte)(107)))));
            this.btn_Punteos.IconChar = FontAwesome.Sharp.IconChar.IdCard;
            this.btn_Punteos.IconColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(72)))), ((int)(((byte)(107)))));
            this.btn_Punteos.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btn_Punteos.IconSize = 78;
            this.btn_Punteos.Location = new System.Drawing.Point(428, 421);
            this.btn_Punteos.Name = "btn_Punteos";
            this.btn_Punteos.Size = new System.Drawing.Size(220, 117);
            this.btn_Punteos.TabIndex = 0;
            this.btn_Punteos.Text = "Mejores Punteos";
            this.btn_Punteos.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_Punteos.UseVisualStyleBackColor = false;
            this.btn_Punteos.Click += new System.EventHandler(this.funcionalidadesBotones);
            // 
            // btn_Instrucciones
            // 
            this.btn_Instrucciones.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(217)))), ((int)(((byte)(73)))));
            this.btn_Instrucciones.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(72)))), ((int)(((byte)(107)))));
            this.btn_Instrucciones.IconChar = FontAwesome.Sharp.IconChar.Paste;
            this.btn_Instrucciones.IconColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(72)))), ((int)(((byte)(107)))));
            this.btn_Instrucciones.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btn_Instrucciones.IconSize = 78;
            this.btn_Instrucciones.Location = new System.Drawing.Point(428, 299);
            this.btn_Instrucciones.Name = "btn_Instrucciones";
            this.btn_Instrucciones.Size = new System.Drawing.Size(220, 116);
            this.btn_Instrucciones.TabIndex = 0;
            this.btn_Instrucciones.Text = "Instrucciones";
            this.btn_Instrucciones.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_Instrucciones.UseVisualStyleBackColor = false;
            this.btn_Instrucciones.Click += new System.EventHandler(this.funcionalidadesBotones);
            // 
            // btn_iniciarJuego
            // 
            this.btn_iniciarJuego.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(217)))), ((int)(((byte)(73)))));
            this.btn_iniciarJuego.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(72)))), ((int)(((byte)(107)))));
            this.btn_iniciarJuego.IconChar = FontAwesome.Sharp.IconChar.Play;
            this.btn_iniciarJuego.IconColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(72)))), ((int)(((byte)(107)))));
            this.btn_iniciarJuego.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btn_iniciarJuego.IconSize = 78;
            this.btn_iniciarJuego.Location = new System.Drawing.Point(428, 177);
            this.btn_iniciarJuego.Name = "btn_iniciarJuego";
            this.btn_iniciarJuego.Size = new System.Drawing.Size(220, 116);
            this.btn_iniciarJuego.TabIndex = 0;
            this.btn_iniciarJuego.Text = "Iniciar Juego";
            this.btn_iniciarJuego.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_iniciarJuego.UseVisualStyleBackColor = false;
            this.btn_iniciarJuego.Click += new System.EventHandler(this.funcionalidadesBotones);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.lbl_TitutloPrincipal);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(3, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1083, 142);
            this.panel1.TabIndex = 1;
            // 
            // lbl_TitutloPrincipal
            // 
            this.lbl_TitutloPrincipal.AutoSize = true;
            this.lbl_TitutloPrincipal.Font = new System.Drawing.Font("Microsoft YaHei UI", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_TitutloPrincipal.ForeColor = System.Drawing.Color.White;
            this.lbl_TitutloPrincipal.Location = new System.Drawing.Point(301, 29);
            this.lbl_TitutloPrincipal.Name = "lbl_TitutloPrincipal";
            this.lbl_TitutloPrincipal.Size = new System.Drawing.Size(500, 106);
            this.lbl_TitutloPrincipal.TabIndex = 1;
            this.lbl_TitutloPrincipal.Text = "Simon Dice";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.btn_info);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(131, 142);
            this.panel2.TabIndex = 0;
            // 
            // btn_info
            // 
            this.btn_info.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(217)))), ((int)(((byte)(73)))));
            this.btn_info.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(72)))), ((int)(((byte)(107)))));
            this.btn_info.IconChar = FontAwesome.Sharp.IconChar.Info;
            this.btn_info.IconColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(72)))), ((int)(((byte)(107)))));
            this.btn_info.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btn_info.IconSize = 40;
            this.btn_info.Location = new System.Drawing.Point(5, 72);
            this.btn_info.Name = "btn_info";
            this.btn_info.Size = new System.Drawing.Size(78, 63);
            this.btn_info.TabIndex = 0;
            this.btn_info.Text = "Info";
            this.btn_info.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_info.UseVisualStyleBackColor = false;
            this.btn_info.Click += new System.EventHandler(this.funcionalidadesBotones);
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(72)))), ((int)(((byte)(107)))));
            this.tabPage2.Controls.Add(this.btn_LuzAzul2);
            this.tabPage2.Controls.Add(this.btn_LuzAmarilla3);
            this.tabPage2.Controls.Add(this.btn_LuzVerde1);
            this.tabPage2.Controls.Add(this.btn_LuzRoja0);
            this.tabPage2.Controls.Add(this.lbl_nivelJuego);
            this.tabPage2.Controls.Add(this.lbl_Jugador);
            this.tabPage2.Controls.Add(this.lbl_nivelTitulo);
            this.tabPage2.Controls.Add(this.lbl_tituloJugador);
            this.tabPage2.Controls.Add(this.lbl_Titulorecord);
            this.tabPage2.Controls.Add(this.lbl_record);
            this.tabPage2.Controls.Add(this.lbl_TituloPunteo);
            this.tabPage2.Controls.Add(this.lbl_punteo);
            this.tabPage2.Controls.Add(this.panel3);
            this.tabPage2.Controls.Add(this.panel10);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1089, 655);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "IniciarJuego";
            // 
            // btn_LuzAzul2
            // 
            this.btn_LuzAzul2.BackColor = System.Drawing.Color.Blue;
            this.btn_LuzAzul2.FlatAppearance.BorderSize = 0;
            this.btn_LuzAzul2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_LuzAzul2.Location = new System.Drawing.Point(284, 271);
            this.btn_LuzAzul2.Name = "btn_LuzAzul2";
            this.btn_LuzAzul2.Size = new System.Drawing.Size(244, 171);
            this.btn_LuzAzul2.TabIndex = 3;
            this.btn_LuzAzul2.UseVisualStyleBackColor = false;
            this.btn_LuzAzul2.Click += new System.EventHandler(this.btn_LuzAzul2_Click);
            // 
            // btn_LuzAmarilla3
            // 
            this.btn_LuzAmarilla3.BackColor = System.Drawing.Color.Yellow;
            this.btn_LuzAmarilla3.FlatAppearance.BorderSize = 0;
            this.btn_LuzAmarilla3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_LuzAmarilla3.Location = new System.Drawing.Point(539, 271);
            this.btn_LuzAmarilla3.Name = "btn_LuzAmarilla3";
            this.btn_LuzAmarilla3.Size = new System.Drawing.Size(244, 171);
            this.btn_LuzAmarilla3.TabIndex = 3;
            this.btn_LuzAmarilla3.UseVisualStyleBackColor = false;
            this.btn_LuzAmarilla3.Click += new System.EventHandler(this.btn_LuzAmarilla3_Click);
            // 
            // btn_LuzVerde1
            // 
            this.btn_LuzVerde1.BackColor = System.Drawing.Color.Lime;
            this.btn_LuzVerde1.FlatAppearance.BorderSize = 0;
            this.btn_LuzVerde1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_LuzVerde1.Location = new System.Drawing.Point(539, 76);
            this.btn_LuzVerde1.Name = "btn_LuzVerde1";
            this.btn_LuzVerde1.Size = new System.Drawing.Size(244, 171);
            this.btn_LuzVerde1.TabIndex = 3;
            this.btn_LuzVerde1.UseVisualStyleBackColor = false;
            this.btn_LuzVerde1.Click += new System.EventHandler(this.btn_LuzVerde1_Click);
            // 
            // btn_LuzRoja0
            // 
            this.btn_LuzRoja0.BackColor = System.Drawing.Color.Red;
            this.btn_LuzRoja0.FlatAppearance.BorderSize = 0;
            this.btn_LuzRoja0.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_LuzRoja0.Location = new System.Drawing.Point(284, 76);
            this.btn_LuzRoja0.Name = "btn_LuzRoja0";
            this.btn_LuzRoja0.Size = new System.Drawing.Size(244, 171);
            this.btn_LuzRoja0.TabIndex = 3;
            this.btn_LuzRoja0.UseVisualStyleBackColor = false;
            this.btn_LuzRoja0.Click += new System.EventHandler(this.btn_LuzRoja0_Click);
            // 
            // lbl_nivelJuego
            // 
            this.lbl_nivelJuego.AutoSize = true;
            this.lbl_nivelJuego.Font = new System.Drawing.Font("Microsoft YaHei UI Light", 28.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_nivelJuego.ForeColor = System.Drawing.Color.White;
            this.lbl_nivelJuego.Location = new System.Drawing.Point(823, 356);
            this.lbl_nivelJuego.Name = "lbl_nivelJuego";
            this.lbl_nivelJuego.Size = new System.Drawing.Size(46, 62);
            this.lbl_nivelJuego.TabIndex = 2;
            this.lbl_nivelJuego.Text = "/";
            this.lbl_nivelJuego.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_Jugador
            // 
            this.lbl_Jugador.AutoSize = true;
            this.lbl_Jugador.Font = new System.Drawing.Font("Microsoft YaHei UI Light", 28.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Jugador.ForeColor = System.Drawing.Color.White;
            this.lbl_Jugador.Location = new System.Drawing.Point(823, 117);
            this.lbl_Jugador.Name = "lbl_Jugador";
            this.lbl_Jugador.Size = new System.Drawing.Size(62, 62);
            this.lbl_Jugador.TabIndex = 2;
            this.lbl_Jugador.Text = "J1";
            this.lbl_Jugador.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_nivelTitulo
            // 
            this.lbl_nivelTitulo.AutoSize = true;
            this.lbl_nivelTitulo.Font = new System.Drawing.Font("Microsoft YaHei UI", 28.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_nivelTitulo.ForeColor = System.Drawing.Color.White;
            this.lbl_nivelTitulo.Location = new System.Drawing.Point(823, 282);
            this.lbl_nivelTitulo.Name = "lbl_nivelTitulo";
            this.lbl_nivelTitulo.Size = new System.Drawing.Size(167, 64);
            this.lbl_nivelTitulo.TabIndex = 2;
            this.lbl_nivelTitulo.Text = "Nivel:";
            // 
            // lbl_tituloJugador
            // 
            this.lbl_tituloJugador.AutoSize = true;
            this.lbl_tituloJugador.Font = new System.Drawing.Font("Microsoft YaHei UI", 28.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_tituloJugador.ForeColor = System.Drawing.Color.White;
            this.lbl_tituloJugador.Location = new System.Drawing.Point(823, 42);
            this.lbl_tituloJugador.Name = "lbl_tituloJugador";
            this.lbl_tituloJugador.Size = new System.Drawing.Size(240, 64);
            this.lbl_tituloJugador.TabIndex = 2;
            this.lbl_tituloJugador.Text = "Jugador:";
            // 
            // lbl_Titulorecord
            // 
            this.lbl_Titulorecord.AutoSize = true;
            this.lbl_Titulorecord.Font = new System.Drawing.Font("Microsoft YaHei UI", 28.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Titulorecord.ForeColor = System.Drawing.Color.White;
            this.lbl_Titulorecord.Location = new System.Drawing.Point(23, 271);
            this.lbl_Titulorecord.Name = "lbl_Titulorecord";
            this.lbl_Titulorecord.Size = new System.Drawing.Size(213, 64);
            this.lbl_Titulorecord.TabIndex = 2;
            this.lbl_Titulorecord.Text = "Record:";
            // 
            // lbl_record
            // 
            this.lbl_record.AutoSize = true;
            this.lbl_record.Font = new System.Drawing.Font("Microsoft YaHei UI", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_record.ForeColor = System.Drawing.Color.White;
            this.lbl_record.Location = new System.Drawing.Point(90, 337);
            this.lbl_record.Name = "lbl_record";
            this.lbl_record.Size = new System.Drawing.Size(94, 106);
            this.lbl_record.TabIndex = 2;
            this.lbl_record.Text = "0";
            // 
            // lbl_TituloPunteo
            // 
            this.lbl_TituloPunteo.AutoSize = true;
            this.lbl_TituloPunteo.Font = new System.Drawing.Font("Microsoft YaHei UI", 28.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_TituloPunteo.ForeColor = System.Drawing.Color.White;
            this.lbl_TituloPunteo.Location = new System.Drawing.Point(23, 51);
            this.lbl_TituloPunteo.Name = "lbl_TituloPunteo";
            this.lbl_TituloPunteo.Size = new System.Drawing.Size(216, 64);
            this.lbl_TituloPunteo.TabIndex = 2;
            this.lbl_TituloPunteo.Text = "Punteo:";
            // 
            // lbl_punteo
            // 
            this.lbl_punteo.AutoSize = true;
            this.lbl_punteo.Font = new System.Drawing.Font("Microsoft YaHei UI", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_punteo.ForeColor = System.Drawing.Color.White;
            this.lbl_punteo.Location = new System.Drawing.Point(90, 117);
            this.lbl_punteo.Name = "lbl_punteo";
            this.lbl_punteo.Size = new System.Drawing.Size(94, 106);
            this.lbl_punteo.TabIndex = 2;
            this.lbl_punteo.Text = "0";
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.btn_comenzarJuego);
            this.panel3.Controls.Add(this.btn_regresar1);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel3.Location = new System.Drawing.Point(3, 583);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1083, 69);
            this.panel3.TabIndex = 0;
            // 
            // btn_comenzarJuego
            // 
            this.btn_comenzarJuego.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(217)))), ((int)(((byte)(73)))));
            this.btn_comenzarJuego.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(72)))), ((int)(((byte)(107)))));
            this.btn_comenzarJuego.IconChar = FontAwesome.Sharp.IconChar.Play;
            this.btn_comenzarJuego.IconColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(72)))), ((int)(((byte)(107)))));
            this.btn_comenzarJuego.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btn_comenzarJuego.IconSize = 40;
            this.btn_comenzarJuego.Location = new System.Drawing.Point(446, 3);
            this.btn_comenzarJuego.Name = "btn_comenzarJuego";
            this.btn_comenzarJuego.Size = new System.Drawing.Size(174, 63);
            this.btn_comenzarJuego.TabIndex = 1;
            this.btn_comenzarJuego.Text = "Iniciar";
            this.btn_comenzarJuego.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_comenzarJuego.UseVisualStyleBackColor = false;
            this.btn_comenzarJuego.Click += new System.EventHandler(this.IniciarJuego);
            // 
            // btn_regresar1
            // 
            this.btn_regresar1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(217)))), ((int)(((byte)(73)))));
            this.btn_regresar1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(72)))), ((int)(((byte)(107)))));
            this.btn_regresar1.IconChar = FontAwesome.Sharp.IconChar.Backward;
            this.btn_regresar1.IconColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(72)))), ((int)(((byte)(107)))));
            this.btn_regresar1.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btn_regresar1.IconSize = 40;
            this.btn_regresar1.Location = new System.Drawing.Point(5, 3);
            this.btn_regresar1.Name = "btn_regresar1";
            this.btn_regresar1.Size = new System.Drawing.Size(123, 63);
            this.btn_regresar1.TabIndex = 1;
            this.btn_regresar1.Text = "Regresar";
            this.btn_regresar1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_regresar1.UseVisualStyleBackColor = false;
            this.btn_regresar1.Click += new System.EventHandler(this.funcionalidadesBotones);
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(72)))), ((int)(((byte)(107)))));
            this.tabPage3.Controls.Add(this.panel4);
            this.tabPage3.Controls.Add(this.panel12);
            this.tabPage3.Location = new System.Drawing.Point(4, 25);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(1089, 655);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Instrucciones";
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.btn_regresar2);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel4.Location = new System.Drawing.Point(0, 586);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(1089, 69);
            this.panel4.TabIndex = 1;
            // 
            // btn_regresar2
            // 
            this.btn_regresar2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(217)))), ((int)(((byte)(73)))));
            this.btn_regresar2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(72)))), ((int)(((byte)(107)))));
            this.btn_regresar2.IconChar = FontAwesome.Sharp.IconChar.Backward;
            this.btn_regresar2.IconColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(72)))), ((int)(((byte)(107)))));
            this.btn_regresar2.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btn_regresar2.IconSize = 40;
            this.btn_regresar2.Location = new System.Drawing.Point(483, 6);
            this.btn_regresar2.Name = "btn_regresar2";
            this.btn_regresar2.Size = new System.Drawing.Size(146, 63);
            this.btn_regresar2.TabIndex = 1;
            this.btn_regresar2.Text = "Regresar";
            this.btn_regresar2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_regresar2.UseVisualStyleBackColor = false;
            this.btn_regresar2.Click += new System.EventHandler(this.funcionalidadesBotones);
            // 
            // tabPage4
            // 
            this.tabPage4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(72)))), ((int)(((byte)(107)))));
            this.tabPage4.Controls.Add(this.pb_mvp2);
            this.tabPage4.Controls.Add(this.pb_mvp1);
            this.tabPage4.Controls.Add(this.label3);
            this.tabPage4.Controls.Add(this.label2);
            this.tabPage4.Controls.Add(this.label8);
            this.tabPage4.Controls.Add(this.label7);
            this.tabPage4.Controls.Add(this.label6);
            this.tabPage4.Controls.Add(this.label5);
            this.tabPage4.Controls.Add(this.label1);
            this.tabPage4.Controls.Add(this.txt_mejoresJugadoresPunteo);
            this.tabPage4.Controls.Add(this.txt_mejoresJugadoresNivel);
            this.tabPage4.Controls.Add(this.txt_mejoresJugadoresNombre);
            this.tabPage4.Controls.Add(this.panel5);
            this.tabPage4.Controls.Add(this.panel13);
            this.tabPage4.Controls.Add(this.panel14);
            this.tabPage4.Location = new System.Drawing.Point(4, 25);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(1089, 655);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Punteos";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft YaHei UI", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(691, 128);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(175, 37);
            this.label3.TabIndex = 3;
            this.label3.Text = "Puntuacion";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft YaHei UI", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(479, 128);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(89, 37);
            this.label2.TabIndex = 3;
            this.label2.Text = "Nivel";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft YaHei UI", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(201, 128);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(134, 37);
            this.label1.TabIndex = 3;
            this.label1.Text = "Nombre";
            // 
            // lbl_mejoresjugadores
            // 
            this.lbl_mejoresjugadores.AutoSize = true;
            this.lbl_mejoresjugadores.BackColor = System.Drawing.Color.Transparent;
            this.lbl_mejoresjugadores.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_mejoresjugadores.Font = new System.Drawing.Font("Microsoft YaHei UI", 28.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_mejoresjugadores.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(217)))), ((int)(((byte)(73)))));
            this.lbl_mejoresjugadores.Location = new System.Drawing.Point(307, 18);
            this.lbl_mejoresjugadores.Name = "lbl_mejoresjugadores";
            this.lbl_mejoresjugadores.Size = new System.Drawing.Size(487, 64);
            this.lbl_mejoresjugadores.TabIndex = 3;
            this.lbl_mejoresjugadores.Text = "Mejores Jugadores";
            // 
            // txt_mejoresJugadoresPunteo
            // 
            this.txt_mejoresJugadoresPunteo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(72)))), ((int)(((byte)(107)))));
            this.txt_mejoresJugadoresPunteo.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_mejoresJugadoresPunteo.Font = new System.Drawing.Font("Microsoft Sans Serif", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_mejoresJugadoresPunteo.ForeColor = System.Drawing.Color.White;
            this.txt_mejoresJugadoresPunteo.Location = new System.Drawing.Point(667, 177);
            this.txt_mejoresJugadoresPunteo.Multiline = true;
            this.txt_mejoresJugadoresPunteo.Name = "txt_mejoresJugadoresPunteo";
            this.txt_mejoresJugadoresPunteo.ReadOnly = true;
            this.txt_mejoresJugadoresPunteo.Size = new System.Drawing.Size(210, 148);
            this.txt_mejoresJugadoresPunteo.TabIndex = 2;
            this.txt_mejoresJugadoresPunteo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txt_mejoresJugadoresNivel
            // 
            this.txt_mejoresJugadoresNivel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(72)))), ((int)(((byte)(107)))));
            this.txt_mejoresJugadoresNivel.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_mejoresJugadoresNivel.Font = new System.Drawing.Font("Microsoft Sans Serif", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_mejoresJugadoresNivel.ForeColor = System.Drawing.Color.White;
            this.txt_mejoresJugadoresNivel.Location = new System.Drawing.Point(417, 177);
            this.txt_mejoresJugadoresNivel.Multiline = true;
            this.txt_mejoresJugadoresNivel.Name = "txt_mejoresJugadoresNivel";
            this.txt_mejoresJugadoresNivel.ReadOnly = true;
            this.txt_mejoresJugadoresNivel.Size = new System.Drawing.Size(210, 148);
            this.txt_mejoresJugadoresNivel.TabIndex = 2;
            this.txt_mejoresJugadoresNivel.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txt_mejoresJugadoresNombre
            // 
            this.txt_mejoresJugadoresNombre.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(72)))), ((int)(((byte)(107)))));
            this.txt_mejoresJugadoresNombre.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_mejoresJugadoresNombre.Font = new System.Drawing.Font("Microsoft Sans Serif", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_mejoresJugadoresNombre.ForeColor = System.Drawing.Color.White;
            this.txt_mejoresJugadoresNombre.Location = new System.Drawing.Point(173, 177);
            this.txt_mejoresJugadoresNombre.Multiline = true;
            this.txt_mejoresJugadoresNombre.Name = "txt_mejoresJugadoresNombre";
            this.txt_mejoresJugadoresNombre.ReadOnly = true;
            this.txt_mejoresJugadoresNombre.Size = new System.Drawing.Size(210, 148);
            this.txt_mejoresJugadoresNombre.TabIndex = 2;
            this.txt_mejoresJugadoresNombre.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.btn_verTodos);
            this.panel5.Controls.Add(this.btn_regresar3);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel5.Location = new System.Drawing.Point(0, 586);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(1089, 69);
            this.panel5.TabIndex = 1;
            // 
            // btn_regresar3
            // 
            this.btn_regresar3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(217)))), ((int)(((byte)(73)))));
            this.btn_regresar3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(72)))), ((int)(((byte)(107)))));
            this.btn_regresar3.IconChar = FontAwesome.Sharp.IconChar.Backward;
            this.btn_regresar3.IconColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(72)))), ((int)(((byte)(107)))));
            this.btn_regresar3.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btn_regresar3.IconSize = 40;
            this.btn_regresar3.Location = new System.Drawing.Point(5, 3);
            this.btn_regresar3.Name = "btn_regresar3";
            this.btn_regresar3.Size = new System.Drawing.Size(156, 63);
            this.btn_regresar3.TabIndex = 1;
            this.btn_regresar3.Text = "Regresar";
            this.btn_regresar3.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_regresar3.UseVisualStyleBackColor = false;
            this.btn_regresar3.Click += new System.EventHandler(this.funcionalidadesBotones);
            // 
            // tabPage5
            // 
            this.tabPage5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(72)))), ((int)(((byte)(107)))));
            this.tabPage5.Controls.Add(this.cb_nivel);
            this.tabPage5.Controls.Add(this.txt_nombreJugador);
            this.tabPage5.Controls.Add(this.lbl_TituloNivel);
            this.tabPage5.Controls.Add(this.lbl_tituloName);
            this.tabPage5.Controls.Add(this.panel6);
            this.tabPage5.Controls.Add(this.panel15);
            this.tabPage5.Controls.Add(this.panel16);
            this.tabPage5.Location = new System.Drawing.Point(4, 25);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Size = new System.Drawing.Size(1089, 590);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "Nombre Y Nivel";
            // 
            // cb_nivel
            // 
            this.cb_nivel.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_nivel.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cb_nivel.FormattingEnabled = true;
            this.cb_nivel.Items.AddRange(new object[] {
            "Facil",
            "Medio",
            "Dificil"});
            this.cb_nivel.Location = new System.Drawing.Point(400, 348);
            this.cb_nivel.Name = "cb_nivel";
            this.cb_nivel.Size = new System.Drawing.Size(290, 39);
            this.cb_nivel.TabIndex = 5;
            // 
            // txt_nombreJugador
            // 
            this.txt_nombreJugador.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_nombreJugador.Location = new System.Drawing.Point(392, 141);
            this.txt_nombreJugador.Name = "txt_nombreJugador";
            this.txt_nombreJugador.Size = new System.Drawing.Size(290, 38);
            this.txt_nombreJugador.TabIndex = 4;
            this.txt_nombreJugador.Text = "J1";
            this.txt_nombreJugador.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl_TituloNivel
            // 
            this.lbl_TituloNivel.AutoSize = true;
            this.lbl_TituloNivel.Font = new System.Drawing.Font("Microsoft YaHei UI", 28.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_TituloNivel.ForeColor = System.Drawing.Color.White;
            this.lbl_TituloNivel.Location = new System.Drawing.Point(170, 253);
            this.lbl_TituloNivel.Name = "lbl_TituloNivel";
            this.lbl_TituloNivel.Size = new System.Drawing.Size(814, 64);
            this.lbl_TituloNivel.TabIndex = 3;
            this.lbl_TituloNivel.Text = "Ingresa el nivel que deseas jugar";
            // 
            // lbl_tituloName
            // 
            this.lbl_tituloName.AutoSize = true;
            this.lbl_tituloName.Font = new System.Drawing.Font("Microsoft YaHei UI", 28.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_tituloName.ForeColor = System.Drawing.Color.White;
            this.lbl_tituloName.Location = new System.Drawing.Point(302, 52);
            this.lbl_tituloName.Name = "lbl_tituloName";
            this.lbl_tituloName.Size = new System.Drawing.Size(476, 64);
            this.lbl_tituloName.TabIndex = 3;
            this.lbl_tituloName.Text = "Ingresa tu nombre";
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.btn_Listo);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel6.Location = new System.Drawing.Point(0, 461);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(1089, 129);
            this.panel6.TabIndex = 2;
            // 
            // btn_Listo
            // 
            this.btn_Listo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(217)))), ((int)(((byte)(73)))));
            this.btn_Listo.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Listo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(72)))), ((int)(((byte)(107)))));
            this.btn_Listo.IconChar = FontAwesome.Sharp.IconChar.CheckCircle;
            this.btn_Listo.IconColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(72)))), ((int)(((byte)(107)))));
            this.btn_Listo.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btn_Listo.IconSize = 72;
            this.btn_Listo.Location = new System.Drawing.Point(465, 18);
            this.btn_Listo.Name = "btn_Listo";
            this.btn_Listo.Size = new System.Drawing.Size(172, 103);
            this.btn_Listo.TabIndex = 1;
            this.btn_Listo.Text = "Listo";
            this.btn_Listo.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_Listo.UseVisualStyleBackColor = false;
            this.btn_Listo.Click += new System.EventHandler(this.funcionalidadesBotones);
            // 
            // tabPage6
            // 
            this.tabPage6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(72)))), ((int)(((byte)(107)))));
            this.tabPage6.Controls.Add(this.panel8);
            this.tabPage6.Controls.Add(this.panel7);
            this.tabPage6.Controls.Add(this.label4);
            this.tabPage6.Controls.Add(this.panel9);
            this.tabPage6.Location = new System.Drawing.Point(4, 25);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Size = new System.Drawing.Size(1089, 655);
            this.tabPage6.TabIndex = 5;
            this.tabPage6.Text = "Puntajes";
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.btn_Leer);
            this.panel8.Controls.Add(this.iconButton1);
            this.panel8.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel8.Location = new System.Drawing.Point(0, 586);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(1089, 69);
            this.panel8.TabIndex = 7;
            // 
            // btn_Leer
            // 
            this.btn_Leer.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(217)))), ((int)(((byte)(73)))));
            this.btn_Leer.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(72)))), ((int)(((byte)(107)))));
            this.btn_Leer.IconChar = FontAwesome.Sharp.IconChar.Database;
            this.btn_Leer.IconColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(72)))), ((int)(((byte)(107)))));
            this.btn_Leer.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btn_Leer.IconSize = 40;
            this.btn_Leer.Location = new System.Drawing.Point(453, 3);
            this.btn_Leer.Name = "btn_Leer";
            this.btn_Leer.Size = new System.Drawing.Size(156, 63);
            this.btn_Leer.TabIndex = 2;
            this.btn_Leer.Text = "Leer Puntajes";
            this.btn_Leer.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_Leer.UseVisualStyleBackColor = false;
            this.btn_Leer.Click += new System.EventHandler(this.leerPunteos);
            // 
            // iconButton1
            // 
            this.iconButton1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(217)))), ((int)(((byte)(73)))));
            this.iconButton1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(72)))), ((int)(((byte)(107)))));
            this.iconButton1.IconChar = FontAwesome.Sharp.IconChar.Backward;
            this.iconButton1.IconColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(72)))), ((int)(((byte)(107)))));
            this.iconButton1.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconButton1.IconSize = 40;
            this.iconButton1.Location = new System.Drawing.Point(5, 3);
            this.iconButton1.Name = "iconButton1";
            this.iconButton1.Size = new System.Drawing.Size(156, 63);
            this.iconButton1.TabIndex = 1;
            this.iconButton1.Text = "Regresar";
            this.iconButton1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.iconButton1.UseVisualStyleBackColor = false;
            this.iconButton1.Click += new System.EventHandler(this.funcionalidadesBotones);
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.data);
            this.panel7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel7.Location = new System.Drawing.Point(0, 100);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(1089, 555);
            this.panel7.TabIndex = 6;
            // 
            // data
            // 
            this.data.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.data.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.data.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.data.Dock = System.Windows.Forms.DockStyle.Fill;
            this.data.Location = new System.Drawing.Point(0, 0);
            this.data.Name = "data";
            this.data.RowHeadersWidth = 51;
            this.data.RowTemplate.Height = 24;
            this.data.Size = new System.Drawing.Size(1089, 555);
            this.data.TabIndex = 5;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft YaHei UI", 28.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(402, 14);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(226, 64);
            this.label4.TabIndex = 4;
            this.label4.Text = "Punteos";
            // 
            // panel9
            // 
            this.panel9.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel9.Location = new System.Drawing.Point(0, 0);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(1089, 100);
            this.panel9.TabIndex = 8;
            // 
            // timer1
            // 
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // timer2
            // 
            this.timer2.Interval = 1000;
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // timer3
            // 
            this.timer3.Interval = 1000;
            this.timer3.Tick += new System.EventHandler(this.timer3_Tick);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft YaHei UI", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Gold;
            this.label5.Location = new System.Drawing.Point(116, 177);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(42, 37);
            this.label5.TabIndex = 3;
            this.label5.Text = "1.";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft YaHei UI", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Silver;
            this.label6.Location = new System.Drawing.Point(116, 214);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(42, 37);
            this.label6.TabIndex = 3;
            this.label6.Text = "2.";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft YaHei UI", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label7.Location = new System.Drawing.Point(116, 251);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(42, 37);
            this.label7.TabIndex = 3;
            this.label7.Text = "3.";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft YaHei UI", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Black;
            this.label8.Location = new System.Drawing.Point(116, 288);
            this.label8.Name = "label8";
            this.label8.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label8.Size = new System.Drawing.Size(42, 37);
            this.label8.TabIndex = 3;
            this.label8.Text = "4.";
            // 
            // pb_mvp1
            // 
            this.pb_mvp1.Location = new System.Drawing.Point(173, 351);
            this.pb_mvp1.Name = "pb_mvp1";
            this.pb_mvp1.Size = new System.Drawing.Size(328, 164);
            this.pb_mvp1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb_mvp1.TabIndex = 4;
            this.pb_mvp1.TabStop = false;
            // 
            // pb_mvp2
            // 
            this.pb_mvp2.Location = new System.Drawing.Point(549, 351);
            this.pb_mvp2.Name = "pb_mvp2";
            this.pb_mvp2.Size = new System.Drawing.Size(328, 164);
            this.pb_mvp2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb_mvp2.TabIndex = 4;
            this.pb_mvp2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(18, 53);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(245, 135);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Location = new System.Drawing.Point(18, 208);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(245, 135);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 2;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Location = new System.Drawing.Point(18, 363);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(245, 135);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 2;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Location = new System.Drawing.Point(836, 53);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(245, 135);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 2;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Location = new System.Drawing.Point(836, 208);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(245, 135);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox5.TabIndex = 2;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Location = new System.Drawing.Point(836, 363);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(245, 135);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox6.TabIndex = 2;
            this.pictureBox6.TabStop = false;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(280, 53);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(135, 25);
            this.label9.TabIndex = 3;
            this.label9.Text = "Inicia el juego ";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(280, 208);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(184, 50);
            this.label10.TabIndex = 3;
            this.label10.Text = "Ingresa tu nombre y\r\ndificultad";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.White;
            this.label11.Location = new System.Drawing.Point(280, 363);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(178, 25);
            this.label11.TabIndex = 3;
            this.label11.Text = "Memoriza el patron";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.White;
            this.label12.Location = new System.Drawing.Point(639, 53);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(171, 75);
            this.label12.TabIndex = 3;
            this.label12.Text = "Adivina, completa \r\n7,13 o 20 combos\r\ny gana";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.White;
            this.label13.Location = new System.Drawing.Point(639, 208);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(169, 50);
            this.label13.TabIndex = 3;
            this.label13.Text = "Lee los puntajes y\r\ncompara";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.White;
            this.label14.Location = new System.Drawing.Point(639, 363);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(191, 50);
            this.label14.TabIndex = 3;
            this.label14.Text = "Obten puntajes altos\r\ne ingresa al TOP 4";
            // 
            // panel10
            // 
            this.panel10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel10.Location = new System.Drawing.Point(3, 3);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(1083, 649);
            this.panel10.TabIndex = 4;
            // 
            // panel11
            // 
            this.panel11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel11.Location = new System.Drawing.Point(3, 3);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(1083, 649);
            this.panel11.TabIndex = 2;
            // 
            // panel12
            // 
            this.panel12.Controls.Add(this.label14);
            this.panel12.Controls.Add(this.pictureBox2);
            this.panel12.Controls.Add(this.label13);
            this.panel12.Controls.Add(this.pictureBox1);
            this.panel12.Controls.Add(this.label12);
            this.panel12.Controls.Add(this.pictureBox3);
            this.panel12.Controls.Add(this.label11);
            this.panel12.Controls.Add(this.pictureBox4);
            this.panel12.Controls.Add(this.label10);
            this.panel12.Controls.Add(this.pictureBox5);
            this.panel12.Controls.Add(this.label9);
            this.panel12.Controls.Add(this.pictureBox6);
            this.panel12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel12.Location = new System.Drawing.Point(0, 0);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(1089, 655);
            this.panel12.TabIndex = 4;
            // 
            // panel13
            // 
            this.panel13.Controls.Add(this.lbl_mejoresjugadores);
            this.panel13.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel13.Location = new System.Drawing.Point(0, 0);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(1089, 100);
            this.panel13.TabIndex = 5;
            // 
            // panel14
            // 
            this.panel14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel14.Location = new System.Drawing.Point(0, 0);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(1089, 655);
            this.panel14.TabIndex = 6;
            // 
            // panel15
            // 
            this.panel15.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel15.Location = new System.Drawing.Point(0, 0);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(1089, 227);
            this.panel15.TabIndex = 6;
            // 
            // panel16
            // 
            this.panel16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel16.Location = new System.Drawing.Point(0, 0);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(1089, 590);
            this.panel16.TabIndex = 7;
            // 
            // btn_verTodos
            // 
            this.btn_verTodos.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(217)))), ((int)(((byte)(73)))));
            this.btn_verTodos.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(72)))), ((int)(((byte)(107)))));
            this.btn_verTodos.IconChar = FontAwesome.Sharp.IconChar.Eye;
            this.btn_verTodos.IconColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(72)))), ((int)(((byte)(107)))));
            this.btn_verTodos.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btn_verTodos.IconSize = 40;
            this.btn_verTodos.Location = new System.Drawing.Point(925, 3);
            this.btn_verTodos.Name = "btn_verTodos";
            this.btn_verTodos.Size = new System.Drawing.Size(156, 63);
            this.btn_verTodos.TabIndex = 1;
            this.btn_verTodos.Text = "Ver Todos";
            this.btn_verTodos.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_verTodos.UseVisualStyleBackColor = false;
            this.btn_verTodos.Click += new System.EventHandler(this.funcionalidadesBotones);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1097, 684);
            this.ControlBox = false;
            this.Controls.Add(this.tab);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Proyecto Simon Dice";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tab.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.tabPage6.ResumeLayout(false);
            this.tabPage6.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.data)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_mvp1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_mvp2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            this.panel12.ResumeLayout(false);
            this.panel12.PerformLayout();
            this.panel13.ResumeLayout(false);
            this.panel13.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tab;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private FontAwesome.Sharp.IconButton btn_iniciarJuego;
        private FontAwesome.Sharp.IconButton btn_cerrar;
        private FontAwesome.Sharp.IconButton btn_Punteos;
        private FontAwesome.Sharp.IconButton btn_Instrucciones;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lbl_TitutloPrincipal;
        private System.Windows.Forms.Panel panel2;
        private FontAwesome.Sharp.IconButton btn_info;
        private System.Windows.Forms.Panel panel3;
        private FontAwesome.Sharp.IconButton btn_regresar1;
        private System.Windows.Forms.Panel panel4;
        private FontAwesome.Sharp.IconButton btn_regresar2;
        private System.Windows.Forms.Panel panel5;
        private FontAwesome.Sharp.IconButton btn_regresar3;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.ComboBox cb_nivel;
        private System.Windows.Forms.TextBox txt_nombreJugador;
        private System.Windows.Forms.Label lbl_TituloNivel;
        private System.Windows.Forms.Label lbl_tituloName;
        private System.Windows.Forms.Panel panel6;
        private FontAwesome.Sharp.IconButton btn_Listo;
        private System.Windows.Forms.Button btn_LuzAzul2;
        private System.Windows.Forms.Button btn_LuzAmarilla3;
        private System.Windows.Forms.Button btn_LuzVerde1;
        private System.Windows.Forms.Button btn_LuzRoja0;
        private System.Windows.Forms.Label lbl_Jugador;
        private System.Windows.Forms.Label lbl_tituloJugador;
        private System.Windows.Forms.Label lbl_TituloPunteo;
        private System.Windows.Forms.Label lbl_punteo;
        private FontAwesome.Sharp.IconButton btn_comenzarJuego;
        private System.Windows.Forms.Label lbl_nivelJuego;
        private System.Windows.Forms.Label lbl_nivelTitulo;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.Label lbl_Titulorecord;
        private System.Windows.Forms.Label lbl_record;
        private System.Windows.Forms.Label lbl_mejoresjugadores;
        private System.Windows.Forms.TextBox txt_mejoresJugadoresNombre;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txt_mejoresJugadoresPunteo;
        private System.Windows.Forms.TextBox txt_mejoresJugadoresNivel;
        private System.Windows.Forms.Timer timer3;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.DataGridView data;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel8;
        private FontAwesome.Sharp.IconButton btn_Leer;
        private FontAwesome.Sharp.IconButton iconButton1;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.PictureBox pb_mvp2;
        private System.Windows.Forms.PictureBox pb_mvp1;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.Panel panel16;
        private FontAwesome.Sharp.IconButton btn_verTodos;
    }
}

