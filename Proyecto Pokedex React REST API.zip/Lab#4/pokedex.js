const host = 'localhost';
const port = 3000;

const pokedex = {

    pokemon: (req, res) => { 
        const fs = require('fs'); //fs es fileSystem
        let elJson = fs.readFileSync('./pokeData.json');

        //Aqui ya tenemos la info del json para manipular
        let data = JSON.parse(elJson);

        //Imprimo
        console.log(data);

        res.status(200).send(data);
    },
    getPokemonID: (req, res) => {
        console.log(req.params.id);

        const fs = require('fs'); //fs es fileSystem
        let elJson = fs.readFileSync('./pokeData.json');

        //Aqui ya tenemos la info del json para manipular
        let data = JSON.parse(elJson);

        let posicion = -1;

        for (let i = 0; i < data.length; i++) {
            const element = data[i];

            if (element.id == req.params.id) {
                posicion = i;
            }
        }


        if (posicion == -1) {
            res.status(200).send("<h1>No existe el pokemon con ese ID en nuestra Pokedex :(</h1>");
        } else {
            res.status(200).send(data[posicion]);
        }
    },
    getPokemonNombre: (req, res) =>{
        console.log(req.params.nombre);

        const fs = require('fs'); //fs es fileSystem
        let elJson = fs.readFileSync('./pokeData.json');

        //Aqui ya tenemos la info del json para manipular
        let data = JSON.parse(elJson);

        let posicion = -1;

        for (let i = 0; i < data.length; i++) {
            const element = data[i];

            if (element.nombre == req.params.nombre) {
                posicion = i;
            }
        }

        if (posicion == -1) {
            res.status(200).send("<h1>No existe el pokemon con ese nombre en nuestra Pokedex :(</h1>");
        } else {
            res.status(200).send(data[posicion]);
        }
    },
    getPokemonNumero: (req, res) => {
        console.log(req.params.no_pokemon);
    
        const fs = require('fs'); //fs es fileSystem
        let elJson = fs.readFileSync('./pokeData.json');
    
        //Aqui ya tenemos la info del json para manipular
        let data = JSON.parse(elJson);
    
        let posicion = -1;
    
        for (let i = 0; i < data.length; i++) {
            const element = data[i];
    
            // Convertir req.params.no_pokemon a número antes de comparar
            if (+element.no_pokemon === +req.params.no_pokemon) {
                posicion = i;
                break; // Terminar el bucle una vez que se encuentra la posición
            }
        }
    
        if (posicion === -1) {
            res.status(200).send("<h1>No existe el pokemon con ese numero en nuestra Pokedex :(</h1>");
        } else {
            res.status(200).send(data[posicion]);
        }
    },
    getPokemonCategoria: (req, res) => { 
        console.log(req.params.categoria);

        const fs = require('fs'); //fs es fileSystem
        let elJson = fs.readFileSync('./pokeData.json');

        //Aqui ya tenemos la info del json para manipular
        let data = JSON.parse(elJson);

        let pokemones = [];

        for (let i = 0; i < data.length; i++) {
            const element = data[i];

            if (element.categoria == req.params.categoria) {
                pokemones.push(element);
            }
        }

        if (pokemones.length == 0) {
            res.status(200).send("<h1>No existe el pokemon con esa categoria en nuestra Pokedex :(</h1>");
        } else {
            res.status(200).send(pokemones);
        }
    },
    getPokemonTipo: (req, res) => { 
        console.log(req.params.tipo);

        const fs = require('fs'); //fs es fileSystem
        let elJson = fs.readFileSync('./pokeData.json');

        //Aqui ya tenemos la info del json para manipular
        let data = JSON.parse(elJson);

        let pokemones = [];

        for (let i = 0; i < data.length; i++) {
            const element = data[i];

            if (element.tipo == req.params.tipo) {
                pokemones.push(element);
            }
        }

        if (pokemones.length == 0) {
            res.status(200).send("<h1>No existe el pokemon con ese tipo en nuestra Pokedex :(</h1>");
        } else {
            res.status(200).send(pokemones);
        }
    },
    getPokemonPeso: (req, res) => { 
        console.log(req.params.peso);

        const fs = require('fs'); //fs es fileSystem
        let elJson = fs.readFileSync('./pokeData.json');

        //Aqui ya tenemos la info del json para manipular
        let data = JSON.parse(elJson);

        let pokemones = [];

        for (let i = 0; i < data.length; i++) {
            const element = data[i];

            if (element.peso == req.params.peso) {
                pokemones.push(element);
            }
        }

        if (pokemones.length == 0) {
            res.status(200).send("<h1>No existe el pokemon con ese peso en nuestra Pokedex :(</h1>");
        } else {
            res.status(200).send(pokemones);
        }
    },
    getPokemonAltura: (req, res) => { 
        console.log(req.params.altura);

        const fs = require('fs'); //fs es fileSystem
        let elJson = fs.readFileSync('./pokeData.json');

        //Aqui ya tenemos la info del json para manipular
        let data = JSON.parse(elJson);

        let pokemones = [];

        for (let i = 0; i < data.length; i++) {
            const element = data[i];

            if (element.altura == req.params.altura) {
                pokemones.push(element);
            }
        }

        if (pokemones.length == 0) {
            res.status(200).send("<h1>No existe el pokemon con esa altura en nuestra Pokedex :(</h1>");
        } else {
            res.status(200).send(pokemones);
        }
    },
    getPokemonHabilidad: (req, res) => { 
        console.log(req.params.habilidad);

        const fs = require('fs'); //fs es fileSystem
        let elJson = fs.readFileSync('./pokeData.json');

        //Aqui ya tenemos la info del json para manipular
        let data = JSON.parse(elJson);

        let pokemones = [];

        for (let i = 0; i < data.length; i++) {
            const element = data[i];

            if (element.habilidad == req.params.habilidad) {
                pokemones.push(element);
            }
        }

        if (pokemones.length == 0) {
            res.status(200).send("<h1>No existe el pokemon con esa habilidad en nuestra Pokedex :(</h1>");
        } else {
            res.status(200).send(pokemones);
        }
    },
    getPokemonDebilidad: (req, res) => { 
        console.log(req.params.debilidad);

        const fs = require('fs'); //fs es fileSystem
        let elJson = fs.readFileSync('./pokeData.json');

        //Aqui ya tenemos la info del json para manipular
        let data = JSON.parse(elJson);

        let pokemones = [];

        for (let i = 0; i < data.length; i++) {
            const element = data[i];

            if (element.debilidad == req.params.debilidad) {
                pokemones.push(element);
            }
        }

        if (pokemones.length == 0) {
            res.status(200).send("<h1>No existe el pokemon con esa debilidad en nuestra Pokedex :(</h1>");
        } else {
            res.status(200).send(pokemones);
        }
    },
    getPokemonEvolucion: (req, res) => { 
        console.log(req.params.id);

        const fs = require('fs'); //fs es fileSystem
        let elJson = fs.readFileSync('./pokeData.json');

        //Aqui ya tenemos la info del json para manipular
        let data = JSON.parse(elJson);

        let posicion = -1;

        for (let i = 0; i < data.length; i++) {
            const element = data[i];

            if (element.id == req.params.id) {
                posicion = i;
            }
        }

        if (posicion === -1) {
            res.status(200).send("<h1>No existe el pokemon con esa evolucion en nuestra Pokedex :(</h1>");
        } else {
            res.status(200).send(data[posicion].evoluciones);
        }
    },
    getPokemonImagen: (req, res) => { 
        console.log(req.params.id);

        const fs = require('fs'); //fs es fileSystem
        let elJson = fs.readFileSync('./pokeData.json');

        //Aqui ya tenemos la info del json para manipular
        let data = JSON.parse(elJson);

        let posicion = -1;

        for (let i = 0; i < data.length; i++) {
            const element = data[i];

            if (element.id == req.params.id) {
                posicion = i;
            }
        }

        if (posicion === -1) {
            res.status(200).send("<h1>No existe el pokemon con esa imagen en nuestra Pokedex :(</h1>");
        } else {
            res.status(200).json({
                imagen1: data[posicion].imagen1,
                imagen2: data[posicion].imagen2
            });
        }
    },
    getPokemonVariables: (req, res) => { 
        const fs = require('fs'); // fs es FileSystem
        let elJson = fs.readFileSync('./pokeData.json');
    
        // Aquí ya tenemos la info del JSON para manipular
        let data = JSON.parse(elJson);
        let pokemonEncontrado = null;
    
        // Buscar el Pokémon por ID
        for (let i = 0; i < data.length; i++) {
            const element = data[i];
    
            if (element.id == req.query.id) {
                pokemonEncontrado = element;
                break;
            }
        }
    
        if (pokemonEncontrado === null) {
            res.status(404).send("<h1>No existe el Pokémon con ese ID en nuestra Pokédex :(</h1>");
        } else {
            // Verificar si la propiedad solicitada existe en el Pokémon encontrado
            const propiedad = req.query.propiedad;
            if (pokemonEncontrado.hasOwnProperty(propiedad)) {
                // Devolver solo la propiedad solicitada del Pokémon encontrado
                res.status(200).send(pokemonEncontrado[propiedad]);
            } else {
                res.status(404).send("<h1>El Pokémon encontrado no tiene la propiedad especificada :(</h1>");
            }
        }
    }
    
};

module.exports = pokedex;