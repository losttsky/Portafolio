const express = require('express');
const app = express();
const port = 3000;
const cors = require('cors');
app.use(express.json());
app.use(cors());

const pokedex = require('./pokedex.js');

//==========================================
//==== END POINTS de la POKEDEX ============
//==========================================

//GETS

app.get('/pokemon', pokedex.pokemon);
app.get('/pokemon/Id/:id', pokedex.getPokemonID);
app.get('/pokemon/Nombre/:nombre', pokedex.getPokemonNombre);
app.get('/pokemon/Numero/:no_pokemon', pokedex.getPokemonNumero);
app.get('/pokemon/Categoria/:categoria', pokedex.getPokemonCategoria);
app.get('/pokemon/Tipo/:tipo', pokedex.getPokemonTipo);
app.get('/pokemon/Peso/:peso', pokedex.getPokemonPeso);
app.get('/pokemon/Altura/:altura', pokedex.getPokemonAltura);
app.get('/pokemon/Habilidad/:habilidad', pokedex.getPokemonHabilidad);
app.get('/pokemon/Debilidad/:debilidad', pokedex.getPokemonDebilidad);
app.get('/pokemon/Evolucion/:id', pokedex.getPokemonEvolucion);
app.get('/pokemon/Imagenes/:id', pokedex.getPokemonImagen);
app.get('/pokemon/?id=:id&propiedad=:propiedad', pokedex.getPokemonVariables);

//arancando API
app.listen(port, () =>{
    console.log(`Arrancando nuestra pokedex en el puerto ${port} ...`);
});