const flechita_arriba = document.getElementById("flecha_arriba");
const flechita_abajo = document.getElementById("flecha_abajo");
const flechita_izquierda = document.getElementById("flecha_izquierda");
const flechita_derecha = document.getElementById("flecha_derecha");
const id = document.getElementById("boton_id");
const name = document.getElementById("boton_name");
const pok = document.getElementById("boton_pok");
const cat = document.getElementById("boton_cat");
const tipo = document.getElementById("boton_tipo");
const peso = document.getElementById("boton_peso");
const altura = document.getElementById("boton_altura");
const hab = document.getElementById("boton_hab");
const deb = document.getElementById("boton_deb");
const evo = document.getElementById("boton_evo");
const flecha_izquierda2 = document.getElementById("flecha_izquierda2");
const flecha_derecha2 = document.getElementById("flecha_derecha2");
let indicePokemon = 0; // Variable para mantener el índice del pokemon actual

console.log("furulo xd");

flechita_arriba.addEventListener('click', function () {
    if (indicePokemon < 19) {
        indicePokemon++;
    } else {
        indicePokemon = 0;
    }
    pokemon();
});

flechita_abajo.addEventListener('click', function () {
    if (indicePokemon > 0) {
        indicePokemon--;
    } else {
        indicePokemon = 19;
    }
    pokemon();
});

flechita_izquierda.addEventListener('click', function () {
    cambiarImagen();
});

flechita_derecha.addEventListener('click', function () {
    cambiarImagen();
});

flecha_izquierda2.addEventListener('click', function () {
    cambiarCaracteristica('anterior');
});

flecha_derecha2.addEventListener('click', function () {
    cambiarCaracteristica('siguiente');
});

id.addEventListener('click', function () {
    const api = "http://localhost:3000/pokemon"; // Endpoint de tu API para obtener los Pokémon
    const label_pokemon = document.getElementById("carac_pokemon");
    fetch(api)
        .then(respuesta => respuesta.ok ? respuesta.json() : Promise.reject(respuesta))
        .then(data => {
            label_pokemon.innerText = data[indicePokemon].id;
        })
        .catch(error => {
            console.error('Error al cargar los datos JSON', error);
        });
});

name.addEventListener('click', function () {
    const api = "http://localhost:3000/pokemon"; // Endpoint de tu API para obtener los Pokémon
    const label_pokemon = document.getElementById("carac_pokemon");
    fetch(api)
        .then(respuesta => respuesta.ok ? respuesta.json() : Promise.reject(respuesta))
        .then(data => {
            label_pokemon.innerText = data[indicePokemon].nombre;
        })
        .catch(error => {
            console.error('Error al cargar los datos JSON', error);
        });
});

pok.addEventListener('click', function () {
    const api = "http://localhost:3000/pokemon"; // Endpoint de tu API para obtener los Pokémon
    const label_pokemon = document.getElementById("carac_pokemon");
    fetch(api)
        .then(respuesta => respuesta.ok ? respuesta.json() : Promise.reject(respuesta))
        .then(data => {
            label_pokemon.innerText = data[indicePokemon].no_pokemon;
        }
        )
        .catch(error => {
            console.error('Error al cargar los datos JSON', error);
        }
        );
});

cat.addEventListener('click', function () {
    const api = "http://localhost:3000/pokemon"; // Endpoint de tu API para obtener los Pokémon
    const label_pokemon = document.getElementById("carac_pokemon");
    fetch(api)
        .then(respuesta => respuesta.ok ? respuesta.json() : Promise.reject(respuesta))
        .then(data => {
            label_pokemon.innerText = data[indicePokemon].categoria;
        }
        )
        .catch(error => {
            console.error('Error al cargar los datos JSON', error);
        }
        );
});

tipo.addEventListener('click', function () {
    const api = "http://localhost:3000/pokemon"; // Endpoint de tu API para obtener los Pokémon
    const label_pokemon = document.getElementById("carac_pokemon");
    fetch(api)
        .then(respuesta => respuesta.ok ? respuesta.json() : Promise.reject(respuesta))
        .then(data => {
            label_pokemon.innerText = data[indicePokemon].tipo;
        }
        )
        .catch(error => {
            console.error('Error al cargar los datos JSON', error);
        }
        );
});

peso.addEventListener('click', function () {
    const api = "http://localhost:3000/pokemon"; // Endpoint de tu API para obtener los Pokémon
    const label_pokemon = document.getElementById("carac_pokemon");
    fetch(api)
        .then(respuesta => respuesta.ok ? respuesta.json() : Promise.reject(respuesta))
        .then(data => {
            label_pokemon.innerText = data[indicePokemon].peso;
        }
        )
        .catch(error => {
            console.error('Error al cargar los datos JSON', error);
        }
        );
});

altura.addEventListener('click', function () {
    const api = "http://localhost:3000/pokemon"; // Endpoint de tu API para obtener los Pokémon
    const label_pokemon = document.getElementById("carac_pokemon");
    fetch(api)
        .then(respuesta => respuesta.ok ? respuesta.json() : Promise.reject(respuesta))
        .then(data => {
            label_pokemon.innerText = data[indicePokemon].altura;
        }
        )
        .catch(error => {
            console.error('Error al cargar los datos JSON', error);
        }
        );
});

hab.addEventListener('click', function () {
    const api = "http://localhost:3000/pokemon"; // Endpoint de tu API para obtener los Pokémon
    const label_pokemon = document.getElementById("carac_pokemon");
    fetch(api)
        .then(respuesta => respuesta.ok ? respuesta.json() : Promise.reject(respuesta))
        .then(data => {
            label_pokemon.innerText = data[indicePokemon].habilidad;
        }
        )
        .catch(error => {
            console.error('Error al cargar los datos JSON', error);
        }
        );
});

deb.addEventListener('click', function () {
    const api = "http://localhost:3000/pokemon"; // Endpoint de tu API para obtener los Pokémon
    const label_pokemon = document.getElementById("carac_pokemon");
    fetch(api)
        .then(respuesta => respuesta.ok ? respuesta.json() : Promise.reject(respuesta))
        .then(data => {
            label_pokemon.innerText = data[indicePokemon].debilidad;
        }
        )
        .catch(error => {
            console.error('Error al cargar los datos JSON', error);
        }
        );
});

evo.addEventListener('click', function () {
    const api = "http://localhost:3000/pokemon"; // Endpoint de tu API para obtener los Pokémon
    const label_pokemon = document.getElementById("carac_pokemon");
    fetch(api)
        .then(respuesta => respuesta.ok ? respuesta.json() : Promise.reject(respuesta))
        .then(data => {
            label_pokemon.innerText = data[indicePokemon].evoluciones;
        }
        )
        .catch(error => {
            console.error('Error al cargar los datos JSON', error);
        }
        );
});

function cambiarImagen() {
    const api = "http://localhost:3000/pokemon"; // Endpoint de tu API para obtener los Pokémon

    fetch(api)
        .then(respuesta => respuesta.ok ? respuesta.json() : Promise.reject(respuesta))
        .then(data => {
            const imagenPokemon = document.getElementById("imagen_pokemon");
            const imagenActual = imagenPokemon.src;
            const imagen1 = data[indicePokemon].imagen1;
            const imagen2 = data[indicePokemon].imagen2;

            // Verificar si la imagen actual es la imagen1
            if (imagenActual === imagen1) {
                imagenPokemon.src = imagen2; // Cambiar a la imagen2
            } else {
                imagenPokemon.src = imagen1; // Cambiar a la imagen1
            }
        })
        .catch(error => {
            console.error('Error al cargar los datos JSON', error);
        });
}

let caracteristicaActual = 'nombre'; // Inicialmente, muestra el nombre del Pokémon

function cambiarCaracteristica(direccion) {
    const caracteristicas = ['id', 'nombre', 'no_pokemon', 'categoria', 'tipo', 'peso', 'altura', 'habilidad', 'debilidad', 'evoluciones'];

    // Obtener el índice de la característica actual
    let indiceCaracteristica = caracteristicas.indexOf(caracteristicaActual);

    // Verificar la dirección y ajustar el índice de la característica
    if (direccion === 'anterior') {
        indiceCaracteristica = (indiceCaracteristica === 0) ? caracteristicas.length - 1 : indiceCaracteristica - 1;
    } else if (direccion === 'siguiente') {
        indiceCaracteristica = (indiceCaracteristica === caracteristicas.length - 1) ? 0 : indiceCaracteristica + 1;
    } else {
        console.error('Dirección no válida');
        return;
    }

    const api = "http://localhost:3000/pokemon"; // Endpoint de tu API para obtener los Pokémon

    fetch(api)
        .then(respuesta => respuesta.ok ? respuesta.json() : Promise.reject(respuesta))
        .then(data => {
            const label_pokemon = document.getElementById("carac_pokemon");
            label_pokemon.innerText = data[indicePokemon][caracteristicas[indiceCaracteristica]];

            // Actualizar la característica actual
            caracteristicaActual = caracteristicas[indiceCaracteristica];
        })
        .catch(error => {
            console.error('Error al cargar los datos JSON', error);
        });
}



const pokemon = () => {
    const api = "http://localhost:3000/pokemon"; // Endpoint de tu API para obtener los Pokémon

    fetch(api)
        .then(respuesta => respuesta.ok ? respuesta.json() : Promise.reject(respuesta))
        .then(data => {
            const imagenPokemon = document.getElementById("imagen_pokemon");
            const mostrar_id = document.getElementById("mostrar_id");
            const label_pokemon = document.getElementById("carac_pokemon");
            imagenPokemon.src = data[indicePokemon].imagen1;
            mostrar_id.placeholder = data[indicePokemon].id;
            label_pokemon.innerText = data[indicePokemon].nombre;
        })
        .catch(error => {
            console.error('Error al cargar los datos JSON', error);
        });
}
