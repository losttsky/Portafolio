﻿namespace Cajero
{
    partial class OpcionesCajero
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btn_salir = new System.Windows.Forms.Button();
            this.btn_consulta = new System.Windows.Forms.Button();
            this.btn_retiro = new System.Windows.Forms.Button();
            this.btn_deposito = new System.Windows.Forms.Button();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.label4 = new System.Windows.Forms.Label();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.btn_regresar = new System.Windows.Forms.Button();
            this.btn_hacerDeposito = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.txt_monto = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.btn_regresar2 = new System.Windows.Forms.Button();
            this.btn_1000 = new System.Windows.Forms.Button();
            this.btn_200 = new System.Windows.Forms.Button();
            this.btn_600 = new System.Windows.Forms.Button();
            this.btn_100 = new System.Windows.Forms.Button();
            this.btn_400 = new System.Windows.Forms.Button();
            this.btn_50 = new System.Windows.Forms.Button();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.label5 = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.btn_regresar3 = new System.Windows.Forms.Button();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.txt_montoActual = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.btn_salirlogin = new System.Windows.Forms.Button();
            this.btn_Seguir = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.tabPage5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1001, 615);
            this.tabControl1.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            this.tabControl1.TabIndex = 11;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(108)))), ((int)(((byte)(148)))));
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.pictureBox1);
            this.tabPage1.Controls.Add(this.btn_salir);
            this.tabPage1.Controls.Add(this.btn_consulta);
            this.tabPage1.Controls.Add(this.btn_retiro);
            this.tabPage1.Controls.Add(this.btn_deposito);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage1.Size = new System.Drawing.Size(993, 586);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Principal";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(201, 100);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(556, 91);
            this.label2.TabIndex = 58;
            this.label2.Text = "Transacciones";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Cajero.Properties.Resources.atm_seguros;
            this.pictureBox1.Location = new System.Drawing.Point(11, 6);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(167, 116);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 13;
            this.pictureBox1.TabStop = false;
            // 
            // btn_salir
            // 
            this.btn_salir.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(167)))), ((int)(((byte)(206)))));
            this.btn_salir.FlatAppearance.BorderSize = 3;
            this.btn_salir.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_salir.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_salir.ForeColor = System.Drawing.Color.White;
            this.btn_salir.Location = new System.Drawing.Point(361, 447);
            this.btn_salir.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_salir.Name = "btn_salir";
            this.btn_salir.Size = new System.Drawing.Size(236, 94);
            this.btn_salir.TabIndex = 12;
            this.btn_salir.Text = "Salir";
            this.btn_salir.UseVisualStyleBackColor = false;
            this.btn_salir.Click += new System.EventHandler(this.Botones);
            // 
            // btn_consulta
            // 
            this.btn_consulta.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(167)))), ((int)(((byte)(206)))));
            this.btn_consulta.FlatAppearance.BorderSize = 3;
            this.btn_consulta.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_consulta.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_consulta.ForeColor = System.Drawing.Color.White;
            this.btn_consulta.Location = new System.Drawing.Point(361, 273);
            this.btn_consulta.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_consulta.Name = "btn_consulta";
            this.btn_consulta.Size = new System.Drawing.Size(236, 94);
            this.btn_consulta.TabIndex = 12;
            this.btn_consulta.Text = "Consulta";
            this.btn_consulta.UseVisualStyleBackColor = false;
            this.btn_consulta.Click += new System.EventHandler(this.Botones);
            // 
            // btn_retiro
            // 
            this.btn_retiro.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(167)))), ((int)(((byte)(206)))));
            this.btn_retiro.FlatAppearance.BorderSize = 3;
            this.btn_retiro.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_retiro.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_retiro.ForeColor = System.Drawing.Color.White;
            this.btn_retiro.Location = new System.Drawing.Point(60, 273);
            this.btn_retiro.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_retiro.Name = "btn_retiro";
            this.btn_retiro.Size = new System.Drawing.Size(236, 94);
            this.btn_retiro.TabIndex = 12;
            this.btn_retiro.Text = "Retiro";
            this.btn_retiro.UseVisualStyleBackColor = false;
            this.btn_retiro.Click += new System.EventHandler(this.Botones);
            // 
            // btn_deposito
            // 
            this.btn_deposito.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(167)))), ((int)(((byte)(206)))));
            this.btn_deposito.FlatAppearance.BorderSize = 3;
            this.btn_deposito.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_deposito.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_deposito.ForeColor = System.Drawing.Color.White;
            this.btn_deposito.Location = new System.Drawing.Point(676, 273);
            this.btn_deposito.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_deposito.Name = "btn_deposito";
            this.btn_deposito.Size = new System.Drawing.Size(236, 94);
            this.btn_deposito.TabIndex = 12;
            this.btn_deposito.Text = "Deposito";
            this.btn_deposito.UseVisualStyleBackColor = false;
            this.btn_deposito.Click += new System.EventHandler(this.Botones);
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(108)))), ((int)(((byte)(148)))));
            this.tabPage2.Controls.Add(this.label4);
            this.tabPage2.Controls.Add(this.pictureBox4);
            this.tabPage2.Controls.Add(this.btn_regresar);
            this.tabPage2.Controls.Add(this.btn_hacerDeposito);
            this.tabPage2.Controls.Add(this.textBox1);
            this.tabPage2.Controls.Add(this.txt_monto);
            this.tabPage2.Controls.Add(this.label13);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage2.Size = new System.Drawing.Size(993, 586);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Deposito";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(319, 49);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(352, 91);
            this.label4.TabIndex = 65;
            this.label4.Text = "Depósito";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::Cajero.Properties.Resources.atm_seguros;
            this.pictureBox4.Location = new System.Drawing.Point(11, 6);
            this.pictureBox4.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(167, 116);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 64;
            this.pictureBox4.TabStop = false;
            // 
            // btn_regresar
            // 
            this.btn_regresar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(167)))), ((int)(((byte)(206)))));
            this.btn_regresar.FlatAppearance.BorderSize = 3;
            this.btn_regresar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_regresar.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_regresar.ForeColor = System.Drawing.Color.White;
            this.btn_regresar.Location = new System.Drawing.Point(35, 502);
            this.btn_regresar.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_regresar.Name = "btn_regresar";
            this.btn_regresar.Size = new System.Drawing.Size(209, 58);
            this.btn_regresar.TabIndex = 61;
            this.btn_regresar.Text = "<<";
            this.btn_regresar.UseVisualStyleBackColor = false;
            this.btn_regresar.Click += new System.EventHandler(this.Botones);
            // 
            // btn_hacerDeposito
            // 
            this.btn_hacerDeposito.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(167)))), ((int)(((byte)(206)))));
            this.btn_hacerDeposito.FlatAppearance.BorderSize = 3;
            this.btn_hacerDeposito.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_hacerDeposito.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_hacerDeposito.ForeColor = System.Drawing.Color.White;
            this.btn_hacerDeposito.Location = new System.Drawing.Point(393, 402);
            this.btn_hacerDeposito.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_hacerDeposito.Name = "btn_hacerDeposito";
            this.btn_hacerDeposito.Size = new System.Drawing.Size(209, 58);
            this.btn_hacerDeposito.TabIndex = 60;
            this.btn_hacerDeposito.Text = "Depositar";
            this.btn_hacerDeposito.UseVisualStyleBackColor = false;
            this.btn_hacerDeposito.Click += new System.EventHandler(this.Depositar);
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(167)))), ((int)(((byte)(206)))));
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.ForeColor = System.Drawing.Color.White;
            this.textBox1.Location = new System.Drawing.Point(181, 276);
            this.textBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(97, 91);
            this.textBox1.TabIndex = 59;
            this.textBox1.Text = "Q.";
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txt_monto
            // 
            this.txt_monto.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(167)))), ((int)(((byte)(206)))));
            this.txt_monto.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_monto.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_monto.ForeColor = System.Drawing.Color.White;
            this.txt_monto.Location = new System.Drawing.Point(284, 276);
            this.txt_monto.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txt_monto.MaxLength = 5;
            this.txt_monto.Name = "txt_monto";
            this.txt_monto.Size = new System.Drawing.Size(504, 91);
            this.txt_monto.TabIndex = 58;
            this.txt_monto.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.White;
            this.label13.Location = new System.Drawing.Point(319, 193);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(365, 51);
            this.label13.TabIndex = 57;
            this.label13.Text = "Ingrese el monto: ";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(108)))), ((int)(((byte)(148)))));
            this.tabPage3.Controls.Add(this.pictureBox2);
            this.tabPage3.Controls.Add(this.label3);
            this.tabPage3.Controls.Add(this.btn_regresar2);
            this.tabPage3.Controls.Add(this.btn_1000);
            this.tabPage3.Controls.Add(this.btn_200);
            this.tabPage3.Controls.Add(this.btn_600);
            this.tabPage3.Controls.Add(this.btn_100);
            this.tabPage3.Controls.Add(this.btn_400);
            this.tabPage3.Controls.Add(this.btn_50);
            this.tabPage3.Location = new System.Drawing.Point(4, 25);
            this.tabPage3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(993, 586);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Retiro";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::Cajero.Properties.Resources.atm_seguros;
            this.pictureBox2.Location = new System.Drawing.Point(11, 17);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(167, 116);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 63;
            this.pictureBox2.TabStop = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(155, 102);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(625, 91);
            this.label3.TabIndex = 64;
            this.label3.Text = "Retiro Monetario";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btn_regresar2
            // 
            this.btn_regresar2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(167)))), ((int)(((byte)(206)))));
            this.btn_regresar2.FlatAppearance.BorderSize = 3;
            this.btn_regresar2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_regresar2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_regresar2.ForeColor = System.Drawing.Color.White;
            this.btn_regresar2.Location = new System.Drawing.Point(35, 502);
            this.btn_regresar2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_regresar2.Name = "btn_regresar2";
            this.btn_regresar2.Size = new System.Drawing.Size(209, 58);
            this.btn_regresar2.TabIndex = 62;
            this.btn_regresar2.Text = "<<";
            this.btn_regresar2.UseVisualStyleBackColor = false;
            this.btn_regresar2.Click += new System.EventHandler(this.Botones);
            // 
            // btn_1000
            // 
            this.btn_1000.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(167)))), ((int)(((byte)(206)))));
            this.btn_1000.FlatAppearance.BorderSize = 3;
            this.btn_1000.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_1000.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_1000.ForeColor = System.Drawing.Color.White;
            this.btn_1000.Location = new System.Drawing.Point(677, 370);
            this.btn_1000.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_1000.Name = "btn_1000";
            this.btn_1000.Size = new System.Drawing.Size(249, 58);
            this.btn_1000.TabIndex = 61;
            this.btn_1000.Text = "Q. 1000";
            this.btn_1000.UseVisualStyleBackColor = false;
            this.btn_1000.Click += new System.EventHandler(this.Retiro);
            // 
            // btn_200
            // 
            this.btn_200.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(167)))), ((int)(((byte)(206)))));
            this.btn_200.FlatAppearance.BorderSize = 3;
            this.btn_200.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_200.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_200.ForeColor = System.Drawing.Color.White;
            this.btn_200.Location = new System.Drawing.Point(677, 260);
            this.btn_200.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_200.Name = "btn_200";
            this.btn_200.Size = new System.Drawing.Size(249, 58);
            this.btn_200.TabIndex = 61;
            this.btn_200.Text = "Q. 200";
            this.btn_200.UseVisualStyleBackColor = false;
            this.btn_200.Click += new System.EventHandler(this.Retiro);
            // 
            // btn_600
            // 
            this.btn_600.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(167)))), ((int)(((byte)(206)))));
            this.btn_600.FlatAppearance.BorderSize = 3;
            this.btn_600.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_600.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_600.ForeColor = System.Drawing.Color.White;
            this.btn_600.Location = new System.Drawing.Point(356, 370);
            this.btn_600.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_600.Name = "btn_600";
            this.btn_600.Size = new System.Drawing.Size(249, 58);
            this.btn_600.TabIndex = 61;
            this.btn_600.Text = "Q. 600";
            this.btn_600.UseVisualStyleBackColor = false;
            this.btn_600.Click += new System.EventHandler(this.Retiro);
            // 
            // btn_100
            // 
            this.btn_100.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(167)))), ((int)(((byte)(206)))));
            this.btn_100.FlatAppearance.BorderSize = 3;
            this.btn_100.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_100.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_100.ForeColor = System.Drawing.Color.White;
            this.btn_100.Location = new System.Drawing.Point(356, 260);
            this.btn_100.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_100.Name = "btn_100";
            this.btn_100.Size = new System.Drawing.Size(249, 58);
            this.btn_100.TabIndex = 61;
            this.btn_100.Text = "Q. 100";
            this.btn_100.UseVisualStyleBackColor = false;
            this.btn_100.Click += new System.EventHandler(this.Retiro);
            // 
            // btn_400
            // 
            this.btn_400.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(167)))), ((int)(((byte)(206)))));
            this.btn_400.FlatAppearance.BorderSize = 3;
            this.btn_400.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_400.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_400.ForeColor = System.Drawing.Color.White;
            this.btn_400.Location = new System.Drawing.Point(45, 370);
            this.btn_400.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_400.Name = "btn_400";
            this.btn_400.Size = new System.Drawing.Size(249, 58);
            this.btn_400.TabIndex = 61;
            this.btn_400.Text = "Q. 400";
            this.btn_400.UseVisualStyleBackColor = false;
            this.btn_400.Click += new System.EventHandler(this.Retiro);
            // 
            // btn_50
            // 
            this.btn_50.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(167)))), ((int)(((byte)(206)))));
            this.btn_50.FlatAppearance.BorderSize = 3;
            this.btn_50.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_50.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_50.ForeColor = System.Drawing.Color.White;
            this.btn_50.Location = new System.Drawing.Point(40, 260);
            this.btn_50.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_50.Name = "btn_50";
            this.btn_50.Size = new System.Drawing.Size(249, 58);
            this.btn_50.TabIndex = 61;
            this.btn_50.Text = "Q. 50";
            this.btn_50.UseVisualStyleBackColor = false;
            this.btn_50.Click += new System.EventHandler(this.Retiro);
            // 
            // tabPage4
            // 
            this.tabPage4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(108)))), ((int)(((byte)(148)))));
            this.tabPage4.Controls.Add(this.label5);
            this.tabPage4.Controls.Add(this.pictureBox3);
            this.tabPage4.Controls.Add(this.btn_regresar3);
            this.tabPage4.Controls.Add(this.textBox2);
            this.tabPage4.Controls.Add(this.txt_montoActual);
            this.tabPage4.Controls.Add(this.label1);
            this.tabPage4.Location = new System.Drawing.Point(4, 25);
            this.tabPage4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(993, 586);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Consulta";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(300, 92);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(352, 91);
            this.label5.TabIndex = 65;
            this.label5.Text = "Consulta";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::Cajero.Properties.Resources.atm_seguros;
            this.pictureBox3.Location = new System.Drawing.Point(11, 17);
            this.pictureBox3.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(167, 116);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 64;
            this.pictureBox3.TabStop = false;
            // 
            // btn_regresar3
            // 
            this.btn_regresar3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(167)))), ((int)(((byte)(206)))));
            this.btn_regresar3.FlatAppearance.BorderSize = 3;
            this.btn_regresar3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_regresar3.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_regresar3.ForeColor = System.Drawing.Color.White;
            this.btn_regresar3.Location = new System.Drawing.Point(27, 497);
            this.btn_regresar3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_regresar3.Name = "btn_regresar3";
            this.btn_regresar3.Size = new System.Drawing.Size(209, 58);
            this.btn_regresar3.TabIndex = 62;
            this.btn_regresar3.Text = "<<";
            this.btn_regresar3.UseVisualStyleBackColor = false;
            this.btn_regresar3.Click += new System.EventHandler(this.Botones);
            // 
            // textBox2
            // 
            this.textBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(167)))), ((int)(((byte)(206)))));
            this.textBox2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox2.ForeColor = System.Drawing.Color.White;
            this.textBox2.Location = new System.Drawing.Point(180, 318);
            this.textBox2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox2.Name = "textBox2";
            this.textBox2.ReadOnly = true;
            this.textBox2.Size = new System.Drawing.Size(97, 91);
            this.textBox2.TabIndex = 61;
            this.textBox2.Text = "Q.";
            this.textBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txt_montoActual
            // 
            this.txt_montoActual.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(167)))), ((int)(((byte)(206)))));
            this.txt_montoActual.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_montoActual.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_montoActual.ForeColor = System.Drawing.Color.White;
            this.txt_montoActual.Location = new System.Drawing.Point(283, 318);
            this.txt_montoActual.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txt_montoActual.MaxLength = 7;
            this.txt_montoActual.Name = "txt_montoActual";
            this.txt_montoActual.ReadOnly = true;
            this.txt_montoActual.Size = new System.Drawing.Size(504, 91);
            this.txt_montoActual.TabIndex = 60;
            this.txt_montoActual.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(219, 226);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(526, 51);
            this.label1.TabIndex = 58;
            this.label1.Text = "Monto actual de la cuenta:";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tabPage5
            // 
            this.tabPage5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(108)))), ((int)(((byte)(148)))));
            this.tabPage5.Controls.Add(this.pictureBox5);
            this.tabPage5.Controls.Add(this.label6);
            this.tabPage5.Controls.Add(this.btn_salirlogin);
            this.tabPage5.Controls.Add(this.btn_Seguir);
            this.tabPage5.Location = new System.Drawing.Point(4, 25);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Size = new System.Drawing.Size(993, 586);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "Seleccion";
            // 
            // pictureBox5
            // 
            this.pictureBox5.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox5.Image = global::Cajero.Properties.Resources.atm_seguros;
            this.pictureBox5.Location = new System.Drawing.Point(9, 15);
            this.pictureBox5.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(108, 84);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox5.TabIndex = 65;
            this.pictureBox5.TabStop = false;
            // 
            // btn_salirlogin
            // 
            this.btn_salirlogin.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(167)))), ((int)(((byte)(206)))));
            this.btn_salirlogin.FlatAppearance.BorderSize = 3;
            this.btn_salirlogin.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_salirlogin.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_salirlogin.ForeColor = System.Drawing.Color.White;
            this.btn_salirlogin.Location = new System.Drawing.Point(540, 298);
            this.btn_salirlogin.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_salirlogin.Name = "btn_salirlogin";
            this.btn_salirlogin.Size = new System.Drawing.Size(338, 150);
            this.btn_salirlogin.TabIndex = 66;
            this.btn_salirlogin.Text = "No, deseo salir";
            this.btn_salirlogin.UseVisualStyleBackColor = false;
            this.btn_salirlogin.Click += new System.EventHandler(this.MasTransacciones);
            // 
            // btn_Seguir
            // 
            this.btn_Seguir.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(167)))), ((int)(((byte)(206)))));
            this.btn_Seguir.FlatAppearance.BorderSize = 3;
            this.btn_Seguir.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Seguir.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Seguir.ForeColor = System.Drawing.Color.White;
            this.btn_Seguir.Location = new System.Drawing.Point(140, 298);
            this.btn_Seguir.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_Seguir.Name = "btn_Seguir";
            this.btn_Seguir.Size = new System.Drawing.Size(338, 150);
            this.btn_Seguir.TabIndex = 67;
            this.btn_Seguir.Text = "Si, deseo hacer otra operacion";
            this.btn_Seguir.UseVisualStyleBackColor = false;
            this.btn_Seguir.Click += new System.EventHandler(this.MasTransacciones);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(124, 88);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(773, 182);
            this.label6.TabIndex = 68;
            this.label6.Text = "¿Desea realizar otra \r\ntransaccion?";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // OpcionesCajero
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(108)))), ((int)(((byte)(148)))));
            this.ClientSize = new System.Drawing.Size(1001, 615);
            this.ControlBox = false;
            this.Controls.Add(this.tabControl1);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "OpcionesCajero";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "OpcionesCajero";
            this.Shown += new System.EventHandler(this.OpcionesCajero_Shown);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox txt_monto;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button btn_hacerDeposito;
        private System.Windows.Forms.Button btn_1000;
        private System.Windows.Forms.Button btn_200;
        private System.Windows.Forms.Button btn_600;
        private System.Windows.Forms.Button btn_100;
        private System.Windows.Forms.Button btn_400;
        private System.Windows.Forms.Button btn_50;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox txt_montoActual;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_regresar;
        private System.Windows.Forms.Button btn_regresar2;
        private System.Windows.Forms.Button btn_regresar3;
        private System.Windows.Forms.Button btn_retiro;
        private System.Windows.Forms.Button btn_deposito;
        private System.Windows.Forms.Button btn_salir;
        private System.Windows.Forms.Button btn_consulta;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btn_salirlogin;
        private System.Windows.Forms.Button btn_Seguir;
        private System.Windows.Forms.PictureBox pictureBox5;
    }
}