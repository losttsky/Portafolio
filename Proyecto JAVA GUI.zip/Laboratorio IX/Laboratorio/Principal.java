
import java.awt.Image;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.UIManager;
import javax.swing.plaf.synth.SynthLookAndFeel;

public class Principal extends javax.swing.JFrame {

    public Principal() {
        initComponents();
        this.setLocationRelativeTo(this);
        this.setTitle("Laboratorio IX");
        SetImageLabel(backk, "img/back.jpg");
        
    }
    

        private void SetImageLabel(JLabel labelName, String root){
        
        ImageIcon image = new ImageIcon(root);
        Icon icon = new ImageIcon(image.getImage().getScaledInstance(labelName.getWidth(), labelName.getHeight(), Image.SCALE_DEFAULT));
        labelName.setIcon(icon);
        
    }

    @SuppressWarnings("unchecked")
 
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jDesktopPane1 = new javax.swing.JDesktopPane();
        backk = new javax.swing.JLabel();
        titulo = new javax.swing.JLabel();
        autor = new javax.swing.JLabel();
        ingresarAMedidas = new javax.swing.JButton();
        medidasLabel = new javax.swing.JLabel();
        ingresarAMonedas = new javax.swing.JButton();
        monedasLabel = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        titulo.setFont(new java.awt.Font("Segoe UI", 3, 18)); 
        titulo.setForeground(new java.awt.Color(255, 255, 255));
        titulo.setText("Laboratorio 9 - GUI");
        titulo.setBorder(new javax.swing.border.MatteBorder(null));

        autor.setFont(new java.awt.Font("Segoe UI", 3, 12)); 
        autor.setForeground(new java.awt.Color(255, 255, 255));
        autor.setText("Angelo Martinez ");

        ingresarAMedidas.setBackground(new java.awt.Color(51, 255, 0));
        ingresarAMedidas.setText("Entrar");
        ingresarAMedidas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ingresarAMedidasActionPerformed(evt);
            }
        });

        medidasLabel.setFont(new java.awt.Font("Segoe UI", 3, 12)); 
        medidasLabel.setForeground(new java.awt.Color(255, 255, 255));
        medidasLabel.setText("Medidas");

        ingresarAMonedas.setBackground(new java.awt.Color(51, 255, 0));
        ingresarAMonedas.setText("Entrar");
        ingresarAMonedas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ingresarAMonedasActionPerformed(evt);
            }
        });

        monedasLabel.setFont(new java.awt.Font("Segoe UI", 3, 12)); 
        monedasLabel.setForeground(new java.awt.Color(255, 255, 255));
        monedasLabel.setText("Conversion de monedas");

        jDesktopPane1.setLayer(backk, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jDesktopPane1.setLayer(titulo, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jDesktopPane1.setLayer(autor, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jDesktopPane1.setLayer(ingresarAMedidas, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jDesktopPane1.setLayer(medidasLabel, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jDesktopPane1.setLayer(ingresarAMonedas, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jDesktopPane1.setLayer(monedasLabel, javax.swing.JLayeredPane.DEFAULT_LAYER);

        javax.swing.GroupLayout jDesktopPane1Layout = new javax.swing.GroupLayout(jDesktopPane1);
        jDesktopPane1.setLayout(jDesktopPane1Layout);
        jDesktopPane1Layout.setHorizontalGroup(
            jDesktopPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jDesktopPane1Layout.createSequentialGroup()
                .addGroup(jDesktopPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jDesktopPane1Layout.createSequentialGroup()
                        .addGap(130, 130, 130)
                        .addGroup(jDesktopPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jDesktopPane1Layout.createSequentialGroup()
                                .addComponent(monedasLabel)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 22, Short.MAX_VALUE)
                                .addComponent(ingresarAMonedas))
                            .addGroup(jDesktopPane1Layout.createSequentialGroup()
                                .addComponent(titulo)
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addGroup(jDesktopPane1Layout.createSequentialGroup()
                                .addComponent(medidasLabel)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(ingresarAMedidas)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(backk, javax.swing.GroupLayout.DEFAULT_SIZE, 84, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jDesktopPane1Layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(autor)))
                .addContainerGap())
        );
        jDesktopPane1Layout.setVerticalGroup(
            jDesktopPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jDesktopPane1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jDesktopPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jDesktopPane1Layout.createSequentialGroup()
                        .addComponent(titulo)
                        .addGap(83, 83, 83)
                        .addGroup(jDesktopPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(ingresarAMedidas)
                            .addComponent(medidasLabel))
                        .addGap(75, 75, 75)
                        .addGroup(jDesktopPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(monedasLabel)
                            .addComponent(ingresarAMonedas))
                        .addGap(0, 78, Short.MAX_VALUE))
                    .addComponent(backk, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(autor)
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jDesktopPane1)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jDesktopPane1)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }

    private void ingresarAMonedasActionPerformed(java.awt.event.ActionEvent evt) {
        
        VentanaConversor newframe = new VentanaConversor();
        newframe.setVisible(true);
        this.dispose();
        
    }

    private void ingresarAMedidasActionPerformed(java.awt.event.ActionEvent evt) {
        
        VentanaMedidas newframe2 = new VentanaMedidas();
        newframe2.setVisible(true);
        this.dispose();
        
    }

    public static void main(String args[]) {

        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }


        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Principal().setVisible(true);
            }
        });
    }

    
    private javax.swing.JLabel autor;
    private javax.swing.JLabel backk;
    private javax.swing.JButton ingresarAMedidas;
    private javax.swing.JButton ingresarAMonedas;
    private javax.swing.JDesktopPane jDesktopPane1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel medidasLabel;
    private javax.swing.JLabel monedasLabel;
    private javax.swing.JLabel titulo;
    
}
