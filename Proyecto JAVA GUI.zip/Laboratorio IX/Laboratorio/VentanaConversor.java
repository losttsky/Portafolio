
import java.awt.Image;
import java.text.DecimalFormat;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

public class VentanaConversor extends javax.swing.JFrame {


    public VentanaConversor() {
        initComponents();
        this.setLocationRelativeTo(this);
        this.setTitle("Laboratorio IX - Monedas");
        SetImageLabel(imgUSD, "img/usd.png");
        SetImageLabel(imgEUR, "img/eur.jpg");
        SetImageLabel(imglib, "img/lib.png");
        SetImageLabel(imgQUETZ, "img/q.jpg");
        
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        monedas = new javax.swing.ButtonGroup();
        regresar = new javax.swing.JButton();
        tituloConversor = new javax.swing.JLabel();
        tituloCantidad = new javax.swing.JLabel();
        cantidad = new javax.swing.JTextField();
        tituloDesde = new javax.swing.JLabel();
        dolar = new javax.swing.JRadioButton();
        euro = new javax.swing.JRadioButton();
        libra = new javax.swing.JRadioButton();
        quetzal = new javax.swing.JRadioButton();
        tituloreusltado = new javax.swing.JLabel();
        conversion1 = new javax.swing.JTextField();
        conversion2 = new javax.swing.JTextField();
        conversion3 = new javax.swing.JTextField();
        converResult1 = new javax.swing.JLabel();
        converResult2 = new javax.swing.JLabel();
        converResult3 = new javax.swing.JLabel();
        imgUSD = new javax.swing.JLabel();
        imgEUR = new javax.swing.JLabel();
        imglib = new javax.swing.JLabel();
        imgQUETZ = new javax.swing.JLabel();
        limpiarbtn = new javax.swing.JButton();
        convertirBTN = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        regresar.setBackground(new java.awt.Color(255, 0, 0));
        regresar.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        regresar.setForeground(new java.awt.Color(255, 255, 255));
        regresar.setText("Regresar");
        regresar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                regresarActionPerformed(evt);
            }
        });

        tituloConversor.setFont(new java.awt.Font("Segoe UI", 3, 18)); // NOI18N
        tituloConversor.setText("Conversor de monedas");

        tituloCantidad.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        tituloCantidad.setText("Cantidad a convertir: ");

        cantidad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cantidadActionPerformed(evt);
            }
        });
        cantidad.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                cantidadKeyTyped(evt);
            }
        });

        tituloDesde.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        tituloDesde.setText("Convertir desde: ");

        monedas.add(dolar);
        dolar.setText("USD");

        monedas.add(euro);
        euro.setText("EUR");

        monedas.add(libra);
        libra.setText("LIBRA");

        monedas.add(quetzal);
        quetzal.setText("QUETZ");

        tituloreusltado.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        tituloreusltado.setText("Resultado de conversion: ");

        converResult1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        converResult2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        converResult3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        limpiarbtn.setBackground(new java.awt.Color(255, 51, 51));
        limpiarbtn.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        limpiarbtn.setForeground(new java.awt.Color(255, 255, 255));
        limpiarbtn.setText("Limpiar");
        limpiarbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                limpiarbtnActionPerformed(evt);
            }
        });

        convertirBTN.setBackground(new java.awt.Color(102, 255, 102));
        convertirBTN.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        convertirBTN.setText("Convertir");
        convertirBTN.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                convertirBTNActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(regresar)
                .addGap(0, 545, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(175, 175, 175)
                        .addComponent(tituloConversor))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(tituloCantidad, javax.swing.GroupLayout.PREFERRED_SIZE, 153, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(cantidad, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(tituloreusltado)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(conversion1, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(conversion2, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(conversion3, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(34, 34, 34)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(converResult1, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(converResult2, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(converResult3, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(limpiarbtn, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(48, 48, 48)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(tituloDesde)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(dolar, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(imgUSD, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(euro, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(libra, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(quetzal, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(imgEUR, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(imglib, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(imgQUETZ, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(convertirBTN, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(tituloConversor, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(tituloCantidad)
                    .addComponent(cantidad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tituloDesde))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(dolar)
                        .addGap(64, 64, 64)
                        .addComponent(tituloreusltado)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(conversion1, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(14, 14, 14)
                                        .addComponent(conversion2, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(conversion3, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(12, 12, 12)
                                        .addComponent(converResult2, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(converResult3, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))))
                            .addComponent(converResult1, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(imgUSD, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(imgEUR, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(euro))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(imglib, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(libra))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(imgQUETZ, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(quetzal))))
                .addGap(41, 41, 41)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(limpiarbtn, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(convertirBTN, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 85, Short.MAX_VALUE)
                .addComponent(regresar))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void regresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_regresarActionPerformed
        
        Principal newframe = new Principal();
        newframe.setVisible(true);
        this.dispose();
        
    }//GEN-LAST:event_regresarActionPerformed

    private void convertirBTNActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_convertirBTNActionPerformed
        
        double usd, eur, libr, quetz;
        DecimalFormat formato = new DecimalFormat("###.##");
        if(!cantidad.getText().equals("")){
            if(dolar.isSelected()){
                usd = Float.parseFloat(cantidad.getText());
                eur = usd*1.01f;
                libr = usd*0.89f;
                quetz = usd*7.82f;
                converResult1.setText(String.valueOf(formato.format(eur)));
                conversion1.setText("Euros");
                converResult2.setText(String.valueOf(formato.format(libr)));
                conversion2.setText("Libras");
                converResult3.setText(String.valueOf(formato.format(quetz)));
                conversion3.setText("Quetzales");
            }else if(euro.isSelected()){
                eur = Float.parseFloat(cantidad.getText());
                usd = eur*0.99f;
                libr = eur*0.88f;
                quetz = eur*7.75f;
                converResult1.setText(String.valueOf(formato.format(usd)));
                conversion1.setText("Dolares");
                converResult2.setText(String.valueOf(formato.format(libr)));
                conversion2.setText("Libras");
                converResult3.setText(String.valueOf(formato.format(quetz)));
                conversion3.setText("Quetzales");
            }else if(libra.isSelected()){
                libr = Float.parseFloat(cantidad.getText());
                usd = libr*1.13f;
                eur = libr*1.14f;
                quetz = libr*8.83f;
                converResult1.setText(String.valueOf(formato.format(usd)));
                conversion1.setText("Dolares");
                converResult2.setText(String.valueOf(formato.format(eur)));
                conversion2.setText("Euros");
                converResult3.setText(String.valueOf(formato.format(quetz)));
                conversion3.setText("Quetzales");
            }else if(quetzal.isSelected()){
                quetz = Float.parseFloat(cantidad.getText());
                usd = quetz*0.13f;
                eur = quetz*0.13f;
                libr = quetz*0.11f;
                converResult1.setText(String.valueOf(formato.format(usd)));
                conversion1.setText("Dolares");
                converResult2.setText(String.valueOf(formato.format(eur)));
                conversion2.setText("Euros");
                converResult3.setText(String.valueOf(formato.format(libr)));
                conversion3.setText("Libras");
            }else{
                JOptionPane.showMessageDialog(rootPane, "Falta seleccionar la opcion a convertir", "Error de opcion", JOptionPane.ERROR_MESSAGE);
            }
        }else {
            JOptionPane.showMessageDialog(rootPane, "Falta el valor a convertir", "Error de numero", JOptionPane.ERROR_MESSAGE);
            cantidad.requestFocus();
        }
        
    }//GEN-LAST:event_convertirBTNActionPerformed

    private void cantidadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cantidadActionPerformed

        //accion de boton
    }//GEN-LAST:event_cantidadActionPerformed

    private void cantidadKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_cantidadKeyTyped
        
        char c = evt.getKeyChar();
        boolean existe;
        int cont = 0;
        if(!Character.isDigit(c) && Character.valueOf(c)!=46 && Character.valueOf(c)!=8){
            getToolkit().beep();
            evt.consume();
            JOptionPane.showMessageDialog(rootPane, "Ingresa un numero", "Error de validacion", JOptionPane.ERROR_MESSAGE);
        }else{
            if(Character.valueOf(c)==46){
                cont++;
            }

        }
        if(cont>1){
            getToolkit().beep();
            evt.consume();
            JOptionPane.showMessageDialog(rootPane, "No pueden haber mas de 1 punto", "Error de validacion", JOptionPane.ERROR_MESSAGE);
            cont=1;
        }
        
    }//GEN-LAST:event_cantidadKeyTyped

    private void limpiarbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_limpiarbtnActionPerformed
        cantidad.setText("");
        monedas.clearSelection();
        converResult1.setText("");
        conversion1.setText("");
        converResult2.setText("");
        conversion2.setText("");
        converResult3.setText("");
        conversion3.setText("");
    }//GEN-LAST:event_limpiarbtnActionPerformed

    private void SetImageLabel(JLabel labelName, String root){
        
        ImageIcon image = new ImageIcon(root);
        Icon icon = new ImageIcon(image.getImage().getScaledInstance(labelName.getWidth(), labelName.getHeight(), Image.SCALE_DEFAULT));
        labelName.setIcon(icon);
        
    }

    public static void main(String args[]) {
 
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(VentanaConversor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(VentanaConversor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(VentanaConversor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(VentanaConversor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }



        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new VentanaConversor().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField cantidad;
    private javax.swing.JLabel converResult1;
    private javax.swing.JLabel converResult2;
    private javax.swing.JLabel converResult3;
    private javax.swing.JTextField conversion1;
    private javax.swing.JTextField conversion2;
    private javax.swing.JTextField conversion3;
    private javax.swing.JButton convertirBTN;
    private javax.swing.JRadioButton dolar;
    private javax.swing.JRadioButton euro;
    private javax.swing.JLabel imgEUR;
    private javax.swing.JLabel imgQUETZ;
    private javax.swing.JLabel imgUSD;
    private javax.swing.JLabel imglib;
    private javax.swing.JRadioButton libra;
    private javax.swing.JButton limpiarbtn;
    private javax.swing.ButtonGroup monedas;
    private javax.swing.JRadioButton quetzal;
    private javax.swing.JButton regresar;
    private javax.swing.JLabel tituloCantidad;
    private javax.swing.JLabel tituloConversor;
    private javax.swing.JLabel tituloDesde;
    private javax.swing.JLabel tituloreusltado;
    // End of variables declaration//GEN-END:variables
}
