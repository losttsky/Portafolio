import javax.swing.JOptionPane;

public class VentanaMedidas extends javax.swing.JFrame {


    public VentanaMedidas() {
        initComponents();
        this.setLocationRelativeTo(this);
        this.setTitle("Laboratorio IX - Medidas");
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        botonUnico = new javax.swing.ButtonGroup();
        regresar = new javax.swing.JButton();
        titulo = new javax.swing.JLabel();
        textoTitulo = new javax.swing.JLabel();
        cantidad = new javax.swing.JTextField();
        textoMedidas = new javax.swing.JLabel();
        longitud = new javax.swing.JRadioButton();
        masa = new javax.swing.JRadioButton();
        tiempo = new javax.swing.JRadioButton();
        volumen = new javax.swing.JRadioButton();
        area = new javax.swing.JRadioButton();
        jLabel1 = new javax.swing.JLabel();
        conversion1 = new javax.swing.JTextField();
        conversion2 = new javax.swing.JTextField();
        conversion3 = new javax.swing.JTextField();
        conversion4 = new javax.swing.JTextField();
        result4 = new javax.swing.JLabel();
        result1 = new javax.swing.JLabel();
        result2 = new javax.swing.JLabel();
        result3 = new javax.swing.JLabel();
        convertir = new javax.swing.JButton();
        limpiar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        regresar.setBackground(new java.awt.Color(255, 0, 0));
        regresar.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        regresar.setForeground(new java.awt.Color(255, 255, 255));
        regresar.setText("Regresar");
        regresar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                regresarActionPerformed(evt);
            }
        });

        titulo.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        titulo.setText("Conversor de medidas");

        textoTitulo.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        textoTitulo.setText("Cantidad a convertir: ");

        cantidad.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                cantidadKeyTyped(evt);
            }
        });

        textoMedidas.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        textoMedidas.setText("Medidas: ");

        botonUnico.add(longitud);
        longitud.setText("Longitud");

        botonUnico.add(masa);
        masa.setText("Masa");

        botonUnico.add(tiempo);
        tiempo.setText("Tiempo");

        botonUnico.add(volumen);
        volumen.setText("Volumen");

        botonUnico.add(area);
        area.setText("Área");

        jLabel1.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        jLabel1.setText("Conversiones Realizadas: ");

        result4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        result1.setBackground(new java.awt.Color(255, 255, 255));
        result1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        result2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        result3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        convertir.setBackground(new java.awt.Color(102, 255, 102));
        convertir.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        convertir.setText("Convertir");
        convertir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                convertirActionPerformed(evt);
            }
        });

        limpiar.setBackground(new java.awt.Color(255, 0, 0));
        limpiar.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        limpiar.setForeground(new java.awt.Color(255, 255, 255));
        limpiar.setText("Limpiar");
        limpiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                limpiarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(regresar)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 186, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(conversion1, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(conversion4, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(39, 39, 39)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(result4, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(result2, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(result1, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(result3, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addComponent(convertir, javax.swing.GroupLayout.DEFAULT_SIZE, 101, Short.MAX_VALUE)
                                            .addComponent(limpiar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))))
                        .addGap(56, 56, 56))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(textoTitulo, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cantidad, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(tiempo, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(volumen, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(textoMedidas, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(longitud, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(area, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addContainerGap())))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(conversion2, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(conversion3, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap())))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(titulo, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(175, 175, 175))
                    .addComponent(masa, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(titulo)
                .addGap(23, 23, 23)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(textoTitulo)
                    .addComponent(cantidad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(textoMedidas))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(longitud)
                    .addComponent(masa))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(tiempo)
                    .addComponent(volumen))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(area)
                .addGap(13, 13, 13)
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(conversion1, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(result1, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(convertir, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(16, 16, 16)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(conversion2, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(result2, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(limpiar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(conversion3, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(result3, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(conversion4, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(result4, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 52, Short.MAX_VALUE)
                .addComponent(regresar))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void regresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_regresarActionPerformed
        
        Principal newframe = new Principal();
        newframe.setVisible(true);
        this.dispose();
        
    }//GEN-LAST:event_regresarActionPerformed

    private void cantidadKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_cantidadKeyTyped
        char c = evt.getKeyChar();
        boolean existe;
        int cont = 0;
        if(!Character.isDigit(c) && Character.valueOf(c)!=46 && Character.valueOf(c)!=8){
            getToolkit().beep();
            evt.consume();
            JOptionPane.showMessageDialog(rootPane, "Ingresa un numero", "Error de validacion", JOptionPane.ERROR_MESSAGE);
        }else{
            if(Character.valueOf(c)==46){
                cont++;
            }

        }
        if(cont>1){
            getToolkit().beep();
            evt.consume();
            JOptionPane.showMessageDialog(rootPane, "No pueden haber mas de 1 punto", "Error de validacion", JOptionPane.ERROR_MESSAGE);
            cont=1;
        }
    }//GEN-LAST:event_cantidadKeyTyped

    private void convertirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_convertirActionPerformed
        
        double metro, centimetro, kilometro, milla;
        double kg, g, ton, lb;
        double seg, min, hor, ds;
        double litro, mlitro, onza, m2;
        double mtcuad, kmcuad, pie, pulgada;
        
        if(!cantidad.getText().equals("")){
        
            if(longitud.isSelected()){
                metro = Float.parseFloat(cantidad.getText());
                metro = metro*1;
                centimetro = metro * 100;
                kilometro = metro * 10000;
                milla = metro * 0.00062;
                
                result1.setText(String.valueOf(metro));
                conversion1.setText("Metros");
                result2.setText(String.valueOf(centimetro));
                conversion2.setText("Centimetros");
                result3.setText(String.valueOf(kilometro));
                conversion3.setText("Kilometros");
                result4.setText(String.valueOf(milla));
                conversion4.setText("Millas");
                
            }else if(masa.isSelected()){
                
                g = Float.parseFloat(cantidad.getText());
                kg = g*0.001;
                g = g*1;
                ton = g*1000000;
                lb = g*0.00220462;
                
                result1.setText(String.valueOf(kg));
                conversion1.setText("Kilogramos");
                result2.setText(String.valueOf(g));
                conversion2.setText("Gramos");
                result3.setText(String.valueOf(ton));
                conversion3.setText("Toneladas");
                result4.setText(String.valueOf(lb));
                conversion4.setText("Libras");
                
            }else if(tiempo.isSelected()){
                
                seg = Float.parseFloat(cantidad.getText());
                seg = seg*1;
                min = seg*0.016;
                hor = seg*0.00027;
                ds = seg* 0.0000115740;
                
                result1.setText(String.valueOf(seg));
                conversion1.setText("Segundos");
                result2.setText(String.valueOf(min));
                conversion2.setText("Minutos");
                result3.setText(String.valueOf(hor));
                conversion3.setText("Horas");
                result4.setText(String.valueOf(ds));
                conversion4.setText("Dias");
                
            }else if(volumen.isSelected()){
                
                litro = Float.parseFloat(cantidad.getText());
                litro = litro*1;
                mlitro = litro*1000;
                onza = litro*33.8;
                m2 = litro*1.001;
                
                result1.setText(String.valueOf(litro));
                conversion1.setText("Litros");
                result2.setText(String.valueOf(mlitro));
                conversion2.setText("Mililitro");
                result3.setText(String.valueOf(onza));
                conversion3.setText("OnzaLiquida");
                result4.setText(String.valueOf(m2));
                conversion4.setText("Metro cúbico");
                
            }else if(area.isSelected()){
                
                mtcuad = Float.parseFloat(cantidad.getText());
                kmcuad = mtcuad*1000000;
                pie = mtcuad*10.7;
                pulgada = mtcuad*1550;
                
                result1.setText(String.valueOf(mtcuad));
                conversion1.setText("Metro cuadrado");
                result2.setText(String.valueOf(kmcuad));
                conversion2.setText("Km Cuadrado");
                result3.setText(String.valueOf(pie));
                conversion3.setText("Pie");
                result4.setText(String.valueOf(pulgada));
                conversion4.setText("Pulgada");
            
            }else{
                JOptionPane.showMessageDialog(rootPane, "Falta seleccionar la opcion a convertir", "Error de opcion", JOptionPane.ERROR_MESSAGE);

            }
            
        }else{
            
            JOptionPane.showMessageDialog(rootPane, "Falta el valor a convertir", "Error de numero", JOptionPane.ERROR_MESSAGE);
            cantidad.requestFocus();
        }
                
    }//GEN-LAST:event_convertirActionPerformed

    private void limpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_limpiarActionPerformed
        cantidad.setText("");
        botonUnico.clearSelection();
        result1.setText("");
        conversion1.setText("");
        result2.setText("");
        conversion2.setText("");
        result3.setText("");
        conversion3.setText("");
        result4.setText("");
        conversion4.setText("");

    }//GEN-LAST:event_limpiarActionPerformed

    public static void main(String args[]) {

        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(VentanaMedidas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(VentanaMedidas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(VentanaMedidas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(VentanaMedidas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }


        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new VentanaMedidas().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JRadioButton area;
    private javax.swing.ButtonGroup botonUnico;
    private javax.swing.JTextField cantidad;
    private javax.swing.JTextField conversion1;
    private javax.swing.JTextField conversion2;
    private javax.swing.JTextField conversion3;
    private javax.swing.JTextField conversion4;
    private javax.swing.JButton convertir;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JButton limpiar;
    private javax.swing.JRadioButton longitud;
    private javax.swing.JRadioButton masa;
    private javax.swing.JButton regresar;
    private javax.swing.JLabel result1;
    private javax.swing.JLabel result2;
    private javax.swing.JLabel result3;
    private javax.swing.JLabel result4;
    private javax.swing.JLabel textoMedidas;
    private javax.swing.JLabel textoTitulo;
    private javax.swing.JRadioButton tiempo;
    private javax.swing.JLabel titulo;
    private javax.swing.JRadioButton volumen;
    // End of variables declaration//GEN-END:variables
}
