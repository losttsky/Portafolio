const host = 'localhost';
const port = 3000;

const express = require('express');
const mongolo = require('./mongo.js');
const cors = require('cors');

const app = express();
app.use(express.json());
app.use(express.static('public'));
app.use(cors());


const predio = require("./predio.js");



/////////////////////////////////////////////////////////////////////////////////////////////////////////////

app.get("/", inicio);

async function validarInicioSesion(correo, password) {
    const user = await mongolo.login(correo, password);

    if (!user) {
        return null;
    }

    if (user.Rol === "Admin" || user.Rol === "Cliente") {
        return user;
    } else {
        return null; 
    }
}

app.post("/login", async (req, res) => {
    const correo = req.body.correo;
    const password = req.body.password;

    const usuarioValido = await validarInicioSesion(correo, password);

    if (usuarioValido) {
        switch (usuarioValido.Rol) {
            case "Admin":
                res.json({ success: true, redirectTo: "/pages/admin.html" });
                break;
            case "Cliente":
                res.json({ success: true, redirectTo: "/pages/predio.html" });
                break;
            default:
                res.status(401).json({ success: false, message: "Rol de usuario no válido" });
        }
    } else {
        res.status(401).json({ success: false, message: "Usuario o contraseña incorrecta" });
    }
});


function inicio(peticion, resultado) {
    resultado.sendFile(__dirname + "/public/index.html");
}

app.listen(port, host, () => {
    console.log(`El servidor esta corriendo en http://${host}:${port}`);
});


//////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////            ENDPOINTS             ////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////


app.get('/Predio/Lista', predio.Lista);

//CRUD
app.get('/Predio/Obtener/:id', predio.ObtenerID);
app.post("/Predio/Crear/", predio.Crear)
app.put('/Predio/Modificar/:id', predio.Modificar);
app.delete('/Predio/Eliminar/:id', predio.Eliminar);

// GET http://localhost:3000/Predio/modificarVehiculos?filtro={"marca":"Toyota"}&cambios={"color":"Rojo","precio":20000}  
app.put('/Predio/modificarVehiculos/', predio.Modificarsss);

// Obtener Propiedades
app.get('/Predio/buscar', predio.ObtenerPropiedad);






