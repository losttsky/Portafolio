const autos = document.getElementById("Auto");

const URLsita = `http://localhost:3000/Predio/Lista`;

const DesplegarAutos = (URL) =>{
    fetch(URL)
    .then(respuesta => respuesta.ok? respuesta.json() : Promise.reject(respuesta))
    .then(data => {
        console.log(data);
        autos.innerHTML = "";
        data.forEach(element => {
            autos.innerHTML += `
            <img src="${element.fotos[0]}"" alt="Foto del carro" class="foto">
            <div class="card-info">
                <h2 class="nombre">${element.marca} ${element.linea} ${element.motor}</h2>
                <p class="marca">${element.marca}</p>
                <p class="linea">${element.linea}</p>
                <p class="motor">${element.motor}</p>
                <p class="transmision">${element.transmision}</p>
                <p class="kilometraje">${element.kilometraje}KM</p>
                <p class="color">${element.color}</p>
                <p class="precio">${element.precio} USD</p>
                <p class="tipo">${element.tipo}</p>
                <div class="year-container">
                    <p class="anio">${element.año}</p>
                </div>
            </div>
            `
        });
    })
};

DesplegarAutos(URLsita);