const host = 'localhost';
const puerto = 3000;


const Predio = {
    Lista: (req, res) => {


        const fs = require('fs'); //fs es fileSystem
        let elJson = fs.readFileSync('./predio.json');

        // aqui ya tenemos la info del json para manipular
        let data = JSON.parse(elJson);

        console.log(data);
        res.status(200).send(data);

    },ObtenerID: (req, res) => {
        console.log(req.params.id);

        const fs = require('fs'); //fs es fileSystem
        let elJson = fs.readFileSync('./predio.json');

        // aqui ya tenemos la info del json para manipular
        let data = JSON.parse(elJson);

        let posicion = -1;

        for (let i = 0; i < data.length; i++) {
            const element = data[i];

            if (element.id == req.params.id) {
                posicion = i;
            }
        }


        if (posicion == -1) {
            res.status(200).send("<h1>EL ID NO EXISTE EN EL JSON</h1>");
        } else {
            res.status(200).send(data[posicion]);
        }

    },

    Crear: (req, res) => {

        console.log(` Creando algo  nuevo `);

        // PASO1 - LEER JSON
        const fs = require('fs'); //fs es fileSystem
        let elJson = fs.readFileSync('./predio.json');
        let data = JSON.parse(elJson);



        // PASO 2 AVERIGUAR EL ID Y ASIGNARLO AL OBJETO
        let elNuevoDato = req.body;

        // averiguo el ultimo id 
        let posicion = 0;

        for (let i = 0; i < data.length; i++) {
            posicion = data[i].id;
        }

        posicion = posicion + 1

        // se lo asigno
        elNuevoDato.id = posicion;


        // PASO2.1 - AGREGAR AL OBJETO LO QUE TRAE EL BODY 
        data.push(elNuevoDato);


        // PASO3 - GUARDAR EL JSON
        //le caemos encima la JSON que existe
        let dataJson = JSON.stringify(data);
        fs.writeFile('./predio.json', dataJson, (error) => {
            if (error) console.log('hubo error al escribir');
            else console.log('JSON MODIFICADO CON EXITO');

        });

        console.log(req.body);
        res.status(204).send(elNuevoDato);


    },

    Modificar: (req, res) => {
        res.status(204).send("Transaccion modificada!");
        //Leer el Jason
        const fs = require(`fs`); //File System
        let elJson = fs.readFileSync(`./predio.json`);
        let data = JSON.parse(elJson);

        let posicion = -1;

        for (let i = 0; i < data.length; i++) {
            const element = data[i];

            if (element.id == req.params.id) {
                posicion = i;

                data[posicion].id = (req.body.id == null) ? data[posicion].id : req.body.id;

                data[posicion].marca = (req.body.marca == null) ? data[posicion].marca : req.body.marca;

                data[posicion].linea = (req.body.linea == null) ? data[posicion].linea : req.body.linea;

                data[posicion].año = (req.body.año == null) ? data[posicion].año : req.body.año;

                data[posicion].motor = (req.body.motor == null) ? data[posicion].motor : req.body.motor;

                data[posicion].transmision = (req.body.transmision == null) ? data[posicion].transmision : req.body.transmision;

                data[posicion].kilometraje = (req.body.kilometraje == null) ? data[posicion].kilometraje : req.body.kilometraje;

                data[posicion].color = (req.body.color == null) ? data[posicion].color : req.body.color;

                data[posicion].precio = (req.body.precio == null) ? data[posicion].precio : req.body.precio;

                data[posicion].fotos = (req.body.fotos == null) ? data[posicion].fotos : req.body.fotos;

                data[posicion].tipo = (req.body.tipo == null) ? data[posicion].tipo : req.body.tipo;

            }
        }

        let dataJson = JSON.stringify(data);
        fs.writeFile(`./predio.json`, dataJson, (error) => {
            if (error) {
                console.log('Error al escribir');
            } else {
                console.log('JSON modificado con exito');
            }
        });

    },

    Modificarsss: (req, res) => {
        const fs = require(`fs`);
        let elJson = fs.readFileSync('./predio.json');
        let data = JSON.parse(elJson);
        
        const filtro = JSON.parse(req.query.filtro);
        const cambio = JSON.parse(req.query.cambios);

        // Buscar todos los vehículos
        for (let i = 0; i < data.length; i++) {
            const vehiculo = data[i];

            // Verificar si el vehículo cumple con el filtro
            let cumpleFiltro = true;
            for (const element in filtro) {
                if (filtro.hasOwnProperty(element) && vehiculo[element] !== filtro[element]) {
                    cumpleFiltro = false;
                    break;
                }
            }

            // Si el vehículo cumple con el filtro, aplicar los cambios
            if (cumpleFiltro) {
                for (const element in cambio) {
                    if (cambio.hasOwnProperty(element)) {
                        vehiculo[element] = cambio[element];
                    }
                }
            }
        }

        // Convertir los datos modificados de nuevo a formato JSON
        let dataJson = JSON.stringify(data);

        // Escribir los cambios en el archivo JSON
        fs.writeFile('./predio.json', dataJson, (error) => {
            if (error) {
                console.log('Error al escribir en el JSON');
                res.status(500).send('Error al escribir en el JSON');
            } else {
                console.log('JSON modificado con exito');
                res.status(200).send('JSON modificado con exito');
            }
        });


    },

    Eliminar: (req, res) => {
        //Leer el Jason
        const fs = require(`fs`); //File System
        let elJson = fs.readFileSync(`./predio.json`);
        let data = JSON.parse(elJson);

        let posicion = -1;

        for (let i = 0; i < data.length; i++) {
            const element = data[i];

            if (element.id == req.params.id) {
                posicion = i;

                data.splice(posicion, 1);
            }
        }
        let dataJson = JSON.stringify(data);
        fs.writeFile(`./predio.json`, dataJson, (error) => {
            if (error) {
                console.log('Error al escribir');
            } else {
                console.log('JSON modificado con exito');
                res.status(204).send("Transacción Eliminada!");
            }
        });
    },

    
    ObtenerPropiedad: (req, res) => {
        const fs = require('fs'); //fs es fileSystem
        let elJson = fs.readFileSync('./predio.json');

        let data = JSON.parse(elJson);     

        // Filtramos los autos según los parámetros recibidos
        let resultados = data.filter(data => {
            return (!req.query.id || data.id == req.query.id) &&
                (!req.query.marca || data.marca.toLowerCase() === req.query.marca.toLowerCase()) &&
                (!req.query.linea || data.linea.toLowerCase() === req.query.linea.toLowerCase()) &&
                (!req.query.año || data.año == req.query.año) &&
                (!req.query.precioMin || data.precio >= req.query.precioMin) &&
                (!req.query.precioMax || data.precio <= req.query.precioMax) &&
                (!req.query.color || data.color.toLowerCase() === req.query.color.toLowerCase()) &&
                (!req.query.kilometrajeMin || data.kilometraje >= req.query.kilometrajeMin) &&
                (!req.query.kilometrajeMax || data.kilometraje <= req.query.kilometrajeMax) &&
                (!req.query.transmision || data.transmision.toLowerCase() === req.query.transmision.toLowerCase()) &&
                (!req.query.cilindrada || data.cilindrada.toLowerCase() === req.query.cilindrada.toLowerCase()) &&
                (!req.query.tipo || data.tipo.toLowerCase() === req.query.tipo.toLowerCase());
        });

        res.status(200).send(resultados);
    
    }
};
module.exports = Predio;
