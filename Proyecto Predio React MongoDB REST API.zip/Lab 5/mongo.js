const { MongoClient, ServerApiVersion } = require('mongodb');
const uri = "mongodb+srv://angelomartinez:contra1234@usuarioslab.syuvbgu.mongodb.net/?retryWrites=true&w=majority&appName=UsuariosLAB";

const client = new MongoClient(uri, {
  serverApi: {
    version: ServerApiVersion.v1,
    strict: true,
    deprecationErrors: true,
  }
});

async function run() {
  try {
    await client.connect();
    await client.db("admin").command({ ping: 1 });
    console.log("soy mongolo y si furulo");
  } finally {
    await client.close();
  }
}

async function login(correo, password) {
  try {
    await client.connect();
    console.log("Conexión exitosa a MongoDB");

    const db = client.db("Laboratorio");
    const collection = db.collection("Usuarios");
    const query = { Correo: correo, Contrasenia: password };
    const user = await collection.findOne(query); 

    if (user) {
      console.log("Usuario encontrado: " + user.Nombre);
      return user;
    } else {
      console.log("Usuario no encontrado");
      return null;
    }
  } catch (error) {
    console.error("Error durante el inicio de sesión:", error);
    return null;
  } finally {
    await client.close();
  }
}

run().catch(console.dir);
module.exports = { login };