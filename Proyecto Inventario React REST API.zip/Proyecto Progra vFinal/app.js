const express = require('express');
const cors = require('cors');
const inventario = require('./Leer.js');
const fs = require('fs');
const path = require('path');
const mongolo = require('./login.js');

const port = 3000;
const app = express();

app.use(cors());
app.use(express.json());
app.use(express.static("public"));
app.use("/static", express.static("public"));

// =======================  ENDPOINTS  ================================

const productosFilePath = path.join(__dirname, 'Yeisons', 'Productos.json');
const productosData = fs.readFileSync(productosFilePath, 'utf8');
const productos = JSON.parse(productosData);


app.post('/pagar', async (req, res) => {
    try {
        const items = req.body.items;

        for (const item of items) {
            const productId = item.id;
            const cantidad = item.cantidad;

            const producto = productos.find(prod => prod.id === productId);

            if (producto) {
                producto.cantidad -= cantidad;
            } else {
                console.error(`No se encontró ningún producto con el ID ${productId}`);
            }
        }

        const productosActualizadosJSON = JSON.stringify(productos, null, 2);

        fs.writeFile(productos, productosActualizadosJSON, (err) => {
            if (err) {
                console.error("Error al escribir en el archivo JSON de productos:", err);
            } else {
                console.log("Archivo JSON de productos actualizado correctamente");
            }
        });

        res.status(200).json({ success: true, message: "Pago procesado y productos restados del inventario correctamente" });
    } catch (error) {
        console.error("Error al procesar el pago y restar productos del inventario:", error);
        res.status(500).json({ success: false, message: "Error al procesar el pago y restar productos del inventario" });
    }
});



// Ruta para crear un nuevo pedido
app.post("/Pedidos/Crear", async (req, res) => {
    try {
        const { detalles, fecha_pedido, estado } = req.body;

        // Generar un nuevo ID para el pedido
        const nuevoId = generarNuevoIdPedido();

        // Crear el nuevo pedido
        const nuevoPedido = {
            id: nuevoId,
            detalles: detalles,
            fecha_pedido: fecha_pedido,
            estado: estado
        };

        // Guardar el nuevo pedido en el archivo JSON
        guardarPedidoEnJSON(nuevoPedido);

        // Enviar una respuesta al cliente
        res.status(200).json({ success: true, message: "Pedido creado exitosamente", pedido: nuevoPedido });
    } catch (error) {
        console.error("Error al crear el pedido:", error);
        res.status(500).json({ success: false, message: "Error al crear el pedido" });
    }
});

// Función para guardar un pedido en el archivo JSON de pedidos
function guardarPedidoEnJSON(nuevoPedido) {
    // Leer el archivo JSON de pedidos
    fs.readFile('Yeisons/Pedidos.json', 'utf8', (err, data) => {
        if (err) {
            console.error("Error al leer el archivo JSON de pedidos:", err);
        } else {
            let pedidos = JSON.parse(data);
            pedidos.push(nuevoPedido);

            // Convertir la lista de pedidos a formato JSON
            const pedidosJSON = JSON.stringify(pedidos, null, 2);

            // Escribir la lista de pedidos en el archivo JSON
            fs.writeFile('Yeisons/Pedidos.json', pedidosJSON, (err) => {
                if (err) {
                    console.error("Error al escribir en el archivo JSON de pedidos:", err);
                } else {
                    console.log("Pedido guardado en el archivo JSON de pedidos");
                }
            });
        }
    });
}

// Función para generar un nuevo ID de pedido
function generarNuevoIdPedido() {
    const timestamp = Date.now();
    const nuevoId = "PED" + timestamp;
    return nuevoId;
}

//PRODUCTOS
app.get('/Producto/Lista', inventario.Listax);
app.get("/Producto/Obtener/:id", inventario.Obtenerx);
app.post("/Producto/Crear", inventario.Crearx)
app.put('/Producto/Modificar/:id', inventario.Modificarx);
app.delete('/Producto/Eliminar/:id', inventario.Eliminarx);


//PROVEEDORES
app.get('/Proveedor/Lista', inventario.Listay);
app.get("/Proveedor/Obtener/:id", inventario.Obtenery);
app.post("/Proveedor/Crear/", inventario.Creary)
app.put('/Proveedor/Modificar/:id', inventario.Modificary);
app.delete('/Proveedor/Eliminar/:id', inventario.Eliminary);

//TRANSACCIONES
app.get('/Transacciones/Lista', inventario.Listat);
app.get("/Transacciones/Obtener/:id", inventario.Obtenert);
app.post("/Transacciones/Crear/", inventario.Creart)
app.put('/Transacciones/Modificar/:id', inventario.Modificart);
app.delete('/Transacciones/Eliminar/:id', inventario.Eliminart);
app.post("/Transacciones/CrearVenta", async (req, res) => {
    try {
        const { id_producto, sucursal, cantidad, monto } = req.body;

        await inventario.RestarProducto(id_producto, cantidad);

        await inventario.CrearTransaccion({
            tipo: 'venta',
            id_producto,
            sucursal,
            cantidad,
            monto,
            fecha: new Date().toISOString()
        });

        res.status(200).json({ success: true, message: "Transacción de venta creada exitosamente" });
    } catch (error) {
        console.error("Error al crear la transacción de venta:", error);
        res.status(500).json({ success: false, message: "Error al crear la transacción de venta" });
    }
});


//PEDIDOS
app.get('/Pedidos/Lista', inventario.Listap);
app.get("/Pedidos/Obtener/:id", inventario.Obtenerp);
app.post("/Pedidos/Crear/", inventario.Crearp)
app.put('/Pedidos/Modificar/:id', inventario.Modificarp);
app.delete('/Pedidos/Eliminar/:id', inventario.Eliminarp);


//=====================================================================

app.get("/", inicio);

async function validarInicioSesion(correo, password) {
    const user = await mongolo.login(correo, password);

    if (!user) {
        return null;
    }

    if (user.Rol === "Admin" || user.Rol === "Cliente" || user.Rol === "Proveedor") {
        return user;
    } else {
        return null; // Si el rol no es válido, retornar null
    }
}


app.post("/login", async (req, res) => {
    const correo = req.body.correo;
    const password = req.body.password;

    const usuarioValido = await validarInicioSesion(correo, password);

    if (usuarioValido) {
        switch (usuarioValido.Rol) {
            case "Admin":
                res.json({ success: true, redirectTo: "/admin.html" });
                break;
            case "Cliente":
                res.json({ success: true, redirectTo: "/cliente.html" });
                break;
            case "Proveedor":
                res.json({ success: true, redirectTo: "/proveedor.html" });
                break;
            default:
                res.status(401).json({ success: false, message: "Rol de usuario no válido" });
        }
    } else {
        res.status(401).json({ success: false, message: "Usuario o contraseña incorrecta" });
    }
});


function inicio(peticion, resultado) {
    resultado.sendFile(__dirname + "/public/index.html");
}

app.listen(port, () => {
    console.log(`Arrancando nuestra propia api en el puerto ${port} ...`);
});