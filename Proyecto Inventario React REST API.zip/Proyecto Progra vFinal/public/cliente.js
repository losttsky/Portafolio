const productitos = document.getElementById('Productito');
const cartItems = document.getElementById('cartItems');

const ConsumirProductos = () => {
    fetch(`http://localhost:3000/Producto/Lista`)
        .then(respuesta => respuesta.ok ? respuesta.json() : Promise.reject(respuesta))
        .then(data => {
            console.log(data);
            productitos.innerHTML = "";

            data.forEach(element => {
                const divProducto = document.createElement('div');
                divProducto.classList.add('product');
                divProducto.dataset.id = element.id;

                const imagen = document.createElement('img'); // Crear elemento de imagen
                imagen.src = element.imagen; // Establecer la URL de la imagen
                imagen.alt = element.nombre; // Establecer el texto alternativo

                const h3 = document.createElement('h3');
                h3.textContent = element.nombre;

                const pDescripcion = document.createElement('p');
                pDescripcion.textContent = element.descripcion;

                const pPrecio = document.createElement('p');
                pPrecio.classList.add('price');
                pPrecio.textContent = `$${element.precio_venta}`;

                const btnAgregar = document.createElement('button');
                btnAgregar.classList.add('add-to-cart-btn');
                btnAgregar.textContent = 'Agregar al carrito';
                btnAgregar.dataset.id = element.id;

                divProducto.appendChild(imagen); // Agregar la imagen al contenedor del producto
                divProducto.appendChild(h3);
                divProducto.appendChild(pDescripcion);
                divProducto.appendChild(pPrecio);
                divProducto.appendChild(btnAgregar);

                productitos.appendChild(divProducto);

                // Agregar event listener al botón "Agregar al carrito"
                btnAgregar.addEventListener('click', addToCartHandler);
            });
        })
        .catch(error => {
            console.error("Error al obtener los productos:", error);
        });
};

ConsumirProductos();

const addToCartHandler = (event) => {
    const productId = event.target.getAttribute('data-id');
    const productName = event.target.parentElement.querySelector('h3').innerText;
    const productPrice = event.target.parentElement.querySelector('.price').innerText;

    const li = document.createElement('li');
    li.textContent = `${productName} - ${productPrice}`;
    cartItems.appendChild(li);

    fetch('http://localhost:3000/Transacciones/CrearVenta', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            id_producto: productId,
            sucursal: "Centro 21",
            cantidad: 1,
            monto: parseFloat(productPrice.replace('$', ''))
        })
    })
        .then(respuesta => respuesta.json())
        .then(data => {
            if (data.success) {
                console.log("Transacción de venta agregada correctamente");
            } else {
                console.error("Error al agregar la transacción de venta:", data.message);
            }
        })
        .catch(error => {
            console.error("Error al agregar la transacción de venta:", error);
        });
};



document.addEventListener('DOMContentLoaded', function () {

    const logoutOpenButton = document.getElementById('logoutOpenButton');
    const offcanvas = document.getElementById('offcanvas');

    logoutOpenButton.addEventListener('click', function () {
        offcanvas.style.display = 'block';
    });

    const logoutButton = document.getElementById('logoutButton');
    logoutButton.addEventListener('click', function () {
        // Redireccionar a la página de inicio de sesión
        window.location.href = './index.html';
    });


    const checkoutButton = document.getElementById('checkoutButton');
    const eliminarPedidos = document.getElementById('cartItems');

    checkoutButton.addEventListener('click', async function () {
        alert("Compra realizada exitosamente");

        try {
            const response = await fetch('http://localhost:3000/Pedidos/Crear', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    id: "PED005",
                    id_producto: "P005",
                    id_proveedor: "PRV002",
                    cantidad: 85,
                    fecha_pedido: "2024-03-19",
                    estado: "en proceso"
                })
            });

            const data = await response.json();

            if (data.success) {
                console.log("Pedido agregado exitosamente");
                eliminarPedidos.innerHTML = ""

            } else {
                console.error("Error al agregar el pedido:", data.message);
            }
        } catch (error) {
            console.error("Error al agregar el pedido:", error);
        }
    });
});

function generarNuevoIdPedido() {
    const timestamp = Date.now();
    const nuevoId = "PED" + timestamp;
    return nuevoId;
}
