const logoutOpenButton = document.getElementById("logoutOpenButton");
const offcanvas = document.getElementById("offcanvas");
const logoutButton = document.getElementById("logoutButton");

logoutOpenButton.addEventListener("click", function () {
    offcanvas.style.display = "block";
});

logoutButton.addEventListener("click", function () {
    window.location.href = "../admin.html";
});

// Hacer fetch de los datos del inventario y mostrar productos en la tabla
fetch('http://localhost:3000/Producto/Lista')
    .then(response => response.json())
    .then(data => {
        const tableBody = document.querySelector('tbody');
        data.forEach(product => {
            const newRow = document.createElement('tr');
            newRow.innerHTML = `
                        <td>${product.id}</td>
                        <td>${product.nombre}</td>
                        <td>${product.descripcion}</td>
                        <td>${product.categoria}</td>
                        <td>${product.id_proveedor}</td>
                        <td>${product.ubicacion}</td>
                        <td>${product.costo_unitario}</td>
                        <td>${product.precio_venta}</td>
                        <td>${product.sucursales.map(sucursal => `${sucursal.sucursal}: ${sucursal.cantidad_disponible}`).join('<br>')}</td>
                        <td>${product.color}</td>
                        <td><img src="${product.imagen}" alt="${product.nombre}" width="100"></td>
                    `;
            tableBody.appendChild(newRow);

            // Verificar si la cantidad disponible es menor que 80 y resaltar el borde del producto en rojo
            product.sucursales.forEach(sucursal => {
                if (sucursal.cantidad_disponible < 20) {
                    newRow.style.border = "5px dashed red";
                }
            });
        });
    })
    .catch(error => {
        console.error('Error de red:', error);
    });
