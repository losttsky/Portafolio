const logoutOpenButton = document.getElementById("logoutOpenButton");
const offcanvas = document.getElementById("offcanvas");
const logoutButton = document.getElementById("logoutButton");

logoutOpenButton.addEventListener("click", function () {
    offcanvas.style.display = "block";
});

logoutButton.addEventListener("click", function () {
    window.location.href = "../admin.html";
});

// Hacer fetch de los datos de proveedores y mostrarlos en la tabla
fetch('http://localhost:3000/Proveedor/Lista')
    .then(response => response.json())
    .then(data => {
        const tableBody = document.querySelector('tbody');
        data.forEach(proveedor => {
            const newRow = document.createElement('tr');
            newRow.innerHTML = `
                <td>${proveedor.id}</td>
                <td>${proveedor.nombre}</td>
                <td>${proveedor.contacto}</td>
                <td>${proveedor.direccion}</td>
                <td>${proveedor.terminos_pago}</td>
            `;
            tableBody.appendChild(newRow);
        });
    })
    .catch(error => {
        console.error('Error de red:', error);
    });
