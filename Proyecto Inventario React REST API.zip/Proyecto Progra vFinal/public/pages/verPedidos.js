// Obtener referencias a los elementos HTML relevantes
const logoutOpenButton = document.getElementById("logoutOpenButton");
const offcanvas = document.getElementById("offcanvas");
const logoutButton = document.getElementById("logoutButton");

// Mostrar el menú de salida al hacer clic en el botón correspondiente
logoutOpenButton.addEventListener("click", function () {
    offcanvas.style.display = "block";
});

// Redirigir al usuario a la página de inicio de sesión al hacer clic en el botón de salida
logoutButton.addEventListener("click", function () {
    window.location.href = "../admin.html";
});

// Hacer fetch de los datos de pedidos y mostrarlos en la tabla
fetch('http://localhost:3000/Pedidos/Lista')
    .then(response => response.json())
    .then(data => {
        const tableBody = document.getElementById('pedidoTableBody'); // Seleccionamos el tbody de la tabla de pedidos
        data.forEach(pedido => {
            const newRow = document.createElement('tr');
            newRow.innerHTML = `
                <td>${pedido.id}</td>
                <td>${pedido.id_producto}</td>
                <td>${pedido.id_proveedor}</td>
                <td>${pedido.cantidad}</td>
                <td>${pedido.fecha_pedido}</td>
                <td>${pedido.estado}</td>
            `;
            tableBody.appendChild(newRow);
        });
    })
    .catch(error => {
        console.error('Error de red:', error);
    });

