const logoutOpenButton = document.getElementById("logoutOpenButton");

const offcanvas = document.getElementById("offcanvas");

const logoutButton = document.getElementById("logoutButton");

logoutOpenButton.addEventListener("click", function () {
    offcanvas.style.display = "block";
});

logoutButton.addEventListener("click", function () {
    window.location.href = "../admin.html";
});

fetch('http://localhost:3000/Transacciones/Lista')
    .then(response => response.json())
    .then(data => {
        const tableBody = document.getElementById('transaccionTableBody');
        data.forEach(transaccion => {
            const newRow = document.createElement('tr');
            newRow.innerHTML = `
                <td>${transaccion.tipo}</td>
                <td>${transaccion.id_producto}</td>
                <td>${transaccion.sucursal}</td>
                <td>${transaccion.cantidad}</td>
                <td>${transaccion.monto}</td>
                <td>${new Date(transaccion.fecha).toLocaleString()}</td>
            `;
            tableBody.appendChild(newRow);
        });
    })
    .catch(error => {
        console.error('Error de red:', error);
    });
