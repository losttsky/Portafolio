const AgregarProducto = (nuevoProducto) => {
    fetch('http://localhost:3000/Producto/Crear', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(nuevoProducto)
    })
    .then(respuesta => {
        if (respuesta.ok) {
            console.log('Producto agregado exitosamente.');
        } else {
            console.error('Error al agregar el producto:', respuesta.statusText);
        }
    })
    .catch(error => {
        console.error('Error de red:', error);
    });
};



const logoutOpenButton = document.getElementById("logoutOpenButton");

const offcanvas = document.getElementById("offcanvas");

const logoutButton = document.getElementById("logoutButton");

logoutOpenButton.addEventListener("click", function () {
    offcanvas.style.display = "block";
});

logoutButton.addEventListener("click", function () {
    window.location.href = "../admin.html";
});


const addProductForm = document.getElementById("addProductForm");
addProductForm.addEventListener("submit", function (event) {
    event.preventDefault();

    const PNombre = document.getElementById("productName").value;
    const PDrescripcion = document.getElementById("productDescription").value;
    const PCategoria = document.getElementById("productCategory").value;
    const PProveedor = document.getElementById("productSupplierId").value;
    const PUbicacion = document.getElementById("productLocation").value;
    const PCosto = parseFloat(document.getElementById("productUnitCost").value);
    const PPrecio = parseFloat(document.getElementById("productSalePrice").value);
    const PSucursal = parseFloat(document.getElementById("productSucursal").value);
    const PCantidad = parseFloat(document.getElementById("productCantidad").value);
    const PColor = document.getElementById("productColor").value;
    const PImagen = document.getElementById("productImage").value;

    const nuevoProducto = {
        nombre: PNombre,
        descripcion: PDrescripcion,
        categoria: PCategoria,
        id_proveedor: PProveedor,
        ubicacion: PUbicacion,
        costo_unitario: PCosto,
        precio_venta: PPrecio,
        sucursales: [
                {
                    sucursal: PSucursal,
                    cantidad_disponible: PCantidad
                }
            ],
        color: PColor,
        imagen: PImagen
    };

    AgregarProducto(nuevoProducto);

    
    console.log("Producto agregado:", product);
});