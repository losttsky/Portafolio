const EliminarProducto = (IdProducto) => {
    fetch(`http://localhost:3000/Producto/Eliminar/${IdProducto}`, {
        method: 'DELETE',
    })
    .then(respuesta => {
        if (respuesta.ok) {
            console.log('Producto eliminado exitosamente.');
        } else {
            console.error('Error al eliminar el producto:', respuesta.statusText);
        }
    })
    .catch(error => {
        console.error('Error de red:', error);
    });
};

const logoutOpenButton = document.getElementById("logoutOpenButton");

const offcanvas = document.getElementById("offcanvas");

const logoutButton = document.getElementById("logoutButton");

logoutOpenButton.addEventListener("click", function () {
    offcanvas.style.display = "block";
});

logoutButton.addEventListener("click", function () {
    window.location.href = "../admin.html"; 
});

// Manejar el envío del formulario para eliminar producto
const deleteProductForm = document.getElementById("deleteProductForm");
deleteProductForm.addEventListener("submit", function (event) {
    const productId = document.getElementById("productId").value;

    if (confirm("¿Estás seguro de que deseas eliminar este producto?")) {
        EliminarProducto(productId);

        console.log("Producto eliminado:", productId);
    }
});

