const EliminarProveedor = (idProveedor) => {
    fetch(`http://localhost:3000/Proveedor/Eliminar/${idProveedor}`, {
        method: 'DELETE',
    })
    .then(respuesta => {
        if (respuesta.ok) {
            alert('Proveedor eliminado exitosamente.');
            location.reload(); // Recargar la página para reflejar los cambios
        } else {
            console.error('Error al eliminar el proveedor:', respuesta.statusText);
        }
    })
    .catch(error => {
        console.error('Error de red:', error);
    });
};

const logoutOpenButton = document.getElementById("logoutOpenButton");
const offcanvas = document.getElementById("offcanvas");
const logoutButton = document.getElementById("logoutButton");

logoutOpenButton.addEventListener("click", function () {
    offcanvas.style.display = "block";
});

logoutButton.addEventListener("click", function () {
    window.location.href = "../admin.html"; 
});

// Manejar el envío del formulario para eliminar proveedor
const deleteSupplierForm = document.getElementById("deleteSupplierForm");
deleteSupplierForm.addEventListener("submit", function (event) {
    event.preventDefault();

    const supplierId = document.getElementById("supplierId").value;

    if (confirm("¿Estás seguro de que deseas eliminar este proveedor?")) {
        EliminarProveedor(supplierId);
    }
});
