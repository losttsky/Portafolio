const ModificarProducto = (IdProducto, productoModificado) => {
    fetch(`http://localhost:3000/Producto/Modificar/${IdProducto}`, {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(productoModificado)
    })
    .then(respuesta => {
        if (respuesta.ok) {
            console.log('Producto modificado exitosamente.');
        } else {
            console.error('Error al modificar el producto:', respuesta.statusText);
        }
    })
    .catch(error => {
        console.error('Error de red:', error);
    });
};


const logoutOpenButton = document.getElementById("logoutOpenButton");

const offcanvas = document.getElementById("offcanvas");

const logoutButton = document.getElementById("logoutButton");

logoutOpenButton.addEventListener("click", function () {
    // Mostrar el offcanvas
    offcanvas.style.display = "block";
});

logoutButton.addEventListener("click", function () {
    window.location.href = "../admin.html"; 
});


const ModificarProductoss = document.getElementById("modifyProductForm");
ModificarProductoss.addEventListener("submit", function (event) {
    event.preventDefault();
    const productId = document.getElementById("productId").value;
    const productName = document.getElementById("productName").value;
    const productDescription = document.getElementById("productDescription").value;
    const productCategory = document.getElementById("productCategory").value;
    const productSupplierId = document.getElementById("productSupplierId").value;
    const productLocation = document.getElementById("productLocation").value;
    const productUnitCost = parseFloat(document.getElementById("productUnitCost").value);
    const productSalePrice = parseFloat(document.getElementById("productSalePrice").value);
    const productColor = document.getElementById("productColor").value;
    const productImage = document.getElementById("productImage").value;

    // Modificar Producto
    const productoModificado = {
        nombre: productName,
        descripcion: productDescription,
        categoria: productCategory,
        id_proveedor: productSupplierId,
        ubicacion: productLocation,
        costo_unitario: productUnitCost,
        precio_venta: productSalePrice,
        color: productColor,
        imagen: productImage
    };

    ModificarProducto(productId, productoModificado);

});