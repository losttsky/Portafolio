document.addEventListener('DOMContentLoaded', function() {
    const addSupplierForm = document.getElementById("addSupplierForm");

    addSupplierForm.addEventListener("submit", function(event) {
        event.preventDefault(); // Prevenir el envío por defecto del formulario

        // Recoger los valores del formulario
        const supplierId = document.getElementById("supplierId").value;
        const supplierName = document.getElementById("supplierName").value;
        const supplierContactName = document.getElementById("supplierContactName").value;
        const supplierContactPhone = document.getElementById("supplierContactPhone").value;
        const supplierContactEmail = document.getElementById("supplierContactEmail").value;
        const supplierAddress = document.getElementById("supplierAddress").value;
        const supplierPaymentTerms = document.getElementById("supplierPaymentTerms").value;

        const nuevoProveedor = {
            id: supplierId,
            nombre: supplierName,
            nombreContacto: supplierContactName,
            telefonoContacto: supplierContactPhone,
            emailContacto: supplierContactEmail,
            direccion: supplierAddress,
            terminosPago: supplierPaymentTerms
        };

        AgregarProveedor(nuevoProveedor);
    });

    const AgregarProveedor = (nuevoProveedor) => {
        fetch('http://localhost:3000/Proveedor/Crear/', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(nuevoProveedor)
        })
        .then(respuesta => respuesta.json())
        .then(data => {
            if (data.exito) {
                console.log('Proveedor agregado exitosamente.', data);
                // Opcional: limpiar el formulario o redirigir al usuario
            } else {
                console.error('Error al agregar el proveedor:', data.mensaje);
            }
        })
        .catch(error => {
            console.error('Error de red:', error);
        });
    };
});
