const formsito = document.getElementById("form");

formsito.addEventListener("submit", function(event) {
    event.preventDefault();

    const correo = document.getElementById("correo").value;
    const password = document.getElementById("password").value;

    const data = {
        correo: correo,
        password: password
    }

    fetch("/login", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(data)
    })
    .then(response => {
        if (response.ok) {
            return response.json();
        } else {
            throw new Error("Error en la solicitud");
        }
    })
    .then(data => {
        if (data.success) {
            window.location.href = data.redirectTo;
        } else {
            alert(data.message);
        }
    })
    .catch(error => {
        console.error("Error:", error);
        alert("Error en la solicitud. Por favor, inténtalo de nuevo más tarde.");
    });
});
