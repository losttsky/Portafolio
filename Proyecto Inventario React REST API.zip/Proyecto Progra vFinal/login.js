const { MongoClient, ServerApiVersion } = require('mongodb');
const uri = "mongodb+srv://angelomartinez:Contraseña1234@usuarios.ysk3iio.mongodb.net/?retryWrites=true&w=majority&appName=Usuarios";

// Create a MongoClient with a MongoClientOptions object to set the Stable API version
const client = new MongoClient(uri, {
  serverApi: {
    version: ServerApiVersion.v1,
    strict: true,
    deprecationErrors: true,
  }
});

async function run() {
  try {
    // Connect the client to the server	(optional starting in v4.7)
    await client.connect();
    // Send a ping to confirm a successful connection
    await client.db("admin").command({ ping: 1 });
    console.log("soy mongolo y si furulo");
  } finally {
    // Ensures that the client will close when you finish/error
    await client.close();
  }
}

async function login(correo, password) {
  try {
    await client.connect();
    console.log("Conexión exitosa a MongoDB");

    const db = client.db("Usuarios");
    const collection = db.collection("Usuarios");
    const query = { Correo: correo, Contrasenia: password };
    const user = await collection.findOne(query); 

    if (user) {
      console.log("Usuario encontrado: " + user.Nombre);
      return user;
    } else {
      console.log("Usuario no encontrado");
      return null;
    }
  } catch (error) {
    console.error("Error durante el inicio de sesión:", error);
    return null;
  } finally {
    // Asegurar que el cliente se cierre después de la operación
    await client.close();
  }
}




run().catch(console.dir);

module.exports = { login };