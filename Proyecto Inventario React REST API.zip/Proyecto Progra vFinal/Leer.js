const host = "localhost";
const port = 3000;
// x = Producto  |  y = Proveedor
const inventario = {

    ////////////////////////////////////////////////////////////////////////////////////
    //////////////////////////////////// PRODUCTOS /////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////////////////

    Listax: (req, res) => {
        const fs = require('fs'); //fs es fileSystem
        let elJson = fs.readFileSync('./Yeisons/Productos.json');

        // aqui ya tenemos la info del json para manipular
        let data = JSON.parse(elJson);

        console.log(data);
        res.status(200).send(data);

    },

    Obtenerx: (req, res) => {
        console.log(req.params.id);

        const fs = require('fs'); //fs es fileSystem
        let elJson = fs.readFileSync('./Yeisons/Productos.json');

        // aqui ya tenemos la info del json para manipular
        let data = JSON.parse(elJson);
        let data1 = 0;
        let posicion = -1;

        for (let i = 0; i < data.length; i++) {
            const element = data[i];


            if (element.id == req.params.id) {
                posicion = i;
            }
        }


        if (posicion == -1) {
            res.status(200).send("<h1>EL ID NO EXISTE EN EL JSON</h1>");
        } else {
            res.status(200).send(data[posicion]);
        }
    },

    Crearx: (req, res) => {


        console.log(` Creando algo  nuevo `);

        // PASO1 - LEER JSON
        const fs = require('fs'); //fs es fileSystem
        let elJson = fs.readFileSync('./Yeisons/Productos.json');
        let data = JSON.parse(elJson);



        // PASO 2 AVERIGUAR EL ID Y ASIGNARLO AL OBJETO
        let elNuevoDato = req.body;

        // averiguo el ultimo id 
        let posicion = 0;

        for (let i = 0; i < data.length; i++) {
            posicion = parseInt(data[i].id.substring(1));
        }

        posicion = posicion + 1

        // se lo asigno
        if ((posicion) < 10) {
            elNuevoDato.id = "P000" + posicion;
        } else if ((posicion + 1) < 100) {
            elNuevoDato.id = "P00" + posicion;
        } else if ((posicion + 1) < 1000) {
            elNuevoDato.id = "P0" + posicion;
        } else {
            elNuevoDato.id = "P" + posicion;
        }

        // PASO2.1 - AGREGAR AL OBJETO LO QUE TRAE EL BODY 
        data.push(elNuevoDato);


        // PASO3 - GUARDAR EL JSON
        //le caemos encima la JSON que existe
        let dataJson = JSON.stringify(data);
        fs.writeFile('./Yeisons/Productos.json', dataJson, (error) => {
            if (error) console.log('hubo error al escribir');
            else console.log('JSON MODIFICADO CON EXITO');

        });

        console.log(req.body);
        res.status(204).send(elNuevoDato);


    },

    Modificarx: (req, res) => {
        res.status(204).send("Producto modificado!");
        //Leer el Jason
        const fs = require(`fs`); //File System
        let elJson = fs.readFileSync(`./Yeisons/Productos.json`);
        let data = JSON.parse(elJson);

        let posicion = -1;

        for (let i = 0; i < data.length; i++) {
            const element = data[i];

            if (element.id == req.params.id) {
                posicion = i;

                data[posicion].nombre = (req.body.nombre == null || req.body.nombre == "") ? data[posicion].nombre : req.body.nombre;

                data[posicion].descripcion = (req.body.descripcion == null || req.body.descripcion == "") ? data[posicion].descripcion : req.body.descripcion;

                data[posicion].categoria = (req.body.categoria == null || req.body.categoria == "") ? data[posicion].categoria : req.body.categoria;

                data[posicion].id_proveedor = (req.body.id_proveedor == null || req.body.id_proveedor == "") ? data[posicion].id_proveedor : req.body.id_proveedor;

                data[posicion].ubicacion = (req.body.ubicacion == null || req.body.ubicacion == "") ? data[posicion].ubicacion : req.body.ubicacion;

                data[posicion].costo_unitario = (req.body.costo_unitario == null || req.body.costo_unitario == "") ? data[posicion].costo_unitario : req.body.costo_unitario;

                data[posicion].precio_venta = (req.body.precio_venta == null || req.body.precio_venta == "") ? data[posicion].precio_venta : req.body.precio_venta;

                data[posicion].sucursales = (req.body.sucursales == null || req.body.sucursales == "") ? data[posicion].sucursales : req.body.sucursales;

                data[posicion].color = (req.body.color == null || req.body.color == "") ? data[posicion].color : req.body.color;

                data[posicion].imagen = (req.body.imagen == null || req.body.imagen == "") ? data[posicion].imagen : req.body.imagen;


            }
        }

        let dataJson = JSON.stringify(data);
        fs.writeFile(`./Yeisons/Productos.json`, dataJson, (error) => {
            if (error) {
                console.log('Error al escribir');
            } else {
                console.log('JSON modificado con exito');
            }
        });

    },

    Eliminarx: (req, res) => {
        //Leer el Jason
        const fs = require(`fs`); //File System
        let elJson = fs.readFileSync(`./Yeisons/Productos.json`);
        let data = JSON.parse(elJson);

        let posicion = -1;

        for (let i = 0; i < data.length; i++) {
            const element = data[i];

            if (element.id == req.params.id) {
                posicion = i;

                data.splice(posicion, 1);
            }
        }
        let dataJson = JSON.stringify(data);
        fs.writeFile(`./Yeisons/Productos.json`, dataJson, (error) => {
            if (error) {
                console.log('Error al escribir');
            } else {
                console.log('JSON modificado con exito');
                res.status(204).send("Producto Eliminado!");
            }
        });
    },

    ////////////////////////////////////////////////////////////////////////////////////
    //////////////////////////////////// PROVEEDORES ///////////////////////////////////
    ////////////////////////////////////////////////////////////////////////////////////

    Listay: (req, res) => {
        const fs = require('fs'); //fs es fileSystem
        let elJson = fs.readFileSync('./Yeisons/Proveedores.json');

        // aqui ya tenemos la info del json para manipular
        let data = JSON.parse(elJson);

        console.log(data);
        res.status(200).send(data);

    },

    Obtenery: (req, res) => {
        console.log(req.params.id);

        const fs = require('fs'); //fs es fileSystem
        let elJson = fs.readFileSync('./Yeisons/Proveedores.json');

        // aqui ya tenemos la info del json para manipular
        let data = JSON.parse(elJson);
        let data1 = 0;
        let posicion = -1;

        for (let i = 0; i < data.length; i++) {
            const element = data[i];


            if (element.id == req.params.id) {
                posicion = i;
            }
        }


        if (posicion == -1) {
            res.status(200).send("<h1>EL ID NO EXISTE EN EL JSON</h1>");
        } else {
            res.status(200).send(data[posicion]);
        }
    },

    Creary: (req, res) => {


        console.log(` Creando algo  nuevo `);

        // PASO1 - LEER JSON
        const fs = require('fs'); //fs es fileSystem
        let elJson = fs.readFileSync('./Yeisons/Proveedores.json');
        let data = JSON.parse(elJson);



        // PASO 2 AVERIGUAR EL ID Y ASIGNARLO AL OBJETO
        let elNuevoDato = req.body;

        // averiguo el ultimo id 
        let posicion = 0;

        for (let i = 0; i < data.length; i++) {
            posicion = parseInt(data[i].id.substring(3));
        }

        posicion = posicion + 1

        // se lo asigno
        if ((posicion) < 10) {
            elNuevoDato.id = "PRV00" + posicion;
        } else if ((posicion + 1) < 100) {
            elNuevoDato.id = "PRV0" + posicion;
        } else {
            elNuevoDato.id = "PRV" + posicion;
        }

        // PASO2.1 - AGREGAR AL OBJETO LO QUE TRAE EL BODY 
        data.push(elNuevoDato);


        // PASO3 - GUARDAR EL JSON
        //le caemos encima la JSON que existe
        let dataJson = JSON.stringify(data);
        fs.writeFile('./Yeisons/Proveedores.json', dataJson, (error) => {
            if (error) console.log('hubo error al escribir');
            else console.log('JSON MODIFICADO CON EXITO');

        });

        console.log(req.body);
        res.status(204).send(elNuevoDato);


    },

    Modificary: (req, res) => {
        res.status(204).send("Proveedor modificado!");
        //Leer el Jason
        const fs = require(`fs`); //File System
        let elJson = fs.readFileSync(`./Yeisons/Proveedores.json`);
        let data = JSON.parse(elJson);

        let posicion = -1;

        for (let i = 0; i < data.length; i++) {
            const element = data[i];

            if (element.id == req.params.id) {
                posicion = i;

                data[posicion].nombre = (req.body.nombre == null) ? data[posicion].nombre : req.body.nombre;

                data[posicion].contacto = (req.body.contacto == null) ? data[posicion].contacto : req.body.contacto;

                data[posicion].direccion = (req.body.direccion == null) ? data[posicion].direccion : req.body.direccion;

                data[posicion].terminos_pago = (req.body.terminos_pago == null) ? data[posicion].terminos_pago : req.body.terminos_pago;


            }
        }

        let dataJson = JSON.stringify(data);
        fs.writeFile(`./Yeisons/Proveedores.json`, dataJson, (error) => {
            if (error) {
                console.log('Error al escribir');
            } else {
                console.log('JSON modificado con exito');
            }
        });

    },

    Eliminary: (req, res) => {
        //Leer el Jason
        const fs = require(`fs`); //File System
        let elJson = fs.readFileSync(`./Yeisons/Proveedores.json`);
        let data = JSON.parse(elJson);

        let posicion = -1;

        for (let i = 0; i < data.length; i++) {
            const element = data[i];

            if (element.id == req.params.id) {
                posicion = i;

                data.splice(posicion, 1);
            }
        }
        let dataJson = JSON.stringify(data);
        fs.writeFile(`./Yeisons/Proveedores.json`, dataJson, (error) => {
            if (error) {
                console.log('Error al escribir');
            } else {
                console.log('JSON modificado con exito');
                res.status(204).send("Proveedor Eliminado!");
            }
        });
    },

    RestarProducto: (idProducto, cantidad) => {
        const fs = require('fs');
        const productosJson = fs.readFileSync('./Yeisons/Productos.json');
        let productos = JSON.parse(productosJson);
    
        // Buscar el producto por su ID
        const productoEncontrado = productos.find(producto => producto.id === idProducto);
    
        if (productoEncontrado) {
            // Verificar si hay suficiente cantidad disponible
            if (productoEncontrado.cantidad >= cantidad) {
                // Restar la cantidad del producto del inventario
                productoEncontrado.cantidad -= cantidad;
    
                // Guardar los cambios en el archivo JSON
                fs.writeFileSync('./Yeisons/Productos.json', JSON.stringify(productos));
    
                console.log(`Se restaron ${cantidad} unidades del producto con ID ${idProducto}`);
            } else {
                console.log(`No hay suficiente cantidad disponible para restar ${cantidad} unidades del producto con ID ${idProducto}`);
            }
        } else {
            console.log(`No se encontró ningún producto con el ID ${idProducto}`);
        }
    },

    ////////////////////////////////////////////////////////////////////////////////////
    /////////////////////////////////// TRANSACCIONES //////////////////////////////////
    ////////////////////////////////////////////////////////////////////////////////////

    CrearTransaccion: (nuevaTransaccion) => {
        const fs = require('fs');
        const transaccionesJson = fs.readFileSync('./Yeisons/Transacciones.json');
        let transacciones = JSON.parse(transaccionesJson);

        // Agregar la nueva transacción al array de transacciones
        transacciones.push(nuevaTransaccion);

        // Guardar los cambios en el archivo JSON
        fs.writeFileSync('./Yeisons/Transacciones.json', JSON.stringify(transacciones));

        console.log('Transacción creada exitosamente');
    },

Listat: (req, res) => {
        const fs = require('fs'); //fs es fileSystem
        let elJson = fs.readFileSync('./Yeisons/Transacciones.json');

        // aqui ya tenemos la info del json para manipular
        let data = JSON.parse(elJson);

        console.log(data);
        res.status(200).send(data);

    },

    Obtenert: (req, res) => {
        console.log(req.params.id);

        const fs = require('fs'); //fs es fileSystem
        let elJson = fs.readFileSync('./Yeisons/Transacciones.json');

        // aqui ya tenemos la info del json para manipular
        let data = JSON.parse(elJson);
        let data1 = 0;
        let posicion = -1;

        for (let i = 0; i < data.length; i++) {
            const element = data[i];


            if (element.id == req.params.id) {
                posicion = i;
            }
        }


        if (posicion == -1) {
            res.status(200).send("<h1>EL ID NO EXISTE EN EL JSON</h1>");
        } else {
            res.status(200).send(data[posicion]);
        }
    },

    Creart: (req, res) => {

        console.log(` Creando algo  nuevo `);

        // PASO1 - LEER JSON
        const fs = require('fs'); //fs es fileSystem
        let elJson = fs.readFileSync('./Yeisons/Transacciones.json');
        let data = JSON.parse(elJson);



        // PASO 2 AVERIGUAR EL ID Y ASIGNARLO AL OBJETO
        let elNuevoDato = req.body;

        // averiguo el ultimo id 
        let posicion = 0;

        for (let i = 0; i < data.length; i++) {
            posicion = data[i].id;
        }

        posicion = posicion + 1

        // se lo asigno
        elNuevoDato.id = posicion;


        // PASO2.1 - AGREGAR AL OBJETO LO QUE TRAE EL BODY 
        data.push(elNuevoDato);


        // PASO3 - GUARDAR EL JSON
        //le caemos encima la JSON que existe
        let dataJson = JSON.stringify(data);
        fs.writeFile('./Yeisons/Transacciones.json', dataJson, (error) => {
            if (error) console.log('hubo error al escribir');
            else console.log('JSON MODIFICADO CON EXITO');

        });

        console.log(req.body);
        res.status(204).send(elNuevoDato);


    },

    Modificart: (req, res) => {
        res.status(204).send("Transaccion modificada!");
        //Leer el Jason
        const fs = require(`fs`); //File System
        let elJson = fs.readFileSync(`./Yeisons/Transacciones.json`);
        let data = JSON.parse(elJson);

        let posicion = -1;

        for (let i = 0; i < data.length; i++) {
            const element = data[i];

            if (element.id == req.params.id) {
                posicion = i;

                data[posicion].tipo = (req.body.tipo == null) ? data[posicion].tipo : req.body.tipo;

                data[posicion].id_producto = (req.body.id_producto == null) ? data[posicion].id_producto : req.body.id_producto;

                data[posicion].sucursal = (req.body.sucursal == null) ? data[posicion].sucursal : req.body.sucursal;

                data[posicion].cantidad = (req.body.cantidad == null) ? data[posicion].cantidad : req.body.cantidad;

                data[posicion].motivo = (req.body.motivo == null) ? data[posicion].motivo : req.body.motivo;

                data[posicion].fecha = (req.body.fecha == null) ? data[posicion].fecha : req.body.fecha;



            }
        }

        let dataJson = JSON.stringify(data);
        fs.writeFile(`./Yeisons/Transacciones.json`, dataJson, (error) => {
            if (error) {
                console.log('Error al escribir');
            } else {
                console.log('JSON modificado con exito');
            }
        });

    },

    Eliminart: (req, res) => {
        //Leer el Jason
        const fs = require(`fs`); //File System
        let elJson = fs.readFileSync(`./Yeisons/Transacciones.json`);
        let data = JSON.parse(elJson);

        let posicion = -1;

        for (let i = 0; i < data.length; i++) {
            const element = data[i];

            if (element.id == req.params.id) {
                posicion = i;

                data.splice(posicion, 1);
            }
        }
        let dataJson = JSON.stringify(data);
        fs.writeFile(`./Yeisons/Transacciones.json`, dataJson, (error) => {
            if (error) {
                console.log('Error al escribir');
            } else {
                console.log('JSON modificado con exito');
                res.status(204).send("Transacción Eliminada!");
            }
        });
    },

    ////////////////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////// PEDIDOS /////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////////////////

    Listap: (req, res) => {
        const fs = require('fs'); //fs es fileSystem
        let elJson = fs.readFileSync('./Yeisons/Pedidos.json');

        // aqui ya tenemos la info del json para manipular
        let data = JSON.parse(elJson);

        console.log(data);
        res.status(200).send(data);

    },

    Obtenerp: (req, res) => {
        console.log(req.params.id);

        const fs = require('fs'); //fs es fileSystem
        let elJson = fs.readFileSync('./Yeisons/Pedidos.json');

        // aqui ya tenemos la info del json para manipular
        let data = JSON.parse(elJson);
        let data1 = 0;
        let posicion = -1;

        for (let i = 0; i < data.length; i++) {
            const element = data[i];


            if (element.id == req.params.id) {
                posicion = i;
            }
        }


        if (posicion == -1) {
            res.status(200).send("<h1>EL ID NO EXISTE EN EL JSON</h1>");
        } else {
            res.status(200).send(data[posicion]);
        }
    },

    Crearp: (req, res) => {


        console.log(` Creando algo  nuevo `);

        // PASO1 - LEER JSON
        const fs = require('fs'); //fs es fileSystem
        let elJson = fs.readFileSync('./Yeisons/Pedidos.json');
        let data = JSON.parse(elJson);



        // PASO 2 AVERIGUAR EL ID Y ASIGNARLO AL OBJETO
        let elNuevoDato = req.body;

        // averiguo el ultimo id 
        let posicion = 0;

        for (let i = 0; i < data.length; i++) {
            posicion = parseInt(data[i].id.substring(3));
        }

        posicion = posicion + 1

        // se lo asigno
        if ((posicion) < 10) {
            elNuevoDato.id = "PED00" + posicion;
        } else if ((posicion + 1) < 100) {
            elNuevoDato.id = "PED0" + posicion;
        } else {
            elNuevoDato.id = "PED" + posicion;
        }

        // PASO2.1 - AGREGAR AL OBJETO LO QUE TRAE EL BODY 
        data.push(elNuevoDato);


        // PASO3 - GUARDAR EL JSON
        //le caemos encima la JSON que existe
        let dataJson = JSON.stringify(data);
        fs.writeFile('./Yeisons/Pedidos.json', dataJson, (error) => {
            if (error) console.log('hubo error al escribir');
            else console.log('JSON MODIFICADO CON EXITO');

        });

        console.log(req.body);
        res.status(204).send(elNuevoDato);


    },

    Modificarp: (req, res) => {
        res.status(204).send("Pedido modificado!");
        //Leer el Jason
        const fs = require(`fs`); //File System
        let elJson = fs.readFileSync(`./Yeisons/Pedidos.json`);
        let data = JSON.parse(elJson);

        let posicion = -1;

        for (let i = 0; i < data.length; i++) {
            const element = data[i];

            if (element.id == req.params.id) {
                posicion = i;

                data[posicion].id_producto = (req.body.id_producto == null) ? data[posicion].id_producto : req.body.id_producto;

                data[posicion].id_proveedor = (req.body.id_proveedor == null) ? data[posicion].id_proveedor : req.body.id_proveedor;

                data[posicion].cantidad = (req.body.cantidad == null) ? data[posicion].cantidad : req.body.cantidad;

                data[posicion].fecha_pedido = (req.body.fecha_pedido == null) ? data[posicion].fecha_pedido : req.body.fecha_pedido;

                data[posicion].estado = (req.body.estado == null) ? data[posicion].estado : req.body.estado;


            }
        }

        let dataJson = JSON.stringify(data);
        fs.writeFile(`./Yeisons/Pedidos.json`, dataJson, (error) => {
            if (error) {
                console.log('Error al escribir');
            } else {
                console.log('JSON modificado con exito');
            }
        });

    },

    Eliminarp: (req, res) => {
        //Leer el Jason
        const fs = require(`fs`); //File System
        let elJson = fs.readFileSync(`./Yeisons/Pedidos.json`);
        let data = JSON.parse(elJson);

        let posicion = -1;

        for (let i = 0; i < data.length; i++) {
            const element = data[i];

            if (element.id == req.params.id) {
                posicion = i;

                data.splice(posicion, 1);
            }
        }
        let dataJson = JSON.stringify(data);
        fs.writeFile(`./Yeisons/Pedidos.json`, dataJson, (error) => {
            if (error) {
                console.log('Error al escribir');
            } else {
                console.log('JSON modificado con exito');
                res.status(204).send("Pedido Eliminado!");
            }
        });
    }
};

module.exports = inventario;
