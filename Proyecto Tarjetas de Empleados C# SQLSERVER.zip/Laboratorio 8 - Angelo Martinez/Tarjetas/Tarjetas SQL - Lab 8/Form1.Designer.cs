﻿
namespace Tarjetas_SQL___Lab_8
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btn_EliminarUsuario = new FontAwesome.Sharp.IconButton();
            this.btn_EditarUsuario = new FontAwesome.Sharp.IconButton();
            this.btn_Tarjetas = new FontAwesome.Sharp.IconButton();
            this.btn_AñadirUsuario = new FontAwesome.Sharp.IconButton();
            this.panel5 = new System.Windows.Forms.Panel();
            this.btn_Salir = new FontAwesome.Sharp.IconButton();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.panel2 = new System.Windows.Forms.Panel();
            this.txt_AñadirDepto = new System.Windows.Forms.TextBox();
            this.txt_AñadirTel1 = new System.Windows.Forms.TextBox();
            this.txt_AñadirTel2 = new System.Windows.Forms.TextBox();
            this.txt_AñadirPuesto = new System.Windows.Forms.TextBox();
            this.txt_AñadirEmpresa = new System.Windows.Forms.TextBox();
            this.txt_AñadirApellido = new System.Windows.Forms.TextBox();
            this.txt_AñadirNombre = new System.Windows.Forms.TextBox();
            this.txt_AñadirID = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.btn_Regresar1 = new FontAwesome.Sharp.IconButton();
            this.panel9 = new System.Windows.Forms.Panel();
            this.btn_Agregar = new FontAwesome.Sharp.IconButton();
            this.label12 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel11 = new System.Windows.Forms.Panel();
            this.btn_Modificar = new FontAwesome.Sharp.IconButton();
            this.label22 = new System.Windows.Forms.Label();
            this.txt_EditarDepartamento = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.txt_EditarTel2 = new System.Windows.Forms.TextBox();
            this.txt_EditarPuesto = new System.Windows.Forms.TextBox();
            this.txt_EditarEmpresa = new System.Windows.Forms.TextBox();
            this.txt_EditarApellido = new System.Windows.Forms.TextBox();
            this.txt_EditarNombre = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.cb_ids2 = new System.Windows.Forms.ComboBox();
            this.label15 = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.btn_Regresar2 = new FontAwesome.Sharp.IconButton();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.panel4 = new System.Windows.Forms.Panel();
            this.btn_Eliminar = new FontAwesome.Sharp.IconButton();
            this.label23 = new System.Windows.Forms.Label();
            this.txt_EliminarApellido = new System.Windows.Forms.TextBox();
            this.txt_EliminarNombre = new System.Windows.Forms.TextBox();
            this.cb_ids3 = new System.Windows.Forms.ComboBox();
            this.panel8 = new System.Windows.Forms.Panel();
            this.btn_Regresar3 = new FontAwesome.Sharp.IconButton();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.cb_ids = new System.Windows.Forms.ComboBox();
            this.panel10 = new System.Windows.Forms.Panel();
            this.btn_Regresar4 = new FontAwesome.Sharp.IconButton();
            this.lbl_nombres = new System.Windows.Forms.Label();
            this.lbl_puesto = new System.Windows.Forms.Label();
            this.lbl_telefono = new System.Windows.Forms.Label();
            this.lbl_depto = new System.Windows.Forms.Label();
            this.lbl_empresa = new System.Windows.Forms.Label();
            this.lbl_apellidos = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel5.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel9.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel11.SuspendLayout();
            this.panel7.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel8.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.panel10.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1112, 652);
            this.tabControl1.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.panel1);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1104, 623);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Menu";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.SteelBlue;
            this.panel1.Controls.Add(this.btn_EliminarUsuario);
            this.panel1.Controls.Add(this.btn_EditarUsuario);
            this.panel1.Controls.Add(this.btn_Tarjetas);
            this.panel1.Controls.Add(this.btn_AñadirUsuario);
            this.panel1.Controls.Add(this.panel5);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label13);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(3, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1098, 617);
            this.panel1.TabIndex = 0;
            // 
            // btn_EliminarUsuario
            // 
            this.btn_EliminarUsuario.FlatAppearance.BorderSize = 0;
            this.btn_EliminarUsuario.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_EliminarUsuario.IconChar = FontAwesome.Sharp.IconChar.UserMinus;
            this.btn_EliminarUsuario.IconColor = System.Drawing.Color.White;
            this.btn_EliminarUsuario.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btn_EliminarUsuario.IconSize = 100;
            this.btn_EliminarUsuario.Location = new System.Drawing.Point(290, 460);
            this.btn_EliminarUsuario.Name = "btn_EliminarUsuario";
            this.btn_EliminarUsuario.Size = new System.Drawing.Size(141, 83);
            this.btn_EliminarUsuario.TabIndex = 3;
            this.btn_EliminarUsuario.UseVisualStyleBackColor = true;
            this.btn_EliminarUsuario.Click += new System.EventHandler(this.Botones);
            // 
            // btn_EditarUsuario
            // 
            this.btn_EditarUsuario.FlatAppearance.BorderSize = 0;
            this.btn_EditarUsuario.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_EditarUsuario.IconChar = FontAwesome.Sharp.IconChar.UserEdit;
            this.btn_EditarUsuario.IconColor = System.Drawing.Color.White;
            this.btn_EditarUsuario.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btn_EditarUsuario.IconSize = 100;
            this.btn_EditarUsuario.Location = new System.Drawing.Point(290, 359);
            this.btn_EditarUsuario.Name = "btn_EditarUsuario";
            this.btn_EditarUsuario.Size = new System.Drawing.Size(141, 83);
            this.btn_EditarUsuario.TabIndex = 3;
            this.btn_EditarUsuario.UseVisualStyleBackColor = true;
            this.btn_EditarUsuario.Click += new System.EventHandler(this.Botones);
            // 
            // btn_Tarjetas
            // 
            this.btn_Tarjetas.FlatAppearance.BorderSize = 0;
            this.btn_Tarjetas.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Tarjetas.IconChar = FontAwesome.Sharp.IconChar.ClipboardUser;
            this.btn_Tarjetas.IconColor = System.Drawing.Color.White;
            this.btn_Tarjetas.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btn_Tarjetas.IconSize = 80;
            this.btn_Tarjetas.Location = new System.Drawing.Point(290, 150);
            this.btn_Tarjetas.Name = "btn_Tarjetas";
            this.btn_Tarjetas.Size = new System.Drawing.Size(141, 83);
            this.btn_Tarjetas.TabIndex = 3;
            this.btn_Tarjetas.UseVisualStyleBackColor = true;
            this.btn_Tarjetas.Click += new System.EventHandler(this.Botones);
            // 
            // btn_AñadirUsuario
            // 
            this.btn_AñadirUsuario.FlatAppearance.BorderSize = 0;
            this.btn_AñadirUsuario.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_AñadirUsuario.IconChar = FontAwesome.Sharp.IconChar.UserPlus;
            this.btn_AñadirUsuario.IconColor = System.Drawing.Color.White;
            this.btn_AñadirUsuario.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btn_AñadirUsuario.IconSize = 100;
            this.btn_AñadirUsuario.Location = new System.Drawing.Point(290, 251);
            this.btn_AñadirUsuario.Name = "btn_AñadirUsuario";
            this.btn_AñadirUsuario.Size = new System.Drawing.Size(141, 83);
            this.btn_AñadirUsuario.TabIndex = 3;
            this.btn_AñadirUsuario.UseVisualStyleBackColor = true;
            this.btn_AñadirUsuario.Click += new System.EventHandler(this.Botones);
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.btn_Salir);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel5.Location = new System.Drawing.Point(0, 557);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(1098, 60);
            this.panel5.TabIndex = 2;
            // 
            // btn_Salir
            // 
            this.btn_Salir.FlatAppearance.BorderSize = 0;
            this.btn_Salir.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Salir.IconChar = FontAwesome.Sharp.IconChar.Xmark;
            this.btn_Salir.IconColor = System.Drawing.Color.White;
            this.btn_Salir.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btn_Salir.IconSize = 70;
            this.btn_Salir.Location = new System.Drawing.Point(5, 5);
            this.btn_Salir.Name = "btn_Salir";
            this.btn_Salir.Size = new System.Drawing.Size(60, 60);
            this.btn_Salir.TabIndex = 3;
            this.btn_Salir.UseVisualStyleBackColor = true;
            this.btn_Salir.Click += new System.EventHandler(this.Botones);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(455, 474);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(470, 69);
            this.label4.TabIndex = 0;
            this.label4.Text = "Eliminar Usuario";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(455, 359);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(409, 69);
            this.label3.TabIndex = 0;
            this.label3.Text = "Editar Usuario";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.White;
            this.label13.Location = new System.Drawing.Point(455, 150);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(247, 69);
            this.label13.TabIndex = 0;
            this.label13.Text = "Tarjetas";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(455, 251);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(425, 69);
            this.label2.TabIndex = 0;
            this.label2.Text = "Añadir Usuario";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 64.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(384, -3);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(330, 124);
            this.label1.TabIndex = 0;
            this.label1.Text = "Menu";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.panel2);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1104, 623);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Agregar Usuario";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.SteelBlue;
            this.panel2.Controls.Add(this.txt_AñadirDepto);
            this.panel2.Controls.Add(this.txt_AñadirTel1);
            this.panel2.Controls.Add(this.txt_AñadirTel2);
            this.panel2.Controls.Add(this.txt_AñadirPuesto);
            this.panel2.Controls.Add(this.txt_AñadirEmpresa);
            this.panel2.Controls.Add(this.txt_AñadirApellido);
            this.panel2.Controls.Add(this.txt_AñadirNombre);
            this.panel2.Controls.Add(this.txt_AñadirID);
            this.panel2.Controls.Add(this.label11);
            this.panel2.Controls.Add(this.label10);
            this.panel2.Controls.Add(this.label9);
            this.panel2.Controls.Add(this.label8);
            this.panel2.Controls.Add(this.label7);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.panel6);
            this.panel2.Controls.Add(this.panel9);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(3, 3);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1098, 617);
            this.panel2.TabIndex = 0;
            // 
            // txt_AñadirDepto
            // 
            this.txt_AñadirDepto.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_AñadirDepto.Location = new System.Drawing.Point(298, 325);
            this.txt_AñadirDepto.Name = "txt_AñadirDepto";
            this.txt_AñadirDepto.Size = new System.Drawing.Size(562, 30);
            this.txt_AñadirDepto.TabIndex = 7;
            // 
            // txt_AñadirTel1
            // 
            this.txt_AñadirTel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_AñadirTel1.Location = new System.Drawing.Point(207, 455);
            this.txt_AñadirTel1.Name = "txt_AñadirTel1";
            this.txt_AñadirTel1.ReadOnly = true;
            this.txt_AñadirTel1.Size = new System.Drawing.Size(121, 30);
            this.txt_AñadirTel1.TabIndex = 7;
            this.txt_AñadirTel1.Text = "+502";
            // 
            // txt_AñadirTel2
            // 
            this.txt_AñadirTel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_AñadirTel2.Location = new System.Drawing.Point(352, 455);
            this.txt_AñadirTel2.Name = "txt_AñadirTel2";
            this.txt_AñadirTel2.Size = new System.Drawing.Size(508, 30);
            this.txt_AñadirTel2.TabIndex = 7;
            // 
            // txt_AñadirPuesto
            // 
            this.txt_AñadirPuesto.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_AñadirPuesto.Location = new System.Drawing.Point(207, 391);
            this.txt_AñadirPuesto.Name = "txt_AñadirPuesto";
            this.txt_AñadirPuesto.Size = new System.Drawing.Size(653, 30);
            this.txt_AñadirPuesto.TabIndex = 7;
            // 
            // txt_AñadirEmpresa
            // 
            this.txt_AñadirEmpresa.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_AñadirEmpresa.Location = new System.Drawing.Point(207, 262);
            this.txt_AñadirEmpresa.Name = "txt_AñadirEmpresa";
            this.txt_AñadirEmpresa.Size = new System.Drawing.Size(653, 30);
            this.txt_AñadirEmpresa.TabIndex = 7;
            // 
            // txt_AñadirApellido
            // 
            this.txt_AñadirApellido.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_AñadirApellido.Location = new System.Drawing.Point(207, 193);
            this.txt_AñadirApellido.Name = "txt_AñadirApellido";
            this.txt_AñadirApellido.Size = new System.Drawing.Size(653, 30);
            this.txt_AñadirApellido.TabIndex = 7;
            // 
            // txt_AñadirNombre
            // 
            this.txt_AñadirNombre.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_AñadirNombre.Location = new System.Drawing.Point(207, 130);
            this.txt_AñadirNombre.Name = "txt_AñadirNombre";
            this.txt_AñadirNombre.Size = new System.Drawing.Size(653, 30);
            this.txt_AñadirNombre.TabIndex = 7;
            // 
            // txt_AñadirID
            // 
            this.txt_AñadirID.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_AñadirID.Location = new System.Drawing.Point(207, 66);
            this.txt_AñadirID.Name = "txt_AñadirID";
            this.txt_AñadirID.Size = new System.Drawing.Size(653, 30);
            this.txt_AñadirID.TabIndex = 7;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 22F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.White;
            this.label11.Location = new System.Drawing.Point(31, 443);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(156, 42);
            this.label11.TabIndex = 4;
            this.label11.Text = "Celular: ";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 22F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(31, 379);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(155, 42);
            this.label10.TabIndex = 4;
            this.label10.Text = "Puesto: ";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 22F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(30, 314);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(274, 42);
            this.label9.TabIndex = 4;
            this.label9.Text = "Departamento: ";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 22F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(31, 250);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(177, 42);
            this.label8.TabIndex = 4;
            this.label8.Text = "Empresa:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 22F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(30, 181);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(171, 42);
            this.label7.TabIndex = 4;
            this.label7.Text = "Apellido: ";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 22F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(31, 118);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(170, 42);
            this.label6.TabIndex = 4;
            this.label6.Text = "Nombre: ";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 22F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(31, 54);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(74, 42);
            this.label5.TabIndex = 4;
            this.label5.Text = "ID: ";
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.btn_Regresar1);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel6.Location = new System.Drawing.Point(0, 549);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(883, 68);
            this.panel6.TabIndex = 3;
            // 
            // btn_Regresar1
            // 
            this.btn_Regresar1.FlatAppearance.BorderSize = 0;
            this.btn_Regresar1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Regresar1.IconChar = FontAwesome.Sharp.IconChar.Xmark;
            this.btn_Regresar1.IconColor = System.Drawing.Color.White;
            this.btn_Regresar1.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btn_Regresar1.IconSize = 70;
            this.btn_Regresar1.Location = new System.Drawing.Point(5, 5);
            this.btn_Regresar1.Name = "btn_Regresar1";
            this.btn_Regresar1.Size = new System.Drawing.Size(60, 60);
            this.btn_Regresar1.TabIndex = 3;
            this.btn_Regresar1.UseVisualStyleBackColor = true;
            this.btn_Regresar1.Click += new System.EventHandler(this.Botones);
            // 
            // panel9
            // 
            this.panel9.Controls.Add(this.btn_Agregar);
            this.panel9.Controls.Add(this.label12);
            this.panel9.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel9.Location = new System.Drawing.Point(883, 0);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(215, 617);
            this.panel9.TabIndex = 6;
            // 
            // btn_Agregar
            // 
            this.btn_Agregar.FlatAppearance.BorderSize = 0;
            this.btn_Agregar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Agregar.IconChar = FontAwesome.Sharp.IconChar.UserPlus;
            this.btn_Agregar.IconColor = System.Drawing.Color.White;
            this.btn_Agregar.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btn_Agregar.IconSize = 100;
            this.btn_Agregar.Location = new System.Drawing.Point(77, 239);
            this.btn_Agregar.Name = "btn_Agregar";
            this.btn_Agregar.Size = new System.Drawing.Size(87, 83);
            this.btn_Agregar.TabIndex = 5;
            this.btn_Agregar.UseVisualStyleBackColor = true;
            this.btn_Agregar.Click += new System.EventHandler(this.AgregarUsuario);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 22F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.White;
            this.label12.Location = new System.Drawing.Point(38, 325);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(151, 42);
            this.label12.TabIndex = 4;
            this.label12.Text = "Agregar";
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.panel3);
            this.tabPage3.Location = new System.Drawing.Point(4, 25);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(1104, 623);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Editar Usuario";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.SteelBlue;
            this.panel3.Controls.Add(this.panel11);
            this.panel3.Controls.Add(this.txt_EditarDepartamento);
            this.panel3.Controls.Add(this.textBox2);
            this.panel3.Controls.Add(this.txt_EditarTel2);
            this.panel3.Controls.Add(this.txt_EditarPuesto);
            this.panel3.Controls.Add(this.txt_EditarEmpresa);
            this.panel3.Controls.Add(this.txt_EditarApellido);
            this.panel3.Controls.Add(this.txt_EditarNombre);
            this.panel3.Controls.Add(this.label16);
            this.panel3.Controls.Add(this.label17);
            this.panel3.Controls.Add(this.label18);
            this.panel3.Controls.Add(this.label19);
            this.panel3.Controls.Add(this.label20);
            this.panel3.Controls.Add(this.label21);
            this.panel3.Controls.Add(this.cb_ids2);
            this.panel3.Controls.Add(this.label15);
            this.panel3.Controls.Add(this.panel7);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1104, 623);
            this.panel3.TabIndex = 0;
            // 
            // panel11
            // 
            this.panel11.Controls.Add(this.btn_Modificar);
            this.panel11.Controls.Add(this.label22);
            this.panel11.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel11.Location = new System.Drawing.Point(904, 0);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(200, 555);
            this.panel11.TabIndex = 23;
            // 
            // btn_Modificar
            // 
            this.btn_Modificar.FlatAppearance.BorderSize = 0;
            this.btn_Modificar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Modificar.IconChar = FontAwesome.Sharp.IconChar.UserEdit;
            this.btn_Modificar.IconColor = System.Drawing.Color.White;
            this.btn_Modificar.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btn_Modificar.IconSize = 100;
            this.btn_Modificar.Location = new System.Drawing.Point(40, 208);
            this.btn_Modificar.Name = "btn_Modificar";
            this.btn_Modificar.Size = new System.Drawing.Size(141, 83);
            this.btn_Modificar.TabIndex = 5;
            this.btn_Modificar.UseVisualStyleBackColor = true;
            this.btn_Modificar.Click += new System.EventHandler(this.Editar);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.ForeColor = System.Drawing.Color.White;
            this.label22.Location = new System.Drawing.Point(24, 294);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(176, 44);
            this.label22.TabIndex = 4;
            this.label22.Text = "Modificar";
            // 
            // txt_EditarDepartamento
            // 
            this.txt_EditarDepartamento.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_EditarDepartamento.Location = new System.Drawing.Point(275, 323);
            this.txt_EditarDepartamento.Name = "txt_EditarDepartamento";
            this.txt_EditarDepartamento.Size = new System.Drawing.Size(562, 30);
            this.txt_EditarDepartamento.TabIndex = 16;
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox2.Location = new System.Drawing.Point(184, 453);
            this.textBox2.Name = "textBox2";
            this.textBox2.ReadOnly = true;
            this.textBox2.Size = new System.Drawing.Size(121, 30);
            this.textBox2.TabIndex = 17;
            this.textBox2.Text = "+502";
            // 
            // txt_EditarTel2
            // 
            this.txt_EditarTel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_EditarTel2.Location = new System.Drawing.Point(329, 453);
            this.txt_EditarTel2.Name = "txt_EditarTel2";
            this.txt_EditarTel2.Size = new System.Drawing.Size(508, 30);
            this.txt_EditarTel2.TabIndex = 18;
            // 
            // txt_EditarPuesto
            // 
            this.txt_EditarPuesto.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_EditarPuesto.Location = new System.Drawing.Point(184, 389);
            this.txt_EditarPuesto.Name = "txt_EditarPuesto";
            this.txt_EditarPuesto.Size = new System.Drawing.Size(653, 30);
            this.txt_EditarPuesto.TabIndex = 19;
            // 
            // txt_EditarEmpresa
            // 
            this.txt_EditarEmpresa.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_EditarEmpresa.Location = new System.Drawing.Point(184, 260);
            this.txt_EditarEmpresa.Name = "txt_EditarEmpresa";
            this.txt_EditarEmpresa.Size = new System.Drawing.Size(653, 30);
            this.txt_EditarEmpresa.TabIndex = 20;
            // 
            // txt_EditarApellido
            // 
            this.txt_EditarApellido.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_EditarApellido.Location = new System.Drawing.Point(184, 191);
            this.txt_EditarApellido.Name = "txt_EditarApellido";
            this.txt_EditarApellido.Size = new System.Drawing.Size(653, 30);
            this.txt_EditarApellido.TabIndex = 21;
            // 
            // txt_EditarNombre
            // 
            this.txt_EditarNombre.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_EditarNombre.Location = new System.Drawing.Point(184, 128);
            this.txt_EditarNombre.Name = "txt_EditarNombre";
            this.txt_EditarNombre.Size = new System.Drawing.Size(653, 30);
            this.txt_EditarNombre.TabIndex = 22;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 22F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.White;
            this.label16.Location = new System.Drawing.Point(8, 441);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(156, 42);
            this.label16.TabIndex = 10;
            this.label16.Text = "Celular: ";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 22F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.White;
            this.label17.Location = new System.Drawing.Point(8, 377);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(155, 42);
            this.label17.TabIndex = 11;
            this.label17.Text = "Puesto: ";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 22F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.Color.White;
            this.label18.Location = new System.Drawing.Point(7, 312);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(274, 42);
            this.label18.TabIndex = 12;
            this.label18.Text = "Departamento: ";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 22F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.Color.White;
            this.label19.Location = new System.Drawing.Point(8, 248);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(177, 42);
            this.label19.TabIndex = 13;
            this.label19.Text = "Empresa:";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 22F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.Color.White;
            this.label20.Location = new System.Drawing.Point(7, 179);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(171, 42);
            this.label20.TabIndex = 14;
            this.label20.Text = "Apellido: ";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 22F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.ForeColor = System.Drawing.Color.White;
            this.label21.Location = new System.Drawing.Point(8, 116);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(170, 42);
            this.label21.TabIndex = 15;
            this.label21.Text = "Nombre: ";
            // 
            // cb_ids2
            // 
            this.cb_ids2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cb_ids2.FormattingEnabled = true;
            this.cb_ids2.Location = new System.Drawing.Point(184, 56);
            this.cb_ids2.Name = "cb_ids2";
            this.cb_ids2.Size = new System.Drawing.Size(653, 37);
            this.cb_ids2.TabIndex = 9;
            this.cb_ids2.SelectedIndexChanged += new System.EventHandler(this.MostrarInfo);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 22F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.White;
            this.label15.Location = new System.Drawing.Point(8, 51);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(74, 42);
            this.label15.TabIndex = 8;
            this.label15.Text = "ID: ";
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.btn_Regresar2);
            this.panel7.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel7.Location = new System.Drawing.Point(0, 555);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(1104, 68);
            this.panel7.TabIndex = 3;
            // 
            // btn_Regresar2
            // 
            this.btn_Regresar2.FlatAppearance.BorderSize = 0;
            this.btn_Regresar2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Regresar2.IconChar = FontAwesome.Sharp.IconChar.Xmark;
            this.btn_Regresar2.IconColor = System.Drawing.Color.White;
            this.btn_Regresar2.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btn_Regresar2.IconSize = 70;
            this.btn_Regresar2.Location = new System.Drawing.Point(5, 5);
            this.btn_Regresar2.Name = "btn_Regresar2";
            this.btn_Regresar2.Size = new System.Drawing.Size(60, 60);
            this.btn_Regresar2.TabIndex = 3;
            this.btn_Regresar2.UseVisualStyleBackColor = true;
            this.btn_Regresar2.Click += new System.EventHandler(this.Botones);
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.panel4);
            this.tabPage4.Location = new System.Drawing.Point(4, 25);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(1104, 623);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Eliminar Usuario";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.SteelBlue;
            this.panel4.Controls.Add(this.btn_Eliminar);
            this.panel4.Controls.Add(this.label23);
            this.panel4.Controls.Add(this.txt_EliminarApellido);
            this.panel4.Controls.Add(this.txt_EliminarNombre);
            this.panel4.Controls.Add(this.cb_ids3);
            this.panel4.Controls.Add(this.panel8);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel4.Location = new System.Drawing.Point(0, 0);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(1104, 623);
            this.panel4.TabIndex = 0;
            // 
            // btn_Eliminar
            // 
            this.btn_Eliminar.FlatAppearance.BorderSize = 0;
            this.btn_Eliminar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Eliminar.IconChar = FontAwesome.Sharp.IconChar.UserMinus;
            this.btn_Eliminar.IconColor = System.Drawing.Color.White;
            this.btn_Eliminar.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btn_Eliminar.IconSize = 100;
            this.btn_Eliminar.Location = new System.Drawing.Point(484, 282);
            this.btn_Eliminar.Name = "btn_Eliminar";
            this.btn_Eliminar.Size = new System.Drawing.Size(141, 83);
            this.btn_Eliminar.TabIndex = 13;
            this.btn_Eliminar.UseVisualStyleBackColor = true;
            this.btn_Eliminar.Click += new System.EventHandler(this.Eliminar);
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.ForeColor = System.Drawing.Color.White;
            this.label23.Location = new System.Drawing.Point(327, 383);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(470, 69);
            this.label23.TabIndex = 12;
            this.label23.Text = "Eliminar Usuario";
            // 
            // txt_EliminarApellido
            // 
            this.txt_EliminarApellido.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_EliminarApellido.Location = new System.Drawing.Point(570, 145);
            this.txt_EliminarApellido.Name = "txt_EliminarApellido";
            this.txt_EliminarApellido.ReadOnly = true;
            this.txt_EliminarApellido.Size = new System.Drawing.Size(312, 53);
            this.txt_EliminarApellido.TabIndex = 11;
            // 
            // txt_EliminarNombre
            // 
            this.txt_EliminarNombre.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_EliminarNombre.Location = new System.Drawing.Point(229, 145);
            this.txt_EliminarNombre.Name = "txt_EliminarNombre";
            this.txt_EliminarNombre.ReadOnly = true;
            this.txt_EliminarNombre.Size = new System.Drawing.Size(312, 53);
            this.txt_EliminarNombre.TabIndex = 11;
            // 
            // cb_ids3
            // 
            this.cb_ids3.Font = new System.Drawing.Font("Microsoft Sans Serif", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cb_ids3.FormattingEnabled = true;
            this.cb_ids3.Location = new System.Drawing.Point(229, 34);
            this.cb_ids3.Name = "cb_ids3";
            this.cb_ids3.Size = new System.Drawing.Size(653, 59);
            this.cb_ids3.TabIndex = 10;
            this.cb_ids3.SelectedIndexChanged += new System.EventHandler(this.MostrarInfo2);
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.btn_Regresar3);
            this.panel8.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel8.Location = new System.Drawing.Point(0, 555);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(1104, 68);
            this.panel8.TabIndex = 3;
            // 
            // btn_Regresar3
            // 
            this.btn_Regresar3.FlatAppearance.BorderSize = 0;
            this.btn_Regresar3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Regresar3.IconChar = FontAwesome.Sharp.IconChar.Xmark;
            this.btn_Regresar3.IconColor = System.Drawing.Color.White;
            this.btn_Regresar3.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btn_Regresar3.IconSize = 70;
            this.btn_Regresar3.Location = new System.Drawing.Point(5, 5);
            this.btn_Regresar3.Name = "btn_Regresar3";
            this.btn_Regresar3.Size = new System.Drawing.Size(60, 60);
            this.btn_Regresar3.TabIndex = 3;
            this.btn_Regresar3.UseVisualStyleBackColor = true;
            this.btn_Regresar3.Click += new System.EventHandler(this.Botones);
            // 
            // tabPage5
            // 
            this.tabPage5.BackColor = System.Drawing.Color.SteelBlue;
            this.tabPage5.Controls.Add(this.cb_ids);
            this.tabPage5.Controls.Add(this.panel10);
            this.tabPage5.Controls.Add(this.lbl_nombres);
            this.tabPage5.Controls.Add(this.lbl_puesto);
            this.tabPage5.Controls.Add(this.lbl_telefono);
            this.tabPage5.Controls.Add(this.lbl_depto);
            this.tabPage5.Controls.Add(this.lbl_empresa);
            this.tabPage5.Controls.Add(this.lbl_apellidos);
            this.tabPage5.Controls.Add(this.label14);
            this.tabPage5.Location = new System.Drawing.Point(4, 25);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Size = new System.Drawing.Size(1104, 623);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "Tarjetas";
            // 
            // cb_ids
            // 
            this.cb_ids.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cb_ids.FormattingEnabled = true;
            this.cb_ids.Location = new System.Drawing.Point(218, 21);
            this.cb_ids.Name = "cb_ids";
            this.cb_ids.Size = new System.Drawing.Size(718, 37);
            this.cb_ids.TabIndex = 7;
            this.cb_ids.SelectedIndexChanged += new System.EventHandler(this.Buscar);
            // 
            // panel10
            // 
            this.panel10.Controls.Add(this.btn_Regresar4);
            this.panel10.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel10.Location = new System.Drawing.Point(0, 563);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(1104, 60);
            this.panel10.TabIndex = 6;
            // 
            // btn_Regresar4
            // 
            this.btn_Regresar4.FlatAppearance.BorderSize = 0;
            this.btn_Regresar4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Regresar4.IconChar = FontAwesome.Sharp.IconChar.Xmark;
            this.btn_Regresar4.IconColor = System.Drawing.Color.White;
            this.btn_Regresar4.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btn_Regresar4.IconSize = 70;
            this.btn_Regresar4.Location = new System.Drawing.Point(5, 5);
            this.btn_Regresar4.Name = "btn_Regresar4";
            this.btn_Regresar4.Size = new System.Drawing.Size(60, 60);
            this.btn_Regresar4.TabIndex = 3;
            this.btn_Regresar4.UseVisualStyleBackColor = true;
            this.btn_Regresar4.Click += new System.EventHandler(this.Botones);
            // 
            // lbl_nombres
            // 
            this.lbl_nombres.AutoSize = true;
            this.lbl_nombres.Font = new System.Drawing.Font("Microsoft Sans Serif", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_nombres.ForeColor = System.Drawing.Color.White;
            this.lbl_nombres.Location = new System.Drawing.Point(31, 144);
            this.lbl_nombres.Name = "lbl_nombres";
            this.lbl_nombres.Size = new System.Drawing.Size(175, 44);
            this.lbl_nombres.TabIndex = 5;
            this.lbl_nombres.Text = "Nombres";
            // 
            // lbl_puesto
            // 
            this.lbl_puesto.AutoSize = true;
            this.lbl_puesto.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_puesto.ForeColor = System.Drawing.Color.White;
            this.lbl_puesto.Location = new System.Drawing.Point(359, 248);
            this.lbl_puesto.Name = "lbl_puesto";
            this.lbl_puesto.Size = new System.Drawing.Size(326, 91);
            this.lbl_puesto.TabIndex = 5;
            this.lbl_puesto.Text = "Puestos";
            // 
            // lbl_telefono
            // 
            this.lbl_telefono.AutoSize = true;
            this.lbl_telefono.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_telefono.ForeColor = System.Drawing.Color.White;
            this.lbl_telefono.Location = new System.Drawing.Point(741, 530);
            this.lbl_telefono.Name = "lbl_telefono";
            this.lbl_telefono.Size = new System.Drawing.Size(100, 29);
            this.lbl_telefono.TabIndex = 5;
            this.lbl_telefono.Text = "Numero";
            // 
            // lbl_depto
            // 
            this.lbl_depto.AutoSize = true;
            this.lbl_depto.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_depto.ForeColor = System.Drawing.Color.White;
            this.lbl_depto.Location = new System.Drawing.Point(739, 484);
            this.lbl_depto.Name = "lbl_depto";
            this.lbl_depto.Size = new System.Drawing.Size(127, 46);
            this.lbl_depto.TabIndex = 5;
            this.lbl_depto.Text = "Depto";
            // 
            // lbl_empresa
            // 
            this.lbl_empresa.AutoSize = true;
            this.lbl_empresa.Font = new System.Drawing.Font("Microsoft Sans Serif", 28.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_empresa.ForeColor = System.Drawing.Color.White;
            this.lbl_empresa.Location = new System.Drawing.Point(739, 429);
            this.lbl_empresa.Name = "lbl_empresa";
            this.lbl_empresa.Size = new System.Drawing.Size(217, 55);
            this.lbl_empresa.TabIndex = 5;
            this.lbl_empresa.Text = "Empresa";
            // 
            // lbl_apellidos
            // 
            this.lbl_apellidos.AutoSize = true;
            this.lbl_apellidos.Font = new System.Drawing.Font("Microsoft Sans Serif", 28.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_apellidos.ForeColor = System.Drawing.Color.White;
            this.lbl_apellidos.Location = new System.Drawing.Point(31, 89);
            this.lbl_apellidos.Name = "lbl_apellidos";
            this.lbl_apellidos.Size = new System.Drawing.Size(218, 55);
            this.lbl_apellidos.TabIndex = 5;
            this.lbl_apellidos.Text = "Apellidos";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 22F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.White;
            this.label14.Location = new System.Drawing.Point(150, 16);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(74, 42);
            this.label14.TabIndex = 5;
            this.label14.Text = "ID: ";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1112, 652);
            this.ControlBox = false;
            this.Controls.Add(this.tabControl1);
            this.Name = "Form1";
            this.Text = "Tarjetas SQL";
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel11.ResumeLayout(false);
            this.panel11.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.tabPage4.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            this.panel10.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.Panel panel4;
        private FontAwesome.Sharp.IconButton btn_EliminarUsuario;
        private FontAwesome.Sharp.IconButton btn_EditarUsuario;
        private FontAwesome.Sharp.IconButton btn_AñadirUsuario;
        private FontAwesome.Sharp.IconButton btn_Salir;
        private System.Windows.Forms.Panel panel6;
        private FontAwesome.Sharp.IconButton btn_Regresar1;
        private System.Windows.Forms.Panel panel7;
        private FontAwesome.Sharp.IconButton btn_Regresar2;
        private System.Windows.Forms.Panel panel8;
        private FontAwesome.Sharp.IconButton btn_Regresar3;
        private System.Windows.Forms.TextBox txt_AñadirDepto;
        private System.Windows.Forms.TextBox txt_AñadirTel1;
        private System.Windows.Forms.TextBox txt_AñadirTel2;
        private System.Windows.Forms.TextBox txt_AñadirPuesto;
        private System.Windows.Forms.TextBox txt_AñadirEmpresa;
        private System.Windows.Forms.TextBox txt_AñadirApellido;
        private System.Windows.Forms.TextBox txt_AñadirNombre;
        private System.Windows.Forms.TextBox txt_AñadirID;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panel9;
        private FontAwesome.Sharp.IconButton btn_Agregar;
        private System.Windows.Forms.Label label12;
        private FontAwesome.Sharp.IconButton btn_Tarjetas;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.Panel panel10;
        private FontAwesome.Sharp.IconButton btn_Regresar4;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.ComboBox cb_ids;
        private System.Windows.Forms.Label lbl_nombres;
        private System.Windows.Forms.Label lbl_puesto;
        private System.Windows.Forms.Label lbl_telefono;
        private System.Windows.Forms.Label lbl_depto;
        private System.Windows.Forms.Label lbl_empresa;
        private System.Windows.Forms.Label lbl_apellidos;
        private System.Windows.Forms.Panel panel11;
        private FontAwesome.Sharp.IconButton btn_Modificar;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox txt_EditarDepartamento;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox txt_EditarTel2;
        private System.Windows.Forms.TextBox txt_EditarPuesto;
        private System.Windows.Forms.TextBox txt_EditarEmpresa;
        private System.Windows.Forms.TextBox txt_EditarApellido;
        private System.Windows.Forms.TextBox txt_EditarNombre;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.ComboBox cb_ids2;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.ComboBox cb_ids3;
        private FontAwesome.Sharp.IconButton btn_Eliminar;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox txt_EliminarApellido;
        private System.Windows.Forms.TextBox txt_EliminarNombre;
    }
}

