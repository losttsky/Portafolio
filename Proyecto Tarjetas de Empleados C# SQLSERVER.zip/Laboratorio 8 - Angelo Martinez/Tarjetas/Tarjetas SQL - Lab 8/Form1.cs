﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tarjetas_SQL___Lab_8
{
    public partial class Form1 : Form
    {

        DataClasses1DataContext dataContext = new DataClasses1DataContext();

        public Form1()
        {
            InitializeComponent();
            tabControl1.ItemSize = new Size(0, 1);
            ItemsComboBox();
        }

        public void ItemsComboBox()
        {
            cb_ids.Items.Clear();
            cb_ids2.Items.Clear();
            cb_ids3.Items.Clear();

            var tabla = from datos in dataContext.GetTable<tarjetaPresentacion>()
                        select datos.id;

            foreach (var ids in tabla)
            {
                cb_ids.Items.Add(ids.ToString());
                cb_ids2.Items.Add(ids.ToString());
                cb_ids3.Items.Add(ids.ToString());
            }
        }

        private void Botones(object sender, EventArgs e)
        {
            Button aux = (Button)sender;

            switch (aux.Name)
            {
                case "btn_Tarjetas":
                    tabControl1.SelectTab(4);
                    break;
                case "btn_AñadirUsuario":
                    tabControl1.SelectTab(1);
                    break;
                case "btn_EditarUsuario":
                    tabControl1.SelectTab(2);
                    break;
                case "btn_EliminarUsuario":
                    tabControl1.SelectTab(3);
                    break;
                case "btn_Regresar1":
                    tabControl1.SelectTab(0);
                    break;
                case "btn_Regresar2":
                    tabControl1.SelectTab(0);
                    break;
                case "btn_Regresar3":
                    tabControl1.SelectTab(0);
                    break;                
                case "btn_Regresar4":
                    tabControl1.SelectTab(0);
                    break;
                case "btn_Salir":
                    this.Close();
                    Application.Exit();
                    break;
            }
        }

        private void AgregarUsuario(object sender, EventArgs e)
        {
            try
            {
                tarjetaPresentacion nuevaTarjeta = new tarjetaPresentacion();
                
                try
                {
                    nuevaTarjeta.id = Convert.ToInt32(txt_AñadirID.Text);
                }
                catch
                {
                    MessageBox.Show("Error al agregar usuario", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txt_AñadirID.Text = "";
                }
                nuevaTarjeta.nombre = txt_AñadirNombre.Text;
                nuevaTarjeta.apellido = txt_AñadirApellido.Text;
                nuevaTarjeta.empresa = txt_AñadirEmpresa.Text;
                nuevaTarjeta.departamento = txt_AñadirDepto.Text;
                nuevaTarjeta.puesto = txt_AñadirPuesto.Text;
                try
                {
                    nuevaTarjeta.celular = Convert.ToInt32(txt_AñadirTel2.Text);
                }
                catch
                {
                    MessageBox.Show("Error al agregar usuario", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txt_AñadirTel2.Text = "";
                }

                dataContext.tarjetaPresentacion.InsertOnSubmit(nuevaTarjeta);

                dataContext.SubmitChanges();
                MessageBox.Show("Usuario Agregado", "Agregado con exito", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                txt_AñadirID.Text = "";
                txt_AñadirNombre.Text = "";
                txt_AñadirApellido.Text = "";
                txt_AñadirEmpresa.Text = "";
                txt_AñadirDepto.Text = "";
                txt_AñadirPuesto.Text = "";
                txt_AñadirTel2.Text = "";
                ItemsComboBox();
            }
            catch
            {
                MessageBox.Show("Error al agregar usuario", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txt_AñadirID.Text = "";
                txt_AñadirTel2.Text = "";
            }
        }

        private void Buscar(object sender, EventArgs e)
        {
            try
            {
                tarjetaPresentacion tarjeta = dataContext.tarjetaPresentacion.Single(x => x.id == Convert.ToInt32(cb_ids.Text));

                lbl_apellidos.Text = tarjeta.apellido;
                lbl_nombres.Text = tarjeta.nombre;
                lbl_puesto.Text = tarjeta.puesto;
                lbl_empresa.Text = tarjeta.empresa;
                lbl_depto.Text = tarjeta.departamento;
                lbl_telefono.Text = tarjeta.celular.ToString();

            }
            catch { }
        }

        private void Editar(object sender, EventArgs e)
        {
            try
            {
                tarjetaPresentacion userModif = dataContext.tarjetaPresentacion.Single(x => x.id == Convert.ToInt32(cb_ids2.Text));

                userModif.nombre = txt_EditarNombre.Text;
                userModif.apellido = txt_EditarApellido.Text;
                userModif.puesto = txt_EditarPuesto.Text;
                userModif.departamento = txt_EditarDepartamento.Text;
                userModif.empresa = txt_EditarEmpresa.Text;
                userModif.celular = Convert.ToInt32(txt_EditarTel2.Text);

                dataContext.SubmitChanges();
                MessageBox.Show("Usuario " + userModif.nombre + " Modificado", "Modificado con exito", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                txt_EditarNombre.Text = "";
                txt_EditarApellido.Text = "";
                txt_EditarPuesto.Text = "";
                txt_EditarDepartamento.Text = "";
                txt_EditarEmpresa.Text = "";
                txt_EditarTel2.Text = "";
            }
            catch 
            {
                MessageBox.Show("Error al modificar usuario", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void MostrarInfo(object sender, EventArgs e)
        {
            try
            {
                tarjetaPresentacion user = dataContext.tarjetaPresentacion.Single(x => x.id == Convert.ToInt32(cb_ids2.Text));

                txt_EditarNombre.Text = user.nombre;
                txt_EditarApellido.Text = user.apellido;
                txt_EditarPuesto.Text = user.puesto;
                txt_EditarDepartamento.Text = user.departamento;
                txt_EditarEmpresa.Text = user.empresa;
                txt_EditarTel2.Text = user.celular.ToString();
            }
            catch { }
        }

        private void Eliminar(object sender, EventArgs e)
        {

            try
            {
                tarjetaPresentacion userDelete = dataContext.tarjetaPresentacion.Single(x => x.id == Convert.ToInt32(cb_ids3.Text));

                dataContext.tarjetaPresentacion.DeleteOnSubmit(userDelete);
                dataContext.SubmitChanges();
                MessageBox.Show("Usuario " + userDelete.nombre + " Eliminado", "Eliminado con exito", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                txt_EliminarNombre.Text = "";
                txt_EliminarApellido.Text = "";
            }
            catch { }

        }

        private void MostrarInfo2(object sender, EventArgs e)
        {
            try
            {
                tarjetaPresentacion user = dataContext.tarjetaPresentacion.Single(x => x.id == Convert.ToInt32(cb_ids3.Text));

                txt_EliminarNombre.Text = user.nombre;
                txt_EliminarApellido.Text = user.apellido;
            }
            catch { }
        }
    }
}
