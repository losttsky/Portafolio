CREATE DATABASE tarjetas;

USE tarjetas;

CREATE TABLE tarjetaPresentacion(
	id INT PRIMARY KEY,
	nombre VARCHAR(30),
	apellido VARCHAR(30),
	empresa VARCHAR(50), 
	departamento VARCHAR(50),
	puesto VARCHAR(30),
	celular BIGINT,
);

SELECT * FROM tarjetaPresentacion;