﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculadora_de_Resistencias
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        Regex reg = new Regex(@"\A[0-9]+\Z");
        Regex regnotacion = new Regex(@"\A\d+(\.[0-9]((K|k)|(M|m)))?((K|k)|(M|m))?\Z");
        Regex regdecimal = new Regex(@"\A0\.[0-9][0-9]?[1-9]?\Z");
        Regex regenterodecimal = new Regex(@"\A\d{1}\.[0-9]\Z");
        
        private void btn_salir_Click(object sender, EventArgs e)
        {
            Close();
            Form1 principal = new Form1();
            principal.Show();
        }

        private void btn_calcular_Click(object sender, EventArgs e)
        {

            
            //Asigno los colores
            if(txt_valor.Text.Length > 4)
            {
                MessageBox.Show("Maximo de caracteres", "Caracteres fuera de rango", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                AsignarColoresBanda(txt_valor.Text);
            }
            

            //Valido la resistencia
            if (comboBox1.Text == "1%")
            {
                banda4.BackColor = Color.Brown;
            }
            else if (comboBox1.Text == "2%")
            {
                banda4.BackColor = Color.Red;
            }
            else if (comboBox1.Text == "5%")
            {
                banda4.BackColor = Color.Gold;
            }
            else if (comboBox1.Text == "10%")
            {
                banda4.BackColor = Color.DarkGray;
            }
            else if (comboBox1.Text == "20%")
            {
                banda4.BackColor = Color.Pink;
            }
            else
            {
                MessageBox.Show("Ingrese el valor de la resistencia", "Resistencia", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }

        }

        private void AsignarColoresBanda(string valor)
        {

            if (reg.IsMatch(valor))
            {
                if (valor.Length > 1)
                {

                    colores(valor);

                }
                //Si solo tiene un digito lo ingresado 
                else if (valor.Length == 1)
                {
                    if (valor.Substring(0, 1) == "0")
                    {
                        banda1.BackColor = Color.Black;
                        banda2.BackColor = Color.Black;
                        banda3.BackColor = Color.Black;
                    }
                    else if (valor.Substring(0, 1) == "1")
                    {
                        banda1.BackColor = Color.Black;
                        banda2.BackColor = Color.Brown;
                        banda3.BackColor = Color.Black;
                    }
                    else if (valor.Substring(0, 1) == "2")
                    {
                        banda1.BackColor = Color.Black;
                        banda2.BackColor = Color.Red;
                        banda3.BackColor = Color.Black;
                    }
                    else if (valor.Substring(0, 1) == "3")
                    {
                        banda1.BackColor = Color.Black;
                        banda2.BackColor = Color.Orange;
                        banda3.BackColor = Color.Black;
                    }
                    else if (valor.Substring(0, 1) == "4")
                    {
                        banda1.BackColor = Color.Black;
                        banda2.BackColor = Color.Yellow;
                        banda3.BackColor = Color.Black;
                    }
                    else if (valor.Substring(0, 1) == "5")
                    {
                        banda1.BackColor = Color.Black;
                        banda2.BackColor = Color.Green;
                        banda3.BackColor = Color.Black;
                    }
                    else if (valor.Substring(0, 1) == "6")
                    {
                        banda1.BackColor = Color.Black;
                        banda2.BackColor = Color.Blue;
                        banda3.BackColor = Color.Black;
                    }
                    else if (valor.Substring(0, 1) == "7")
                    {
                        banda1.BackColor = Color.Black;
                        banda2.BackColor = Color.Purple;
                        banda3.BackColor = Color.Black;
                    }
                    else if (valor.Substring(0, 1) == "8")
                    {
                        banda1.BackColor = Color.Black;
                        banda2.BackColor = Color.Gray;
                        banda3.BackColor = Color.Black;
                    }
                    else if (valor.Substring(0, 1) == "9")
                    {
                        banda1.BackColor = Color.Black;
                        banda2.BackColor = Color.White;
                        banda3.BackColor = Color.Black;
                    }
                }
            }
            else if (regnotacion.IsMatch(valor))
            {
                if (valor.Contains("K"))
                {
                    if (valor.Contains("."))
                    {
                        valor = valor.Replace(".", "");
                        valor = valor.Replace("K", "00");
                        colores(valor);
                    }else
                    {
                        valor = valor.Replace("K", "000");
                        colores(valor);
                    }
                }
                else if (valor.Contains("k"))
                {
                    if (valor.Contains("."))
                    {
                        valor = valor.Replace(".", "");
                        valor = valor.Replace("k", "00");
                        colores(valor);
                    }
                    else
                    {
                        valor = valor.Replace("k", "000");
                        colores(valor);
                    }
                }
                else if (valor.Contains("M"))
                {
                    if (valor.Contains("."))
                    {
                        valor = valor.Replace(".", "");
                        valor = valor.Replace("M", "00000");
                        colores(valor);
                    }
                    else
                    {
                        valor = valor.Replace("M", "000000");
                        colores(valor);
                    }
                }
                else if (valor.Contains("m"))
                {
                    if (valor.Contains("."))
                    {
                        valor = valor.Replace(".", "");
                        valor = valor.Replace("m", "00000");
                        colores(valor);
                    }
                    else
                    {
                        valor = valor.Replace("m", "000000");
                        colores(valor);
                    }
                }
            }
            else if (regdecimal.IsMatch(valor))
            {

                if (valor.Length == 3)
                {
                    banda1.BackColor = Color.Black;
                    banda3.BackColor = Color.Gold;

                    if (valor.Substring(2, 1) == "0")
                    {
                        banda2.BackColor = Color.Black;
                    }
                    else if (valor.Substring(2, 1) == "1")
                    {
                        banda2.BackColor = Color.Brown;
                    }
                    else if (valor.Substring(2, 1) == "2")
                    {
                        banda2.BackColor = Color.Red;
                    }
                    else if (valor.Substring(2, 1) == "3")
                    {
                        banda2.BackColor = Color.Orange;
                    }
                    else if (valor.Substring(2, 1) == "4")
                    {
                        banda2.BackColor = Color.Yellow;
                    }
                    else if (valor.Substring(2, 1) == "5")
                    {
                        banda2.BackColor = Color.Green;
                    }
                    else if (valor.Substring(2, 1) == "6")
                    {
                        banda2.BackColor = Color.Blue;
                    }
                    else if (valor.Substring(2, 1) == "7")
                    {
                        banda2.BackColor = Color.Purple;
                    }
                    else if (valor.Substring(2, 1) == "8")
                    {
                        banda2.BackColor = Color.Gray;
                    }
                    else if (valor.Substring(2, 1) == "9")
                    {
                        banda2.BackColor = Color.White;
                    }
                }
                else if (valor.Length == 4)
                {
                    banda3.BackColor = Color.DarkGray;

                    //Color banda 1
                    if (valor.Substring(2, 1) == "0")
                    {
                        banda1.BackColor = Color.Black;
                    }
                    else if (valor.Substring(2, 1) == "1")
                    {
                        banda1.BackColor = Color.Brown;
                    }
                    else if (valor.Substring(2, 1) == "2")
                    {
                        banda1.BackColor = Color.Red;
                    }
                    else if (valor.Substring(2, 1) == "3")
                    {
                        banda1.BackColor = Color.Orange;
                    }
                    else if (valor.Substring(2, 1) == "4")
                    {
                        banda1.BackColor = Color.Yellow;
                    }
                    else if (valor.Substring(2, 1) == "5")
                    {
                        banda1.BackColor = Color.Green;
                    }
                    else if (valor.Substring(2, 1) == "6")
                    {
                        banda1.BackColor = Color.Blue;
                    }
                    else if (valor.Substring(2, 1) == "7")
                    {
                        banda1.BackColor = Color.Purple;
                    }
                    else if (valor.Substring(2, 1) == "8")
                    {
                        banda1.BackColor = Color.Gray;
                    }
                    else if (valor.Substring(2, 1) == "9")
                    {
                        banda1.BackColor = Color.White;
                    }

                    //Color banda 2
                    if (valor.Substring(3, 1) == "0")
                    {
                        banda2.BackColor = Color.Black;
                    }
                    else if (valor.Substring(3, 1) == "1")
                    {
                        banda2.BackColor = Color.Brown;
                    }
                    else if (valor.Substring(3, 1) == "2")
                    {
                        banda2.BackColor = Color.Red;
                    }
                    else if (valor.Substring(3, 1) == "3")
                    {
                        banda2.BackColor = Color.Orange;
                    }
                    else if (valor.Substring(3, 1) == "4")
                    {
                        banda2.BackColor = Color.Yellow;
                    }
                    else if (valor.Substring(3, 1) == "5")
                    {
                        banda2.BackColor = Color.Green;
                    }
                    else if (valor.Substring(3, 1) == "6")
                    {
                        banda2.BackColor = Color.Blue;
                    }
                    else if (valor.Substring(3, 1) == "7")
                    {
                        banda2.BackColor = Color.Purple;
                    }
                    else if (valor.Substring(3, 1) == "8")
                    {
                        banda2.BackColor = Color.Gray;
                    }
                    else if (valor.Substring(3, 1) == "9")
                    {
                        banda2.BackColor = Color.White;
                    }
                }
                else
                {
                    MessageBox.Show("Tu numero esta fuera del rango ;(", "Error de rango", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            else if (regenterodecimal.IsMatch(valor))
            {
                banda3.BackColor = Color.Gold;

                //Color banda 1
                if (valor.Substring(0, 1) == "0")
                {
                    banda1.BackColor = Color.Black;
                }
                else if (valor.Substring(0, 1) == "1")
                {
                    banda1.BackColor = Color.Brown;
                }
                else if (valor.Substring(0, 1) == "2")
                {
                    banda1.BackColor = Color.Red;
                }
                else if (valor.Substring(0, 1) == "3")
                {
                    banda1.BackColor = Color.Orange;
                }
                else if (valor.Substring(0, 1) == "4")
                {
                    banda1.BackColor = Color.Yellow;
                }
                else if (valor.Substring(0, 1) == "5")
                {
                    banda1.BackColor = Color.Green;
                }
                else if (valor.Substring(0, 1) == "6")
                {
                    banda1.BackColor = Color.Blue;
                }
                else if (valor.Substring(0, 1) == "7")
                {
                    banda1.BackColor = Color.Purple;
                }
                else if (valor.Substring(0, 1) == "8")
                {
                    banda1.BackColor = Color.Gray;
                }
                else if (valor.Substring(0, 1) == "9")
                {
                    banda1.BackColor = Color.White;
                }

                //Color banda 2
                if (valor.Substring(2, 1) == "0")
                {
                    banda2.BackColor = Color.Black;
                }
                else if (valor.Substring(2, 1) == "1")
                {
                    banda2.BackColor = Color.Brown;
                }
                else if (valor.Substring(2, 1) == "2")
                {
                    banda2.BackColor = Color.Red;
                }
                else if (valor.Substring(2, 1) == "3")
                {
                    banda2.BackColor = Color.Orange;
                }
                else if (valor.Substring(2, 1) == "4")
                {
                    banda2.BackColor = Color.Yellow;
                }
                else if (valor.Substring(2, 1) == "5")
                {
                    banda2.BackColor = Color.Green;
                }
                else if (valor.Substring(2, 1) == "6")
                {
                    banda2.BackColor = Color.Blue;
                }
                else if (valor.Substring(2, 1) == "7")
                {
                    banda2.BackColor = Color.Purple;
                }
                else if (valor.Substring(2, 1) == "8")
                {
                    banda2.BackColor = Color.Gray;
                }
                else if (valor.Substring(2, 1) == "9")
                {
                    banda2.BackColor = Color.White;
                }


            }
        }

        private void colores(string valor)
        {
            //Color 1
            if (valor.Substring(0, 1) == "0")
            {
                banda1.BackColor = Color.Black;
            }
            else if (valor.Substring(0, 1) == "1")
            {
                banda1.BackColor = Color.Brown;
            }
            else if (valor.Substring(0, 1) == "2")
            {
                banda1.BackColor = Color.Red;
            }
            else if (valor.Substring(0, 1) == "3")
            {
                banda1.BackColor = Color.Orange;
            }
            else if (valor.Substring(0, 1) == "4")
            {
                banda1.BackColor = Color.Yellow;
            }
            else if (valor.Substring(0, 1) == "5")
            {
                banda1.BackColor = Color.Green;
            }
            else if (valor.Substring(0, 1) == "6")
            {
                banda1.BackColor = Color.Blue;
            }
            else if (valor.Substring(0, 1) == "7")
            {
                banda1.BackColor = Color.Purple;
            }
            else if (valor.Substring(0, 1) == "8")
            {
                banda1.BackColor = Color.Gray;
            }
            else if (valor.Substring(0, 1) == "9")
            {
                banda1.BackColor = Color.White;
            }


            //Color 2
            if (valor.Substring(1, 1) == "0")
            {
                banda2.BackColor = Color.Black;
            }
            else if (valor.Substring(1, 1) == "1")
            {
                banda2.BackColor = Color.Brown;
            }
            else if (valor.Substring(1, 1) == "2")
            {
                banda2.BackColor = Color.Red;
            }
            else if (valor.Substring(1, 1) == "3")
            {
                banda2.BackColor = Color.Orange;
            }
            else if (valor.Substring(1, 1) == "4")
            {
                banda2.BackColor = Color.Yellow;
            }
            else if (valor.Substring(1, 1) == "5")
            {
                banda2.BackColor = Color.Green;
            }
            else if (valor.Substring(1, 1) == "6")
            {
                banda2.BackColor = Color.Blue;
            }
            else if (valor.Substring(1, 1) == "7")
            {
                banda2.BackColor = Color.Purple;
            }
            else if (valor.Substring(1, 1) == "8")
            {
                banda2.BackColor = Color.Gray;
            }
            else if (valor.Substring(1, 1) == "9")
            {
                banda2.BackColor = Color.White;
            }

            //Color3
            if (Convert.ToInt32(valor.Substring(0, 2)) * 1 == Convert.ToInt32(valor)){
                banda3.BackColor = Color.Black;
            }
            else if (Convert.ToInt32(valor.Substring(0, 2)) * 10 == Convert.ToInt32(valor))
            {
                banda3.BackColor = Color.Brown;
            }
            else if (Convert.ToInt32(valor.Substring(0, 2)) * 100 == Convert.ToInt32(valor))
            {
                banda3.BackColor = Color.Red;
            }
            else if (Convert.ToInt32(valor.Substring(0, 2)) * 1000 == Convert.ToInt32(valor))
            {
                banda3.BackColor = Color.Orange;
            }
            else if (Convert.ToInt32(valor.Substring(0, 2)) * 10000 == Convert.ToInt32(valor))
            {
                banda3.BackColor = Color.Yellow;
            }
            else if (Convert.ToInt32(valor.Substring(0, 2)) * 100000 == Convert.ToInt32(valor))
            {
                banda3.BackColor = Color.Green;
            }
            else if (Convert.ToInt32(valor.Substring(0, 2)) * 1000000 == Convert.ToInt32(valor))
            {
                banda3.BackColor = Color.Blue;
            }
            else if (Convert.ToDouble(valor.Substring(0, 2)) * 0.1 == Convert.ToDouble(valor))
            {
                banda3.BackColor = Color.Gold;
            }
            else if (Convert.ToDouble(valor.Substring(0, 2)) * 0.01 == Convert.ToDouble(valor))
            {
                banda3.BackColor = Color.DarkGray;
            }
            else
            {
                MessageBox.Show("Tu numero es demasiado grande ;(", "Error de rango", MessageBoxButtons.OK, MessageBoxIcon.Warning);

            }
        }
    }
}