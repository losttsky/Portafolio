﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TreeView;

namespace Calculadora_de_Resistencias
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void btn_salir_Click(object sender, EventArgs e)
        {
            Close();
            Form1 principal = new Form1();
            principal.Show();
        }

        private void cb_banda1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(cb_banda1.Text == "Negro")
            {
                banda1.BackColor = Color.Black;
            }
            else if(cb_banda1.Text == "Marron")
            {
                banda1.BackColor = Color.Brown;
            }
            else if(cb_banda1.Text == "Rojo")
            {
                banda1.BackColor = Color.Red;
            }
            else if(cb_banda1.Text == "Naranja")
            {
                banda1.BackColor = Color.Orange;
            }
            else if(cb_banda1.Text == "Amarillo")
            {
                banda1.BackColor = Color.Yellow;
            }
            else if(cb_banda1.Text == "Verde")
            {
                banda1.BackColor = Color.Green;
            }
            else if(cb_banda1.Text == "Azul")
            {
                banda1.BackColor = Color.Blue;
            }
            else if(cb_banda1.Text == "Violeta")
            {
                banda1.BackColor = Color.Violet;
            }
            else if(cb_banda1.Text == "Gris")
            {
                banda1.BackColor = Color.Gray;
            }
            else if(cb_banda1.Text == "Blanco")
            {
                banda1.BackColor = Color.White;
            }
            else
            {
                banda1.BackColor = Color.Pink;
            }
        }

        private void cb_banda2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cb_banda2.Text == "Negro")
            {
                banda2.BackColor = Color.Black;
            }
            else if (cb_banda2.Text == "Marron")
            {
                banda2.BackColor = Color.Brown;
            }
            else if (cb_banda2.Text == "Rojo")
            {
                banda2.BackColor = Color.Red;
            }
            else if (cb_banda2.Text == "Naranja")
            {
                banda2.BackColor = Color.Orange;
            }
            else if (cb_banda2.Text == "Amarillo")
            {
                banda2.BackColor = Color.Yellow;
            }
            else if (cb_banda2.Text == "Verde")
            {
                banda2.BackColor = Color.Green;
            }
            else if (cb_banda2.Text == "Azul")
            {
                banda2.BackColor = Color.Blue;
            }
            else if (cb_banda2.Text == "Violeta")
            {
                banda2.BackColor = Color.Violet;
            }
            else if (cb_banda2.Text == "Gris")
            {
                banda2.BackColor = Color.Gray;
            }
            else if (cb_banda2.Text == "Blanco")
            {
                banda2.BackColor = Color.White;
            }
            else
            {
                banda2.BackColor = Color.Pink;
            }
        }

        private void cb_banda3_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(cb_banda3.Text == "Negro")
            {
                banda3.BackColor = Color.Black;
            }
            else if(cb_banda3.Text == "Marron")
            {
                banda3.BackColor = Color.Brown;
            }
            else if(cb_banda3.Text == "Rojo")
            {
                banda3.BackColor = Color.Red;
            }
            else if(cb_banda3.Text == "Naranja")
            {
                banda3.BackColor = Color.Orange;
            }
            else if(cb_banda3.Text == "Amarillo")
            {
                banda3.BackColor = Color.Yellow;
            }
            else if(cb_banda3.Text == "Verde")
            {
                banda3.BackColor = Color.Green;
            }
            else if(cb_banda3.Text == "Azul")
            {
                banda3.BackColor = Color.Blue;
            }
            else if (cb_banda3.Text == "Dorado")
            {
                banda3.BackColor = Color.Gold;
            }
            else if(cb_banda3.Text == "Plateado")
            {
                banda3.BackColor = Color.DimGray;
            }
            else
            {
                banda3.BackColor = Color.Pink;
            }
        }

        private void cb_banda4_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(cb_banda4.Text == "Marron")
            {
                banda4.BackColor = Color.Brown;
            }
            else if(cb_banda4.Text == "Rojo")
            {
                banda4.BackColor = Color.Red;
            }
            else if(cb_banda4.Text == "Dorado")
            {
                banda4.BackColor = Color.Gold;
            }
            else if(cb_banda4.Text == "Plateado")
            {
                banda4.BackColor = Color.DimGray;
            }
            else if(cb_banda4.Text == "Sin Banda")
            {
                banda4.BackColor = Color.Pink;
            }
            else
            {
                MessageBox.Show("Ingresa color en banda 4");
            }
        }

        private void btn_calcular_Click(object sender, EventArgs e)
        {
            String result, b1, b2, resistencia = "";


            //Valor de la banda 1
            if (cb_banda1.Text == "Negro")
            {
                b1 = "0";
            }
            else if (cb_banda1.Text == "Marron")
            {
                b1 = "1";
            }
            else if (cb_banda1.Text == "Rojo")
            {
                b1 = "2";
            }
            else if (cb_banda1.Text == "Naranja")
            {
                b1   = "3";
            }
            else if (cb_banda1.Text == "Amarillo")
            {
                b1 = "4";
            }
            else if (cb_banda1.Text == "Verde")
            {
                b1 = "5";
            }
            else if (cb_banda1.Text == "Azul")
            {
                b1 = "6";
            }
            else if (cb_banda1.Text == "Violeta")
            {
                b1 = "7";
            }
            else if (cb_banda1.Text == "Gris")
            {
                b1 = "8";
            }
            else if (cb_banda1.Text == "Blanco")
            {
                b1 = "9";
            }
            else
            {
                b1 = "Error";
            }

            //Valor de la banda 2
            if (cb_banda2.Text == "Negro")
            {
                b2 = "0";
            }
            else if (cb_banda2.Text == "Marron")
            {
                b2 = "1";
            }
            else if (cb_banda2.Text == "Rojo")
            {
                b2 = "2";
            }
            else if (cb_banda2.Text == "Naranja")
            {
                b2 = "3";
            }
            else if (cb_banda2.Text == "Amarillo")
            {
                b2 = "4";
            }
            else if (cb_banda2.Text == "Verde")
            {
                b2 = "5";
            }
            else if (cb_banda2.Text == "Azul")
            {
                b2 = "6";
            }
            else if (cb_banda2.Text == "Violeta")
            {
                b2 = "7";
            }
            else if (cb_banda2.Text == "Gris")
            {
                b2 = "8";
            }
            else if (cb_banda2.Text == "Blanco")
            {
                b2 = "9";
            }
            else
            {
                b2 = "Error";
            }
            
            if(cb_banda3.Text == "Negro")
            {
                resistencia = b1 + b2;
            }
            else if(cb_banda3.Text == "Marron")
            {
                resistencia = b1 + b2 + "0";
            }
            else if(cb_banda3.Text == "Rojo")
            {
                result = b1 + "." + b2 + "K";
                resistencia = result;
            }
            else if(cb_banda3.Text == "Naranja")
            {
                resistencia = b1 + b2 + "K";
            }
            else if(cb_banda3.Text == "Amarillo")
            {
                resistencia = b1 + b2 + "0" + "K";
            }
            else if(cb_banda3.Text == "Verde")
            {
                result = b1 + "." + b2 + "M";
                resistencia = result;
            }
            else if(cb_banda3.Text == "Azul")
            {
                resistencia = b1 + b2 + "M";
            }
            else if(cb_banda3.Text == "Dorado")
            {
                resistencia = b1 + "." + b2;
            }
            else if (cb_banda3.Text == "Plateado")
            {
                resistencia = "0." + b1 + b2;
            }


            if (cb_banda4.Text == "Marron")
            {
                txt_result.Text = resistencia.ToString() + "Ω   1%";
            }
            else if (cb_banda4.Text == "Rojo")
            {
                txt_result.Text = resistencia.ToString() + "Ω   2%";
            }
            else if (cb_banda4.Text == "Plateado")
            {
                txt_result.Text = resistencia.ToString() + "Ω   10%";
            }
            else if (cb_banda4.Text == "Dorado")
            {
                txt_result.Text = resistencia.ToString() + "Ω   5%";
            }
            else if (cb_banda4.Text == "Sin Banda")
            {
                txt_result.Text = resistencia.ToString() + "Ω   20%";
            }
            else
            {
                txt_result.Text = "Ingrese un valor en la cuarta banda";
            }
        }
    }
}
