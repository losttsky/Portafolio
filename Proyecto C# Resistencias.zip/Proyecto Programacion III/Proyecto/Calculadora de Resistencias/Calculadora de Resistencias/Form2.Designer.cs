﻿namespace Calculadora_de_Resistencias
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            this.btn_salir = new System.Windows.Forms.Button();
            this.lbl_titulo = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.cb_banda3 = new System.Windows.Forms.ComboBox();
            this.lbl_banda3 = new System.Windows.Forms.Label();
            this.lbl_banda4 = new System.Windows.Forms.Label();
            this.cb_banda4 = new System.Windows.Forms.ComboBox();
            this.cb_banda1 = new System.Windows.Forms.ComboBox();
            this.lbl_banda1 = new System.Windows.Forms.Label();
            this.lbl_banda2 = new System.Windows.Forms.Label();
            this.cb_banda2 = new System.Windows.Forms.ComboBox();
            this.txt_result = new System.Windows.Forms.TextBox();
            this.banda2 = new System.Windows.Forms.TextBox();
            this.banda1 = new System.Windows.Forms.TextBox();
            this.banda3 = new System.Windows.Forms.TextBox();
            this.banda4 = new System.Windows.Forms.TextBox();
            this.btn_calcular = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // btn_salir
            // 
            this.btn_salir.BackColor = System.Drawing.Color.Red;
            this.btn_salir.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            resources.ApplyResources(this.btn_salir, "btn_salir");
            this.btn_salir.Name = "btn_salir";
            this.btn_salir.UseVisualStyleBackColor = false;
            this.btn_salir.Click += new System.EventHandler(this.btn_salir_Click);
            // 
            // lbl_titulo
            // 
            resources.ApplyResources(this.lbl_titulo, "lbl_titulo");
            this.lbl_titulo.Name = "lbl_titulo";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Calculadora_de_Resistencias.Properties.Resources.resistencia;
            resources.ApplyResources(this.pictureBox1, "pictureBox1");
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.TabStop = false;
            // 
            // cb_banda3
            // 
            this.cb_banda3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_banda3.FormattingEnabled = true;
            this.cb_banda3.Items.AddRange(new object[] {
            resources.GetString("cb_banda3.Items"),
            resources.GetString("cb_banda3.Items1"),
            resources.GetString("cb_banda3.Items2"),
            resources.GetString("cb_banda3.Items3"),
            resources.GetString("cb_banda3.Items4"),
            resources.GetString("cb_banda3.Items5"),
            resources.GetString("cb_banda3.Items6"),
            resources.GetString("cb_banda3.Items7"),
            resources.GetString("cb_banda3.Items8")});
            resources.ApplyResources(this.cb_banda3, "cb_banda3");
            this.cb_banda3.Name = "cb_banda3";
            this.cb_banda3.SelectedIndexChanged += new System.EventHandler(this.cb_banda3_SelectedIndexChanged);
            // 
            // lbl_banda3
            // 
            resources.ApplyResources(this.lbl_banda3, "lbl_banda3");
            this.lbl_banda3.Name = "lbl_banda3";
            // 
            // lbl_banda4
            // 
            resources.ApplyResources(this.lbl_banda4, "lbl_banda4");
            this.lbl_banda4.Name = "lbl_banda4";
            // 
            // cb_banda4
            // 
            this.cb_banda4.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_banda4.FormattingEnabled = true;
            this.cb_banda4.Items.AddRange(new object[] {
            resources.GetString("cb_banda4.Items"),
            resources.GetString("cb_banda4.Items1"),
            resources.GetString("cb_banda4.Items2"),
            resources.GetString("cb_banda4.Items3"),
            resources.GetString("cb_banda4.Items4")});
            resources.ApplyResources(this.cb_banda4, "cb_banda4");
            this.cb_banda4.Name = "cb_banda4";
            this.cb_banda4.SelectedIndexChanged += new System.EventHandler(this.cb_banda4_SelectedIndexChanged);
            // 
            // cb_banda1
            // 
            this.cb_banda1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_banda1.FormattingEnabled = true;
            this.cb_banda1.Items.AddRange(new object[] {
            resources.GetString("cb_banda1.Items"),
            resources.GetString("cb_banda1.Items1"),
            resources.GetString("cb_banda1.Items2"),
            resources.GetString("cb_banda1.Items3"),
            resources.GetString("cb_banda1.Items4"),
            resources.GetString("cb_banda1.Items5"),
            resources.GetString("cb_banda1.Items6"),
            resources.GetString("cb_banda1.Items7"),
            resources.GetString("cb_banda1.Items8"),
            resources.GetString("cb_banda1.Items9")});
            resources.ApplyResources(this.cb_banda1, "cb_banda1");
            this.cb_banda1.Name = "cb_banda1";
            this.cb_banda1.SelectedIndexChanged += new System.EventHandler(this.cb_banda1_SelectedIndexChanged);
            // 
            // lbl_banda1
            // 
            resources.ApplyResources(this.lbl_banda1, "lbl_banda1");
            this.lbl_banda1.Name = "lbl_banda1";
            // 
            // lbl_banda2
            // 
            resources.ApplyResources(this.lbl_banda2, "lbl_banda2");
            this.lbl_banda2.Name = "lbl_banda2";
            // 
            // cb_banda2
            // 
            this.cb_banda2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_banda2.FormattingEnabled = true;
            this.cb_banda2.Items.AddRange(new object[] {
            resources.GetString("cb_banda2.Items"),
            resources.GetString("cb_banda2.Items1"),
            resources.GetString("cb_banda2.Items2"),
            resources.GetString("cb_banda2.Items3"),
            resources.GetString("cb_banda2.Items4"),
            resources.GetString("cb_banda2.Items5"),
            resources.GetString("cb_banda2.Items6"),
            resources.GetString("cb_banda2.Items7"),
            resources.GetString("cb_banda2.Items8"),
            resources.GetString("cb_banda2.Items9")});
            resources.ApplyResources(this.cb_banda2, "cb_banda2");
            this.cb_banda2.Name = "cb_banda2";
            this.cb_banda2.SelectedIndexChanged += new System.EventHandler(this.cb_banda2_SelectedIndexChanged);
            // 
            // txt_result
            // 
            resources.ApplyResources(this.txt_result, "txt_result");
            this.txt_result.Name = "txt_result";
            this.txt_result.ReadOnly = true;
            // 
            // banda2
            // 
            resources.ApplyResources(this.banda2, "banda2");
            this.banda2.Name = "banda2";
            this.banda2.ReadOnly = true;
            // 
            // banda1
            // 
            resources.ApplyResources(this.banda1, "banda1");
            this.banda1.Name = "banda1";
            this.banda1.ReadOnly = true;
            // 
            // banda3
            // 
            resources.ApplyResources(this.banda3, "banda3");
            this.banda3.Name = "banda3";
            this.banda3.ReadOnly = true;
            // 
            // banda4
            // 
            resources.ApplyResources(this.banda4, "banda4");
            this.banda4.Name = "banda4";
            this.banda4.ReadOnly = true;
            // 
            // btn_calcular
            // 
            this.btn_calcular.BackColor = System.Drawing.Color.Chartreuse;
            resources.ApplyResources(this.btn_calcular, "btn_calcular");
            this.btn_calcular.Name = "btn_calcular";
            this.btn_calcular.UseVisualStyleBackColor = false;
            this.btn_calcular.Click += new System.EventHandler(this.btn_calcular_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.banda1);
            resources.ApplyResources(this.panel1, "panel1");
            this.panel1.Name = "panel1";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.banda2);
            resources.ApplyResources(this.panel2, "panel2");
            this.panel2.Name = "panel2";
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.banda3);
            resources.ApplyResources(this.panel3, "panel3");
            this.panel3.Name = "panel3";
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.banda4);
            resources.ApplyResources(this.panel4, "panel4");
            this.panel4.Name = "panel4";
            // 
            // Form2
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ControlBox = false;
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.btn_calcular);
            this.Controls.Add(this.txt_result);
            this.Controls.Add(this.cb_banda2);
            this.Controls.Add(this.cb_banda4);
            this.Controls.Add(this.lbl_banda2);
            this.Controls.Add(this.lbl_banda4);
            this.Controls.Add(this.lbl_banda1);
            this.Controls.Add(this.lbl_banda3);
            this.Controls.Add(this.cb_banda1);
            this.Controls.Add(this.cb_banda3);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.lbl_titulo);
            this.Controls.Add(this.btn_salir);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "Form2";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Button btn_salir;
        private Label lbl_titulo;
        private PictureBox pictureBox1;
        private ComboBox cb_banda3;
        private Label lbl_banda3;
        private Label lbl_banda4;
        private ComboBox cb_banda4;
        private ComboBox cb_banda1;
        private Label lbl_banda1;
        private Label lbl_banda2;
        private ComboBox cb_banda2;
        private TextBox txt_result;
        private TextBox banda2;
        private TextBox banda1;
        private TextBox banda3;
        private TextBox banda4;
        private Button btn_calcular;
        private Panel panel1;
        private Panel panel2;
        private Panel panel3;
        private Panel panel4;
    }
}