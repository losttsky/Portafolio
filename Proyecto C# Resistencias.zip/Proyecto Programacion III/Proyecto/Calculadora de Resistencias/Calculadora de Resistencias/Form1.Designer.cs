﻿namespace Calculadora_de_Resistencias
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.lbl_titulo = new System.Windows.Forms.Label();
            this.btn_porColor = new System.Windows.Forms.Button();
            this.btn_porValor = new System.Windows.Forms.Button();
            this.btn_salir = new System.Windows.Forms.Button();
            this.btn_manual = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // lbl_titulo
            // 
            resources.ApplyResources(this.lbl_titulo, "lbl_titulo");
            this.lbl_titulo.Name = "lbl_titulo";
            // 
            // btn_porColor
            // 
            this.btn_porColor.BackColor = System.Drawing.Color.Yellow;
            resources.ApplyResources(this.btn_porColor, "btn_porColor");
            this.btn_porColor.Name = "btn_porColor";
            this.btn_porColor.UseVisualStyleBackColor = false;
            this.btn_porColor.Click += new System.EventHandler(this.btn_porColor_Click);
            // 
            // btn_porValor
            // 
            this.btn_porValor.BackColor = System.Drawing.Color.Yellow;
            resources.ApplyResources(this.btn_porValor, "btn_porValor");
            this.btn_porValor.Name = "btn_porValor";
            this.btn_porValor.UseVisualStyleBackColor = false;
            this.btn_porValor.Click += new System.EventHandler(this.btn_proValor_Click);
            // 
            // btn_salir
            // 
            this.btn_salir.BackColor = System.Drawing.Color.Red;
            this.btn_salir.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            resources.ApplyResources(this.btn_salir, "btn_salir");
            this.btn_salir.Name = "btn_salir";
            this.btn_salir.UseVisualStyleBackColor = false;
            this.btn_salir.Click += new System.EventHandler(this.btn_salir_Click);
            // 
            // btn_manual
            // 
            this.btn_manual.BackColor = System.Drawing.Color.Lime;
            resources.ApplyResources(this.btn_manual, "btn_manual");
            this.btn_manual.Name = "btn_manual";
            this.btn_manual.UseVisualStyleBackColor = false;
            this.btn_manual.Click += new System.EventHandler(this.btn_manual_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Calculadora_de_Resistencias.Properties.Resources.logo;
            resources.ApplyResources(this.pictureBox1, "pictureBox1");
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::Calculadora_de_Resistencias.Properties.Resources.logo;
            resources.ApplyResources(this.pictureBox2, "pictureBox2");
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.TabStop = false;
            // 
            // Form1
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ControlBox = false;
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.btn_salir);
            this.Controls.Add(this.btn_porValor);
            this.Controls.Add(this.btn_manual);
            this.Controls.Add(this.btn_porColor);
            this.Controls.Add(this.lbl_titulo);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label lbl_titulo;
        private Button btn_porColor;
        private Button btn_porValor;
        private Button btn_salir;
        private Button btn_manual;
        private PictureBox pictureBox1;
        private PictureBox pictureBox2;
    }
}