﻿namespace Calculadora_de_Resistencias
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form3));
            this.btn_salir = new System.Windows.Forms.Button();
            this.lbl_titulo = new System.Windows.Forms.Label();
            this.banda1 = new System.Windows.Forms.TextBox();
            this.banda4 = new System.Windows.Forms.TextBox();
            this.banda3 = new System.Windows.Forms.TextBox();
            this.banda2 = new System.Windows.Forms.TextBox();
            this.resistor = new System.Windows.Forms.PictureBox();
            this.txt_valor = new System.Windows.Forms.TextBox();
            this.btn_calcular = new System.Windows.Forms.Button();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.resistor)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_salir
            // 
            this.btn_salir.BackColor = System.Drawing.Color.Red;
            this.btn_salir.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            resources.ApplyResources(this.btn_salir, "btn_salir");
            this.btn_salir.Name = "btn_salir";
            this.btn_salir.UseVisualStyleBackColor = false;
            this.btn_salir.Click += new System.EventHandler(this.btn_salir_Click);
            // 
            // lbl_titulo
            // 
            resources.ApplyResources(this.lbl_titulo, "lbl_titulo");
            this.lbl_titulo.Name = "lbl_titulo";
            // 
            // banda1
            // 
            resources.ApplyResources(this.banda1, "banda1");
            this.banda1.Name = "banda1";
            this.banda1.ReadOnly = true;
            // 
            // banda4
            // 
            resources.ApplyResources(this.banda4, "banda4");
            this.banda4.Name = "banda4";
            this.banda4.ReadOnly = true;
            // 
            // banda3
            // 
            resources.ApplyResources(this.banda3, "banda3");
            this.banda3.Name = "banda3";
            this.banda3.ReadOnly = true;
            // 
            // banda2
            // 
            resources.ApplyResources(this.banda2, "banda2");
            this.banda2.Name = "banda2";
            this.banda2.ReadOnly = true;
            // 
            // resistor
            // 
            this.resistor.Image = global::Calculadora_de_Resistencias.Properties.Resources.resistencia;
            resources.ApplyResources(this.resistor, "resistor");
            this.resistor.Name = "resistor";
            this.resistor.TabStop = false;
            // 
            // txt_valor
            // 
            resources.ApplyResources(this.txt_valor, "txt_valor");
            this.txt_valor.Name = "txt_valor";
            // 
            // btn_calcular
            // 
            resources.ApplyResources(this.btn_calcular, "btn_calcular");
            this.btn_calcular.Name = "btn_calcular";
            this.btn_calcular.UseVisualStyleBackColor = true;
            this.btn_calcular.Click += new System.EventHandler(this.btn_calcular_Click);
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            resources.GetString("comboBox1.Items"),
            resources.GetString("comboBox1.Items1"),
            resources.GetString("comboBox1.Items2"),
            resources.GetString("comboBox1.Items3"),
            resources.GetString("comboBox1.Items4")});
            resources.ApplyResources(this.comboBox1, "comboBox1");
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.DropDownStyle = ComboBoxStyle.DropDownList;
            // 
            // Form3
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ControlBox = false;
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.btn_calcular);
            this.Controls.Add(this.txt_valor);
            this.Controls.Add(this.banda1);
            this.Controls.Add(this.banda4);
            this.Controls.Add(this.banda3);
            this.Controls.Add(this.banda2);
            this.Controls.Add(this.resistor);
            this.Controls.Add(this.lbl_titulo);
            this.Controls.Add(this.btn_salir);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "Form3";
            ((System.ComponentModel.ISupportInitialize)(this.resistor)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Button btn_salir;
        private Label lbl_titulo;
        private TextBox banda1;
        private TextBox banda4;
        private TextBox banda3;
        private TextBox banda2;
        private PictureBox resistor;
        private TextBox txt_valor;
        private Button btn_calcular;
        private ComboBox comboBox1;
    }
}