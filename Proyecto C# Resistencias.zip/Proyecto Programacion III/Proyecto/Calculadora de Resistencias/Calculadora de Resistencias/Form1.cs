namespace Calculadora_de_Resistencias
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_salir_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btn_porColor_Click(object sender, EventArgs e)
        {
            Hide();
            Form2 porColor = new Form2();
            porColor.Show();
        }

        private void btn_proValor_Click(object sender, EventArgs e)
        {
            Hide();
            Form3 porValor = new Form3();
            porValor.Show();
        }

        private void btn_manual_Click(object sender, EventArgs e)
        {
            Hide();
            Form4 manual = new Form4();
            manual.Show();
        }

    }
}